<?php
/**
 * Plugin Name:       LearnDash Group Leader Course Toggle
 * Description:       Enterprise LearnDash group management. Toggle course access per-group and per-user, view audit logs, wipe progress, and send group emails. Includes Site Admin governance controls.
 * Version:           3.8.1
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            
 * Text Domain:       glct
 * License:           GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 1 — RUNTIME CACHES
// ═══════════════════════════════════════════════════════════════════════════

/** @var int[][]  group_id → course_id[] */
$_glct_disabled_cache = [];
/** @var int[]|null  current user's hidden course IDs */
$_glct_hidden_cache = null;
/** @var int[]|null  current user's group IDs */
$_glct_my_group_ids_cache = null;
/** @var array[]  group_id → WP_User[] members cache */
$_glct_members_cache = [];

/**
 * Get the LearnDash group post type slug.
 * Uses LearnDash 5.0's `learndash_get_post_type_slug()` if available,
 * falls back to the default 'groups' for older versions.
 */
function glct_group_post_type(): string {
    static $slug = null;
    if ( $slug === null ) {
        $slug = function_exists( 'learndash_get_post_type_slug' )
            ? learndash_get_post_type_slug( 'group' )
            : 'groups';
    }
    return $slug;
}


// ═══════════════════════════════════════════════════════════════════════════
// SECTION 2 — HIDE DISABLED COURSES FROM FRONT-END QUERIES
// ═══════════════════════════════════════════════════════════════════════════

add_action( 'pre_get_posts', 'glct_hide_disabled_courses' );

function glct_hide_disabled_courses( WP_Query $query ): void {
    if ( is_admin() || wp_doing_ajax() ) {
        return;
    }

    $pt = (array) $query->get( 'post_type' );
    if ( ! in_array( 'sfwd-courses', $pt, true ) && $query->get( 'post_type' ) !== 'sfwd-courses' ) {
        return;
    }

    if ( current_user_can( 'administrator' ) || current_user_can( 'group_leader' ) ) {
        return;
    }

    $hide = glct_hidden_course_ids_for_user( get_current_user_id() );
    if ( empty( $hide ) ) {
        return;
    }

    $existing = (array) $query->get( 'post__not_in' );
    $query->set( 'post__not_in', array_unique( array_merge( $existing, $hide ) ) );
}

function glct_hidden_course_ids_for_user( int $user_id ): array {
    global $_glct_hidden_cache;

    if ( ! $user_id ) {
        return glct_all_globally_disabled_ids();
    }

    if ( $_glct_hidden_cache !== null ) {
        return $_glct_hidden_cache;
    }

    $group_ids = function_exists( 'learndash_get_users_group_ids' )
        ? (array) learndash_get_users_group_ids( $user_id )
        : [];

    // Track courses that are accessible in AT LEAST ONE group vs. hidden in a group.
    // A course should only be hidden from the front end if no group grants the user access —
    // one group disabling a course must not override another group enabling it for this user.
    $accessible = [];
    $hidden     = [];

    foreach ( $group_ids as $gid ) {
        $gid    = (int) $gid;
        $master = array_filter( array_map( 'intval', (array) get_post_meta( $gid, 'glct_master_courses', true ) ) );

        foreach ( $master as $cid ) {
            if ( glct_is_enabled( $gid, $cid ) ) {
                if ( glct_is_user_blocked( $gid, $cid, $user_id ) ) {
                    $hidden[] = $cid;       // group on, but user individually blocked
                } else {
                    $accessible[] = $cid;   // group on, user not blocked → accessible
                }
            } else {
                if ( get_user_meta( $user_id, "glct_force_on_{$gid}_{$cid}", true ) === '1' ) {
                    $accessible[] = $cid;   // group off, but user has force-on override → accessible
                } else {
                    $hidden[] = $cid;       // group off, no override → hidden
                }
            }
        }
    }

    // Only hide courses that are not accessible via any of the user's groups.
    $_glct_hidden_cache = array_values(
        array_diff( array_unique( $hidden ), array_unique( $accessible ) )
    );
    return $_glct_hidden_cache;
}

function glct_all_globally_disabled_ids(): array {
    $group_ids = get_posts( [
        'post_type'      => glct_group_post_type(),
        'posts_per_page' => -1,
        'post_status'    => 'publish',
        'fields'         => 'ids',
    ] );

    $hidden = [];
    foreach ( $group_ids as $gid ) {
        foreach ( glct_disabled_ids( (int) $gid ) as $cid ) {
            $hidden[] = $cid;
        }
    }

    return array_unique( $hidden );
}


// ═══════════════════════════════════════════════════════════════════════════
// SECTION 3 — SHORTCODE
// ═══════════════════════════════════════════════════════════════════════════

add_shortcode( 'group_leader_course_toggle', 'glct_shortcode' );

function glct_shortcode(): string {
    // Prevent page caching — this page contains nonces and user-specific content
    if ( ! defined( 'DONOTCACHEPAGE' ) ) {
        define( 'DONOTCACHEPAGE', true );
    }
    nocache_headers();

    if ( ! is_user_logged_in() ) {
        return '<p class="glct-notice">You must be logged in to manage courses.</p>';
    }

    $user = wp_get_current_user();
    $is_manager = current_user_can( 'administrator' )
        || in_array( 'group_leader', (array) $user->roles, true );

    if ( ! $is_manager ) {
        return '<p class="glct-notice">You do not have permission to manage group courses.</p>';
    }

    $all_groups = glct_my_groups( $user->ID );
    if ( empty( $all_groups ) ) {
        return '<p class="glct-notice">You are not assigned as a leader of any LearnDash group.</p>';
    }

    $selected_gid = isset( $_GET['glct_group_id'] ) ? (int) $_GET['glct_group_id'] : 0;

    $active_groups = [];
    if ( $selected_gid && glct_can_manage( $selected_gid ) ) {
        $active_groups = array_values( array_filter(
            $all_groups,
            fn( WP_Post $g ): bool => $g->ID === $selected_gid
        ) );
    }

    if ( empty( $active_groups ) ) {
        $active_groups = [ $all_groups[0] ];
    }

    ob_start();
    glct_render( $active_groups, $all_groups );
    return ob_get_clean();
}


// ═══════════════════════════════════════════════════════════════════════════
// SECTION 4 — DATA HELPERS
// ═══════════════════════════════════════════════════════════════════════════

function glct_my_groups( int $user_id ): array {
    if ( current_user_can( 'administrator' ) ) {
        return get_posts( [
            'post_type'      => glct_group_post_type(),
            'posts_per_page' => -1,
            'post_status'    => 'publish',
        ] );
    }

    if ( function_exists( 'learndash_get_administrators_group_ids' ) ) {
        $ids = (array) learndash_get_administrators_group_ids( $user_id, 'group_leader' );
        if ( ! empty( $ids ) ) {
            return get_posts( [
                'post_type'      => glct_group_post_type(),
                'post__in'       => array_map( 'intval', $ids ),
                'posts_per_page' => -1,
                'post_status'    => 'publish',
            ] );
        }
    }

    global $wpdb;
    $meta_keys = $wpdb->get_col( $wpdb->prepare(
        "SELECT meta_key FROM {$wpdb->usermeta} WHERE user_id = %d AND meta_key LIKE %s",
        $user_id,
        $wpdb->esc_like( 'learndash_group_leaders_' ) . '%'
    ) );

    if ( empty( $meta_keys ) ) {
        return [];
    }

    $ids = array_filter( array_map(
        fn( string $k ): int => (int) str_replace( 'learndash_group_leaders_', '', $k ),
        $meta_keys
    ) );

    return empty( $ids ) ? [] : get_posts( [
        'post_type'      => glct_group_post_type(),
        'post__in'       => $ids,
        'posts_per_page' => -1,
        'post_status'    => 'publish',
    ] );
}

function glct_all_courses( int $group_id ): array {
    $active = function_exists( 'learndash_group_enrolled_courses' )
        ? (array) learndash_group_enrolled_courses( $group_id, true )
        : (array) get_post_meta( $group_id, 'learndash_group_enrolled_courses', true );

    $active   = array_filter( array_map( 'intval', $active ) );
    $disabled = glct_disabled_ids( $group_id );
    $master   = array_filter( array_map( 'intval', (array) get_post_meta( $group_id, 'glct_master_courses', true ) ) );
    $all      = array_unique( array_merge( $master, $active, $disabled ) );

    if ( ! empty( $all ) && array_diff( $all, $master ) ) {
        update_post_meta( $group_id, 'glct_master_courses', array_values( $all ) );
    }

    if ( empty( $all ) ) {
        return [];
    }

    return get_posts( [
        'post_type'      => 'sfwd-courses',
        'post__in'       => $all,
        'posts_per_page' => -1,
        'post_status'    => 'publish',
        'orderby'        => 'title',
        'order'          => 'ASC',
    ] );
}

function glct_disabled_ids( int $group_id ): array {
    global $_glct_disabled_cache;

    if ( ! isset( $_glct_disabled_cache[ $group_id ] ) ) {
        $v = get_post_meta( $group_id, 'glct_disabled_courses', true );
        $_glct_disabled_cache[ $group_id ] = ( is_array( $v ) && ! empty( $v ) )
            ? array_values( array_filter( array_map( 'intval', $v ) ) )
            : [];
    }

    return $_glct_disabled_cache[ $group_id ];
}

function glct_is_enabled( int $group_id, int $course_id ): bool {
    return ! in_array( $course_id, glct_disabled_ids( $group_id ), true );
}

function glct_is_user_blocked( int $group_id, int $course_id, int $user_id ): bool {
    return get_user_meta( $user_id, "glct_block_{$group_id}_{$course_id}", true ) === '1';
}

function glct_members( int $group_id ): array {
    global $_glct_members_cache;

    if ( ! isset( $_glct_members_cache[ $group_id ] ) ) {
        $_glct_members_cache[ $group_id ] = function_exists( 'learndash_get_groups_users' )
            ? ( (array) learndash_get_groups_users( $group_id ) ?: [] )
            : [];
    }

    return $_glct_members_cache[ $group_id ];
}

function glct_can_manage( int $group_id ): bool {
    if ( current_user_can( 'administrator' ) ) {
        return true;
    }

    global $_glct_my_group_ids_cache;

    if ( $_glct_my_group_ids_cache === null ) {
        $groups = glct_my_groups( get_current_user_id() );
        $_glct_my_group_ids_cache = array_map( fn( WP_Post $g ): int => $g->ID, $groups );
    }

    return in_array( $group_id, $_glct_my_group_ids_cache, true );
}

/**
 * Get the Group Leader user IDs for a specific group.
 * Uses LearnDash API if available, falls back to usermeta lookup.
 *
 * @param int $group_id The group post ID.
 * @return int[] Array of user IDs who are leaders of this group.
 */
function glct_group_leaders( int $group_id ): array {
    // LearnDash 3.x+ provides this
    if ( function_exists( 'learndash_get_groups_administrators' ) ) {
        $leaders = learndash_get_groups_administrators( $group_id );
        return array_map( 'intval', wp_list_pluck( $leaders, 'ID' ) );
    }

    // Fallback: search usermeta for learndash_group_leaders_{group_id}
    global $wpdb;
    $meta_key = 'learndash_group_leaders_' . $group_id;
    $ids = $wpdb->get_col( $wpdb->prepare(
        "SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = %s",
        $meta_key
    ) );
    return array_map( 'intval', $ids );
}

/**
 * Returns true if the given user has effective access to a course through
 * at least one group OTHER than $excluding_group_id.
 *
 * Used before revoking global LearnDash enrollment to prevent a toggle in
 * one group from stripping access that another group grants.
 */
function glct_user_has_course_via_other_group( int $user_id, int $course_id, int $excluding_group_id ): bool {
    $user_group_ids = function_exists( 'learndash_get_users_group_ids' )
        ? (array) learndash_get_users_group_ids( $user_id )
        : [];

    foreach ( $user_group_ids as $gid ) {
        $gid = (int) $gid;
        if ( $gid === $excluding_group_id ) {
            continue;
        }

        // Only consider groups where this course is tracked in master_courses.
        $master = array_filter( array_map( 'intval', (array) get_post_meta( $gid, 'glct_master_courses', true ) ) );
        if ( ! in_array( $course_id, $master, true ) ) {
            continue;
        }

        if ( glct_is_enabled( $gid, $course_id ) ) {
            // Group has the course enabled — user has access unless individually blocked.
            if ( ! glct_is_user_blocked( $gid, $course_id, $user_id ) ) {
                return true;
            }
        } else {
            // Group has the course disabled — user still has access if force-on override exists.
            if ( get_user_meta( $user_id, "glct_force_on_{$gid}_{$course_id}", true ) === '1' ) {
                return true;
            }
        }
    }

    return false;
}

/**
 * Checks whether the current user (Group Leader) has permission to use a specific feature.
 * Administrators always bypass restrictions.
 */
function glct_gl_can( string $feature ): bool {
    if ( current_user_can( 'administrator' ) ) {
        return true;
    }
    return get_option( "glct_allow_{$feature}", 'yes' ) === 'yes';
}

/**
 * Returns true if a course is part of a group's tracked course catalog.
 * Checks both the plugin's master list and LearnDash's enrolled courses.
 */
function glct_course_in_group( int $group_id, int $course_id ): bool {
    $master = array_filter( array_map( 'intval',
        (array) get_post_meta( $group_id, 'glct_master_courses', true )
    ) );
    if ( in_array( $course_id, $master, true ) ) {
        return true;
    }
    // Fall back to LearnDash's native group-course enrollment
    if ( function_exists( 'learndash_group_enrolled_courses' ) ) {
        $ld_courses = array_map( 'intval', (array) learndash_group_enrolled_courses( $group_id ) );
        return in_array( $course_id, $ld_courses, true );
    }
    return false;
}

/**
 * Retrieves course tags map for a group.
 * Returns associative array [ course_id (int) => tag_name (string) ]
 */
function glct_get_course_tags( int $group_id ): array {
    $raw = get_post_meta( $group_id, 'glct_course_tags', true );
    if ( ! is_array( $raw ) ) {
        return [];
    }
    // Normalize keys to integers for consistent lookup
    $tags = [];
    foreach ( $raw as $k => $v ) {
        $tags[ (int) $k ] = (string) $v;
    }
    return $tags;
}

/**
 * Batch-fetch course progress for multiple users on a specific course.
 * Uses WordPress object cache (compatible with Redis/Memcached via Object Cache Pro).
 *
 * @param int[] $user_ids List of user IDs.
 * @param int   $course_id The course to check progress for.
 * @return array [ user_id => [ 'percentage' => int, 'status' => string, 'completed_on' => string|null ] ]
 */
function glct_batch_course_progress( array $user_ids, int $course_id ): array {
    if ( empty( $user_ids ) ) return [];

    $user_ids = array_map( 'intval', array_unique( $user_ids ) );

    // Prime the WordPress meta cache for all users in one SQL query.
    // This populates wp_cache so subsequent get_user_meta() calls hit
    // the object cache (Redis/Memcached) instead of individual SQL queries.
    update_meta_cache( 'user', $user_ids );

    $results = [];
    foreach ( $user_ids as $uid ) {
        $uid = (int) $uid;

        // Check completion timestamp first (reads from object cache)
        $completed_ts = (int) get_user_meta( $uid, 'course_completed_' . $course_id, true );
        if ( $completed_ts > 0 ) {
            $results[ $uid ] = [
                'percentage'   => 100,
                'status'       => 'completed',
                'completed_on' => gmdate( 'Y-m-d', $completed_ts ),
            ];
            continue;
        }

        // Read progress data (reads from object cache)
        $all_progress = get_user_meta( $uid, '_sfwd-course_progress', true );
        if ( ! is_array( $all_progress ) || ! isset( $all_progress[ $course_id ] ) ) {
            $results[ $uid ] = [
                'percentage'   => 0,
                'status'       => 'not_started',
                'completed_on' => null,
            ];
            continue;
        }

        $course_progress = $all_progress[ $course_id ];
        $total           = isset( $course_progress['total'] ) ? (int) $course_progress['total'] : 0;
        $completed_steps = isset( $course_progress['completed'] ) ? (int) $course_progress['completed'] : 0;
        $pct             = $total > 0 ? (int) round( ( $completed_steps / $total ) * 100 ) : 0;

        $results[ $uid ] = [
            'percentage'   => min( $pct, 100 ),
            'status'       => $pct > 0 ? 'in_progress' : 'not_started',
            'completed_on' => null,
        ];
    }

    return $results;
}

/**
 * Batch-fetch course progress for multiple users across MULTIPLE courses in one pass.
 * Avoids redundant deserialization of _sfwd-course_progress when checking many courses.
 * Returns [ course_id => [ user_id => [ 'percentage' => int, 'status' => string, 'completed_on' => string|null ] ] ]
 *
 * @param int[] $user_ids  List of user IDs.
 * @param int[] $course_ids List of course IDs.
 * @return array
 */
function glct_batch_multi_course_progress( array $user_ids, array $course_ids ): array {
    if ( empty( $user_ids ) || empty( $course_ids ) ) return [];

    $user_ids   = array_map( 'intval', array_unique( $user_ids ) );
    $course_ids = array_map( 'intval', array_unique( $course_ids ) );

    // Prime the meta cache for all users in one SQL query
    update_meta_cache( 'user', $user_ids );

    // Deserialize _sfwd-course_progress ONCE per user
    $progress_map   = [];
    $completion_map = [];
    foreach ( $user_ids as $uid ) {
        $uid = (int) $uid;
        $progress_map[ $uid ] = get_user_meta( $uid, '_sfwd-course_progress', true );
        if ( ! is_array( $progress_map[ $uid ] ) ) {
            $progress_map[ $uid ] = [];
        }
        // Pre-fetch all completion timestamps
        foreach ( $course_ids as $cid ) {
            $ts = (int) get_user_meta( $uid, 'course_completed_' . $cid, true );
            if ( $ts > 0 ) {
                $completion_map[ $uid ][ $cid ] = $ts;
            }
        }
    }

    // Build results per course
    $results = [];
    foreach ( $course_ids as $cid ) {
        $cid = (int) $cid;
        $results[ $cid ] = [];
        foreach ( $user_ids as $uid ) {
            $uid = (int) $uid;

            if ( isset( $completion_map[ $uid ][ $cid ] ) ) {
                $results[ $cid ][ $uid ] = [
                    'percentage'   => 100,
                    'status'       => 'completed',
                    'completed_on' => gmdate( 'Y-m-d', $completion_map[ $uid ][ $cid ] ),
                ];
                continue;
            }

            $user_progress = $progress_map[ $uid ];
            if ( ! isset( $user_progress[ $cid ] ) ) {
                $results[ $cid ][ $uid ] = [
                    'percentage'   => 0,
                    'status'       => 'not_started',
                    'completed_on' => null,
                ];
                continue;
            }

            $cp    = $user_progress[ $cid ];
            $total = isset( $cp['total'] ) ? (int) $cp['total'] : 0;
            $done  = isset( $cp['completed'] ) ? (int) $cp['completed'] : 0;
            $pct   = $total > 0 ? (int) round( ( $done / $total ) * 100 ) : 0;

            $results[ $cid ][ $uid ] = [
                'percentage'   => min( $pct, 100 ),
                'status'       => $pct > 0 ? 'in_progress' : 'not_started',
                'completed_on' => null,
            ];
        }
    }

    return $results;
}

/**
 * Get a single course deadline for a group.
 */
function glct_get_deadline( int $group_id, int $course_id ): ?string {
    $val = get_post_meta( $group_id, "glct_deadline_{$course_id}", true );
    return ! empty( $val ) ? $val : null;
}

/**
 * Get all deadlines for a group (keyed by course_id).
 */
function glct_get_all_deadlines( int $group_id ): array {
    global $wpdb;
    $prefix = 'glct_deadline_';
    $rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT meta_key, meta_value FROM {$wpdb->postmeta}
         WHERE post_id = %d AND meta_key LIKE %s AND meta_value != ''",
        $group_id,
        $wpdb->esc_like( $prefix ) . '%'
    ) );
    $deadlines = [];
    foreach ( $rows as $row ) {
        $cid = (int) str_replace( $prefix, '', $row->meta_key );
        if ( $cid > 0 ) $deadlines[ $cid ] = $row->meta_value;
    }
    return $deadlines;
}

/**
 * Compute deadline status label and CSS class.
 */
function glct_deadline_status( string $deadline_date ): array {
    $now  = new DateTime( current_time( 'Y-m-d' ) );
    $due  = new DateTime( $deadline_date );
    $diff = (int) $now->diff( $due )->format( '%r%a' );

    if ( $diff < 0 ) {
        return [ 'label' => 'Overdue by ' . abs( $diff ) . 'd', 'class' => 'glct-deadline--overdue' ];
    }
    if ( $diff === 0 ) {
        return [ 'label' => 'Due today', 'class' => 'glct-deadline--urgent' ];
    }
    if ( $diff <= 7 ) {
        return [ 'label' => 'Due in ' . $diff . 'd', 'class' => 'glct-deadline--soon' ];
    }
    return [ 'label' => 'Due ' . $due->format( 'M j' ), 'class' => 'glct-deadline--normal' ];
}


// ═══════════════════════════════════════════════════════════════════════════
// SECTION 5 — TOGGLE LOGIC
// ═══════════════════════════════════════════════════════════════════════════

function glct_toggle_group( int $group_id, int $course_id, bool $override_caps = false ): array {
    if ( ! $override_caps && ! glct_can_manage( $group_id ) ) {
        return [ 'success' => false, 'message' => 'Permission denied.' ];
    }

    if ( ! $override_caps && ! glct_course_in_group( $group_id, $course_id ) ) {
        return [ 'success' => false, 'message' => 'Course does not belong to this group.' ];
    }

    $master = array_values( array_unique( array_merge(
        array_filter( array_map( 'intval', (array) get_post_meta( $group_id, 'glct_master_courses', true ) ) ),
        [ $course_id ]
    ) ) );
    update_post_meta( $group_id, 'glct_master_courses', $master );

    $disabled = glct_disabled_ids( $group_id );
    $is_on    = ! in_array( $course_id, $disabled, true );
    $members  = glct_members( $group_id );

    global $_glct_disabled_cache;

    if ( $is_on ) {
        // ── DISABLE ─────────────────────────────────────────────────────────
        $disabled[] = $course_id;
        $disabled   = array_values( array_unique( $disabled ) );
        update_post_meta( $group_id, 'glct_disabled_courses', $disabled );
        $_glct_disabled_cache[ $group_id ] = $disabled;

        if ( function_exists( 'ld_update_course_group_access' ) ) {
            ld_update_course_group_access( $course_id, $group_id, true );
        } else {
            glct_meta_remove_course( $group_id, $course_id );
        }

        if ( function_exists( 'ld_update_course_access' ) ) {
            foreach ( $members as $u ) {
                if ( get_user_meta( $u->ID, "glct_force_on_{$group_id}_{$course_id}", true ) === '1' ) {
                    continue;
                }
                // Only revoke global LD enrollment if no other group grants this user access.
                // Prevents one group's disable from stripping access earned through another group.
                if ( ! glct_user_has_course_via_other_group( $u->ID, $course_id, $group_id ) ) {
                    ld_update_course_access( $u->ID, $course_id, true );
                }
            }
        }

        update_post_meta( $group_id, "glct_toggled_{$course_id}", current_time( 'mysql' ) );
        glct_log_event( 'group', $group_id, $course_id, 0, false );
        glct_notify_group_members( $group_id, $course_id, 'course_disabled',
            'Course Disabled: ' . get_the_title( $course_id ),
            'The course "' . esc_html( get_the_title( $course_id ) ) . '" has been disabled for your group. Please contact your Group Leader with any questions.'
        );

        return [ 'success' => true, 'enabled' => false, 'message' => 'Course disabled — hidden from group defaults.' ];

    } else {
        // ── ENABLE ──────────────────────────────────────────────────────────
        $disabled = array_values( array_diff( $disabled, [ $course_id ] ) );
        update_post_meta( $group_id, 'glct_disabled_courses', $disabled );
        $_glct_disabled_cache[ $group_id ] = $disabled;

        if ( function_exists( 'ld_update_course_group_access' ) ) {
            ld_update_course_group_access( $course_id, $group_id, false );
        } else {
            glct_meta_add_course( $group_id, $course_id );
        }

        if ( function_exists( 'ld_update_course_access' ) ) {
            foreach ( $members as $u ) {
                if ( glct_is_user_blocked( $group_id, $course_id, $u->ID ) ) {
                    continue; 
                }
                ld_update_course_access( $u->ID, $course_id, false );
            }
        }

        update_post_meta( $group_id, "glct_toggled_{$course_id}", current_time( 'mysql' ) );
        glct_log_event( 'group', $group_id, $course_id, 0, true );
        glct_notify_group_members( $group_id, $course_id, 'course_enabled',
            'Course Enabled: ' . get_the_title( $course_id ),
            'The course "' . esc_html( get_the_title( $course_id ) ) . '" is now available for your group.'
        );

        return [ 'success' => true, 'enabled' => true, 'message' => 'Course enabled — default access restored.' ];
    }
}

function glct_toggle_user( int $group_id, int $course_id, int $user_id, bool $state ): array {
    if ( ! glct_can_manage( $group_id ) ) {
        return [ 'success' => false, 'message' => 'Permission denied.' ];
    }

    $member_ids = array_map( fn( WP_User $u ): int => $u->ID, glct_members( $group_id ) );
    if ( ! in_array( $user_id, $member_ids, true ) ) {
        return [ 'success' => false, 'message' => 'User is not a member of this group.' ];
    }

    if ( ! glct_course_in_group( $group_id, $course_id ) ) {
        return [ 'success' => false, 'message' => 'Course does not belong to this group.' ];
    }

    $is_group_on = glct_is_enabled( $group_id, $course_id );

    if ( $state ) {
        delete_user_meta( $user_id, "glct_block_{$group_id}_{$course_id}" );
        if ( ! $is_group_on ) {
            update_user_meta( $user_id, "glct_force_on_{$group_id}_{$course_id}", '1' );
        }
        if ( function_exists( 'ld_update_course_access' ) ) {
            ld_update_course_access( $user_id, $course_id, false );
        }
        glct_log_event( 'user', $group_id, $course_id, $user_id, true );
        glct_create_notification( 'user_enabled', $user_id, $group_id, $course_id,
            'Course Access Granted: ' . get_the_title( $course_id ),
            'You have been granted access to "' . esc_html( get_the_title( $course_id ) ) . '".'
        );
        return [ 'success' => true, 'enabled' => true, 'message' => 'Access granted.' ];
    } else {
        delete_user_meta( $user_id, "glct_force_on_{$group_id}_{$course_id}" );
        if ( $is_group_on ) {
            update_user_meta( $user_id, "glct_block_{$group_id}_{$course_id}", '1' );
        }
        if ( function_exists( 'ld_update_course_access' ) ) {
            // Only revoke global LD enrollment if no other group grants this user access.
            if ( ! glct_user_has_course_via_other_group( $user_id, $course_id, $group_id ) ) {
                ld_update_course_access( $user_id, $course_id, true );
            }
        }
        glct_log_event( 'user', $group_id, $course_id, $user_id, false );
        glct_create_notification( 'user_disabled', $user_id, $group_id, $course_id,
            'Course Access Revoked: ' . get_the_title( $course_id ),
            'Your access to "' . esc_html( get_the_title( $course_id ) ) . '" has been revoked. Please contact your Group Leader with any questions.'
        );
        return [ 'success' => true, 'enabled' => false, 'message' => 'Access revoked.' ];
    }
}

function glct_meta_add_course( int $group_id, int $course_id ): void {
    $ids = array_unique( array_merge(
        array_filter( array_map( 'intval', (array) get_post_meta( $group_id, 'learndash_group_enrolled_courses', true ) ) ),
        [ $course_id ]
    ) );
    update_post_meta( $group_id, 'learndash_group_enrolled_courses', array_values( $ids ) );

    $gids = array_unique( array_merge(
        array_filter( array_map( 'intval', (array) get_post_meta( $course_id, 'learndash_course_groups', true ) ) ),
        [ $group_id ]
    ) );
    update_post_meta( $course_id, 'learndash_course_groups', array_values( $gids ) );
}

function glct_meta_remove_course( int $group_id, int $course_id ): void {
    $ids = array_values( array_diff(
        array_filter( array_map( 'intval', (array) get_post_meta( $group_id, 'learndash_group_enrolled_courses', true ) ) ),
        [ $course_id ]
    ) );
    update_post_meta( $group_id, 'learndash_group_enrolled_courses', $ids );

    $gids = array_values( array_diff(
        array_filter( array_map( 'intval', (array) get_post_meta( $course_id, 'learndash_course_groups', true ) ) ),
        [ $group_id ]
    ) );
    update_post_meta( $course_id, 'learndash_course_groups', $gids );
}


// ═══════════════════════════════════════════════════════════════════════════
// SECTION 6 — AUTO-ENROLL NEW GROUP MEMBERS
// ═══════════════════════════════════════════════════════════════════════════

add_action( 'ld_added_group_access', function ( int $user_id, int $group_id ): void {
    if ( ! function_exists( 'ld_update_course_access' ) ) {
        return;
    }
    foreach ( glct_all_courses( $group_id ) as $course ) {
        if ( glct_is_enabled( $group_id, $course->ID ) ) {
            if ( ! glct_is_user_blocked( $group_id, $course->ID, $user_id ) ) {
                ld_update_course_access( $user_id, $course->ID, false );
            }
        } else {
            if ( get_user_meta( $user_id, "glct_force_on_{$group_id}_{$course->ID}", true ) === '1' ) {
                ld_update_course_access( $user_id, $course->ID, false );
            }
        }
    }
}, 10, 2 );


// ═══════════════════════════════════════════════════════════════════════════
// SECTION 7 — AJAX HANDLERS
// ═══════════════════════════════════════════════════════════════════════════

add_action( 'wp_ajax_glct_refresh_group', function (): void {
    check_ajax_referer( 'glct_nonce', 'nonce' );
    $gid = (int) ( $_POST['group_id'] ?? 0 );

    if ( ! glct_can_manage( $gid ) ) {
        wp_send_json_error( [ 'message' => 'Permission denied.' ] );
        return;
    }

    $active = function_exists( 'learndash_group_enrolled_courses' )
        ? (array) learndash_group_enrolled_courses( $gid, true )
        : (array) get_post_meta( $gid, 'learndash_group_enrolled_courses', true );

    $active   = array_filter( array_map( 'intval', $active ) );
    $disabled = glct_disabled_ids( $gid );

    // Preserve existing master_courses (including expansion-added courses)
    // to prevent data loss when courses are disabled or externally modified.
    $existing_master = array_filter( array_map( 'intval',
        (array) get_post_meta( $gid, 'glct_master_courses', true )
    ) );

    $new_master = array_values( array_unique( array_merge( $existing_master, $active, $disabled ) ) );
    update_post_meta( $gid, 'glct_master_courses', $new_master );

    wp_send_json_success( [ 'message' => 'Group synced with LearnDash successfully.' ] );
} );

add_action( 'wp_ajax_glct_remove_course', function (): void {
    check_ajax_referer( 'glct_nonce', 'nonce' );
    
    if ( get_option('glct_allow_remove', 'yes') !== 'yes' ) {
        wp_send_json_error( [ 'message' => 'Course removal is disabled by the Site Admin.' ] );
        return;
    }

    $gid = (int) ( $_POST['group_id'] ?? 0 );
    $cid = (int) ( $_POST['course_id'] ?? 0 );

    if ( ! glct_can_manage( $gid ) ) {
        wp_send_json_error( [ 'message' => 'Permission denied.' ] );
        return;
    }

    if ( ! glct_course_in_group( $gid, $cid ) ) {
        wp_send_json_error( [ 'message' => 'Course does not belong to this group.' ] );
        return;
    }

    if ( function_exists( 'ld_update_course_group_access' ) ) {
        ld_update_course_group_access( $cid, $gid, true );
    } else {
        glct_meta_remove_course( $gid, $cid );
    }

    $members = glct_members( $gid );
    if ( function_exists( 'ld_update_course_access' ) ) {
        foreach ( $members as $u ) {
            if ( get_user_meta( $u->ID, "glct_force_on_{$gid}_{$cid}", true ) === '1' ) {
                continue;
            }
            // Only revoke global LD enrollment if no other group grants this user access.
            if ( ! glct_user_has_course_via_other_group( $u->ID, $cid, $gid ) ) {
                ld_update_course_access( $u->ID, $cid, true );
            }
        }
    }

    $disabled = glct_disabled_ids( $gid );
    $disabled = array_values( array_diff( $disabled, [ $cid ] ) );
    update_post_meta( $gid, 'glct_disabled_courses', $disabled );

    $master = (array) get_post_meta( $gid, 'glct_master_courses', true );
    $master = array_values( array_diff( array_map( 'intval', $master ), [ $cid ] ) );
    update_post_meta( $gid, 'glct_master_courses', $master );

    glct_log_event( 'course_removed', $gid, $cid, 0, false );
    $rm_title = get_the_title( $cid );
    foreach ( $members as $u ) {
        glct_create_notification( 'course_removed', $u->ID, $gid, $cid,
            'Course Removed: ' . $rm_title,
            'The course "' . esc_html( $rm_title ) . '" has been removed from your group. Please contact your Group Leader with any questions.'
        );
    }
    wp_send_json_success( [ 'message' => 'Course removed from group successfully.' ] );
} );

add_action( 'wp_ajax_glct_toggle_group', function (): void {
    check_ajax_referer( 'glct_nonce', 'nonce' );
    $gid = (int) ( $_POST['group_id'] ?? 0 );
    $cid = (int) ( $_POST['course_id'] ?? 0 );
    $wipe = ! empty( $_POST['wipe_progress'] );
    
    $result = glct_toggle_group( $gid, $cid );
    
    if ( $result['success'] && $wipe && get_option('glct_allow_wipe', 'yes') === 'yes' ) {
        $members = glct_members( $gid );
        foreach ( $members as $u ) {
            glct_wipe_course_progress( $u->ID, $cid );
        }
        glct_log_event( 'group_wipe', $gid, $cid, 0, false );
    }
    
    $result['success'] ? wp_send_json_success( $result ) : wp_send_json_error( $result );
} );

add_action( 'wp_ajax_glct_toggle_user', function (): void {
    check_ajax_referer( 'glct_nonce', 'nonce' );
    if ( ! glct_gl_can( 'per_user' ) ) {
        wp_send_json_error( [ 'message' => 'Per-user overrides are disabled by Site Admin.' ] );
        return;
    }
    $result = glct_toggle_user(
        (int) ( $_POST['group_id']  ?? 0 ),
        (int) ( $_POST['course_id'] ?? 0 ),
        (int) ( $_POST['user_id']   ?? 0 ),
        (bool) ( $_POST['state'] ?? false )
    );
    $result['success'] ? wp_send_json_success( $result ) : wp_send_json_error( $result );
} );

add_action( 'wp_ajax_glct_bulk_user_toggle', function (): void {
    check_ajax_referer( 'glct_nonce', 'nonce' );
    if ( ! glct_gl_can( 'bulk_toggle' ) ) {
        wp_send_json_error( [ 'message' => 'Bulk toggle is disabled by Site Admin.' ] );
        return;
    }
    $gid = (int) ( $_POST['group_id']  ?? 0 );
    $cid = (int) ( $_POST['course_id'] ?? 0 );
    $state = (bool) ( $_POST['state'] ?? false );

    if ( ! glct_can_manage( $gid ) ) {
        wp_send_json_error( [ 'message' => 'Permission denied.' ] );
        return;
    }

    if ( ! glct_course_in_group( $gid, $cid ) ) {
        wp_send_json_error( [ 'message' => 'Course does not belong to this group.' ] );
        return;
    }

    $members = glct_members( $gid );
    foreach ( $members as $u ) {
        glct_toggle_user( $gid, $cid, $u->ID, $state );
    }

    wp_send_json_success( [ 'message' => $state ? 'All users enabled.' : 'All users disabled.' ] );
} );

add_action( 'wp_ajax_glct_get_members', function (): void {
    check_ajax_referer( 'glct_nonce', 'nonce' );
    $gid = (int) ( $_POST['group_id']  ?? 0 );
    $cid = (int) ( $_POST['course_id'] ?? 0 );

    if ( ! glct_can_manage( $gid ) ) {
        wp_send_json_error( [ 'message' => 'Permission denied.' ] );
        return;
    }

    if ( ! glct_course_in_group( $gid, $cid ) ) {
        wp_send_json_error( [ 'message' => 'Course does not belong to this group.' ] );
        return;
    }

    $is_group_on = glct_is_enabled( $gid, $cid );

    $members = array_map(
        function ( WP_User $u ) use ( $gid, $cid, $is_group_on ) {
            $blocked = glct_is_user_blocked( $gid, $cid, $u->ID );
            $force_on = get_user_meta( $u->ID, "glct_force_on_{$gid}_{$cid}", true ) === '1';
            $enabled = $is_group_on ? ! $blocked : $force_on;

            return [
                'id'      => $u->ID,
                'name'    => $u->display_name,
                'email'   => $u->user_email,
                'enabled' => $enabled,
            ];
        },
        glct_members( $gid )
    );

    // Enrich with progress data if enabled
    if ( get_option( 'glct_allow_progress_visibility', 'yes' ) === 'yes' ) {
        $member_ids = array_column( $members, 'id' );
        $progress   = glct_batch_course_progress( $member_ids, $cid );
        foreach ( $members as &$m ) {
            $p = $progress[ $m['id'] ] ?? [ 'percentage' => 0, 'status' => 'not_started', 'completed_on' => null ];
            $m['progress']        = $p['percentage'];
            $m['progress_status'] = $p['status'];
            $m['completed_on']    = $p['completed_on'];
        }
        unset( $m );
    }

    wp_send_json_success( [ 'members' => $members ] );
} );

/* ── Course Progress Summary for Card Labels ──────────────────────── */
add_action( 'wp_ajax_glct_get_course_progress_summary', function (): void {
    check_ajax_referer( 'glct_nonce', 'nonce' );
    $gid = (int) ( $_POST['group_id'] ?? 0 );
    if ( ! glct_can_manage( $gid ) ) {
        wp_send_json_error( [ 'message' => 'Permission denied.' ] );
        return;
    }

    $members    = glct_members( $gid );
    $member_ids = array_map( fn( WP_User $u ): int => $u->ID, $members );
    $courses    = function_exists( 'learndash_group_enrolled_courses' )
        ? (array) learndash_group_enrolled_courses( $gid )
        : [];

    $course_ids   = array_map( 'intval', $courses );
    $all_progress = glct_batch_multi_course_progress( $member_ids, $course_ids );

    $summaries = [];
    foreach ( $course_ids as $cid ) {
        $completed = 0;
        foreach ( ( $all_progress[ $cid ] ?? [] ) as $p ) {
            if ( $p['status'] === 'completed' ) $completed++;
        }
        $summaries[ $cid ] = [
            'total'     => count( $member_ids ),
            'completed' => $completed,
        ];
    }

    wp_send_json_success( [ 'summaries' => $summaries ] );
} );

/* ── Set Deadline on a Course ──────────────────────── */
add_action( 'wp_ajax_glct_set_deadline', function (): void {
    check_ajax_referer( 'glct_nonce', 'nonce' );
    $gid  = (int) ( $_POST['group_id']  ?? 0 );
    $cid  = (int) ( $_POST['course_id'] ?? 0 );
    $date = sanitize_text_field( $_POST['deadline'] ?? '' );

    if ( ! glct_can_manage( $gid ) ) {
        wp_send_json_error( [ 'message' => 'Permission denied.' ] );
        return;
    }
    if ( ! glct_course_in_group( $gid, $cid ) ) {
        wp_send_json_error( [ 'message' => 'Course not in group.' ] );
        return;
    }
    if ( get_option( 'glct_allow_deadlines', 'yes' ) !== 'yes' ) {
        wp_send_json_error( [ 'message' => 'Deadlines are disabled.' ] );
        return;
    }

    $meta_key = "glct_deadline_{$cid}";
    if ( empty( $date ) ) {
        delete_post_meta( $gid, $meta_key );
        glct_log_event( 'deadline_cleared', $gid, $cid, 0, false );
        wp_send_json_success( [ 'message' => 'Deadline cleared.' ] );
    } else {
        $dt = DateTime::createFromFormat( 'Y-m-d', $date );
        if ( ! $dt ) {
            wp_send_json_error( [ 'message' => 'Invalid date format.' ] );
            return;
        }
        update_post_meta( $gid, $meta_key, $dt->format( 'Y-m-d' ) );
        glct_log_event( 'deadline_set', $gid, $cid, 0, true );

        // Notify all incomplete learners about the new deadline
        $course_title  = get_the_title( $cid );
        $friendly_date = $dt->format( 'M j, Y' );
        $members       = glct_members( $gid );
        $member_ids    = array_map( fn( WP_User $u ): int => $u->ID, $members );
        $progress      = glct_batch_course_progress( $member_ids, $cid );

        global $wpdb;
        $ntable = $wpdb->prefix . 'glct_notifications';
        $batch  = [];
        $now_str = current_time( 'mysql' );
        foreach ( $progress as $uid => $p ) {
            if ( $p['status'] === 'completed' ) continue;
            $batch[] = $wpdb->prepare(
                '(%d, %s, %d, %d, %s, %s, %s)',
                (int) $uid,
                'deadline',
                $gid,
                $cid,
                "Deadline Set: {$course_title}",
                "A deadline of {$friendly_date} has been set for \"{$course_title}\". Please complete the course before the due date.",
                $now_str
            );
            if ( count( $batch ) >= 100 ) {
                $wpdb->query( "INSERT INTO {$ntable} (user_id, type, group_id, course_id, title, message, created_at) VALUES " . implode( ',', $batch ) );
                $batch = [];
            }
        }
        if ( ! empty( $batch ) ) {
            $wpdb->query( "INSERT INTO {$ntable} (user_id, type, group_id, course_id, title, message, created_at) VALUES " . implode( ',', $batch ) );
        }

        wp_send_json_success( [ 'message' => 'Deadline set to ' . $friendly_date . '.' ] );
    }
} );

/* ── Get All Deadlines for a Group ──────────────────────── */
add_action( 'wp_ajax_glct_get_deadlines', function (): void {
    check_ajax_referer( 'glct_nonce', 'nonce' );
    $gid = (int) ( $_POST['group_id'] ?? 0 );
    if ( ! glct_can_manage( $gid ) ) {
        wp_send_json_error( [ 'message' => 'Permission denied.' ] );
        return;
    }
    $deadlines = glct_get_all_deadlines( $gid );
    $enriched  = [];
    foreach ( $deadlines as $cid => $date ) {
        $status = glct_deadline_status( $date );
        $enriched[ $cid ] = [
            'date'  => $date,
            'label' => $status['label'],
            'class' => $status['class'],
        ];
    }
    wp_send_json_success( [ 'deadlines' => $enriched ] );
} );

/* ── Compliance Report ──────────────────────── */
add_action( 'wp_ajax_glct_get_compliance_report', function (): void {
    check_ajax_referer( 'glct_nonce', 'nonce' );
    $gid = (int) ( $_POST['group_id'] ?? 0 );
    if ( ! glct_can_manage( $gid ) ) {
        wp_send_json_error( [ 'message' => 'Permission denied.' ] );
        return;
    }

    $members      = glct_members( $gid );
    $member_ids   = array_map( fn( WP_User $u ): int => $u->ID, $members );
    $member_count = count( $member_ids );
    $courses      = function_exists( 'learndash_group_enrolled_courses' )
        ? (array) learndash_group_enrolled_courses( $gid )
        : [];
    $course_ids   = array_map( 'intval', $courses );
    $deadlines    = glct_get_all_deadlines( $gid );
    $today        = current_time( 'Y-m-d' );

    // Fetch progress for ALL courses × ALL users in ONE pass (single deserialization per user)
    $all_progress = glct_batch_multi_course_progress( $member_ids, $course_ids );

    $total_possible  = $member_count * count( $course_ids );
    $total_completed = 0;
    $course_stats    = [];
    $overdue_count   = 0;
    $user_total_pct  = []; // Track cumulative completion % per user for at-risk calculation

    foreach ( $course_ids as $course_id ) {
        $course_id = (int) $course_id;
        $progress  = $all_progress[ $course_id ] ?? [];
        $completed = 0;
        $in_progress_ct = 0;
        $not_started_ct = 0;

        foreach ( $progress as $uid => $p ) {
            if ( $p['status'] === 'completed' )   $completed++;
            elseif ( $p['status'] === 'in_progress' ) $in_progress_ct++;
            else $not_started_ct++;

            // Accumulate each user's percentage across all courses
            $user_total_pct[ $uid ] = ( $user_total_pct[ $uid ] ?? 0 ) + $p['percentage'];
        }

        $total_completed += $completed;
        $pct = $member_count > 0 ? (int) round( ( $completed / $member_count ) * 100 ) : 0;

        $deadline   = $deadlines[ $course_id ] ?? null;
        $is_overdue = $deadline && $deadline < $today;

        if ( $is_overdue ) {
            foreach ( $progress as $uid => $p ) {
                if ( $p['status'] !== 'completed' ) $overdue_count++;
            }
        }

        $course_stats[] = [
            'id'          => $course_id,
            'title'       => get_the_title( $course_id ),
            'completed'   => $completed,
            'in_progress' => $in_progress_ct,
            'not_started' => $not_started_ct,
            'pct'         => $pct,
            'deadline'    => $deadline,
            'is_overdue'  => $is_overdue,
        ];
    }

    // Sort by highest completion first (descending)
    usort( $course_stats, fn( $a, $b ) => $b['pct'] <=> $a['pct'] );

    // Build at-risk learners using configurable thresholds
    $at_risk       = [];
    $course_count  = count( $course_ids );
    $at_risk_days  = (int) get_option( 'glct_at_risk_inactive_days', 14 );
    $at_risk_pct   = (int) get_option( 'glct_at_risk_completion_pct', 25 );

    // Batch-fetch user data to eliminate N+1
    $user_data_map = [];
    if ( ! empty( $member_ids ) ) {
        $fetched_users = get_users( [ 'include' => $member_ids, 'fields' => [ 'ID', 'display_name', 'user_email' ] ] );
        foreach ( $fetched_users as $u ) { $user_data_map[ (int) $u->ID ] = $u; }
    }
    // Batch-prime user meta for last activity lookups
    update_meta_cache( 'user', $member_ids );

    foreach ( $member_ids as $uid ) {
        $reasons = [];

        // Condition 1: Inactivity threshold
        if ( $at_risk_days > 0 ) {
            $last_activity = get_user_meta( $uid, 'glct_last_activity', true );
            if ( $last_activity && ( time() - (int) $last_activity ) > ( $at_risk_days * DAY_IN_SECONDS ) ) {
                $reasons[] = 'Inactive ' . human_time_diff( (int) $last_activity );
            } elseif ( ! $last_activity ) {
                $reasons[] = 'Never logged in';
            }
        }

        // Condition 2: Average completion below threshold
        if ( $at_risk_pct > 0 && $course_count > 0 ) {
            $avg = ( $user_total_pct[ $uid ] ?? 0 ) / $course_count;
            if ( $avg < $at_risk_pct ) {
                $reasons[] = (int) round( $avg ) . '% avg completion';
            }
        }

        if ( ! empty( $reasons ) ) {
            $u = $user_data_map[ $uid ] ?? null;
            if ( ! $u ) continue;
            $last_act = get_user_meta( $uid, 'glct_last_activity', true );
            $at_risk[] = [
                'id'          => $uid,
                'name'        => $u->display_name,
                'email'       => $u->user_email,
                'reason'      => implode( ' · ', $reasons ),
                'last_active' => $last_act ? human_time_diff( (int) $last_act ) . ' ago' : 'Never',
            ];
        }
    }

    $overall_pct = $total_possible > 0 ? (int) round( ( $total_completed / $total_possible ) * 100 ) : 0;
    $per_page    = (int) get_option( 'glct_compliance_per_page', 8 );

    ob_start();
    glct_render_compliance_html( $overall_pct, $member_count, $course_count, $overdue_count, $course_stats, $at_risk, $per_page, $at_risk_days, $at_risk_pct );
    $html = ob_get_clean();

    wp_send_json_success( [ 'html' => $html, 'overall_pct' => $overall_pct ] );
} );

/* ── Compliance CSV Export ──────────────────────── */
add_action( 'wp_ajax_glct_export_compliance_csv', function (): void {
    check_ajax_referer( 'glct_nonce', 'nonce' );
    $gid = (int) ( $_GET['group_id'] ?? 0 );
    if ( ! glct_can_manage( $gid ) ) {
        wp_die( 'Permission denied.' );
    }

    $group_title = sanitize_file_name( get_the_title( $gid ) );
    nocache_headers();
    header( 'Content-Type: text/csv; charset=utf-8' );
    header( "Content-Disposition: attachment; filename=compliance-{$group_title}-" . gmdate( 'Y-m-d' ) . ".csv" );

    $output    = fopen( 'php://output', 'w' );
    $members   = glct_members( $gid );
    $courses   = function_exists( 'learndash_group_enrolled_courses' )
        ? (array) learndash_group_enrolled_courses( $gid )
        : [];
    $course_ids = array_map( 'intval', $courses );
    $deadlines  = glct_get_all_deadlines( $gid );

    // Build header row
    $header = [ 'Learner Name', 'Email' ];
    $course_titles = [];
    foreach ( $course_ids as $cid ) {
        $title = get_the_title( $cid );
        $course_titles[ $cid ] = $title;
        $header[] = $title . ' (%)';
        $header[] = $title . ' (Status)';
        if ( isset( $deadlines[ $cid ] ) ) {
            $header[] = $title . ' (Deadline)';
        }
    }
    $header[] = 'Overall %';
    fputcsv( $output, $header );

    // Batch-fetch progress for ALL courses × ALL users in one pass
    $member_ids   = array_map( fn( WP_User $u ): int => $u->ID, $members );
    $all_progress = glct_batch_multi_course_progress( $member_ids, $course_ids );

    // Write data rows
    foreach ( $members as $u ) {
        $row = [ $u->display_name, $u->user_email ];
        $total_pct = 0;
        foreach ( $course_ids as $cid ) {
            $p   = $all_progress[ $cid ][ $u->ID ] ?? [ 'percentage' => 0, 'status' => 'not_started' ];
            $row[] = $p['percentage'];
            $row[] = ucfirst( str_replace( '_', ' ', $p['status'] ) );
            if ( isset( $deadlines[ $cid ] ) ) {
                $row[] = $deadlines[ $cid ];
            }
            $total_pct += $p['percentage'];
        }
        $course_count = count( $course_ids );
        $row[] = $course_count > 0 ? (int) round( $total_pct / $course_count ) : 0;
        fputcsv( $output, $row );
    }

    fclose( $output );
    exit;
} );

add_action( 'wp_ajax_glct_global_user_search', function (): void {
    check_ajax_referer( 'glct_nonce', 'nonce' );
    $term = sanitize_text_field( $_POST['term'] ?? '' );
    if ( strlen( $term ) < 2 ) {
        wp_send_json_success( [ 'users' => [] ] );
    }

    $my_groups = glct_my_groups( get_current_user_id() );
    if ( empty( $my_groups ) ) {
        wp_send_json_success( [ 'users' => [] ] );
    }
    
    $my_gids = array_map( fn($g) => $g->ID, $my_groups );
    $u_query = new WP_User_Query([
        'search'         => "*{$term}*",
        'search_columns' => ['user_login', 'user_email', 'display_name'],
        'number'         => 30
    ]);

    $results = [];
    foreach ( $u_query->get_results() as $u ) {
        $u_gids = function_exists( 'learndash_get_users_group_ids' ) ? (array) learndash_get_users_group_ids( $u->ID ) : [];
        if ( array_intersect( $u_gids, $my_gids ) ) {
            $results[] = [ 'id' => $u->ID, 'name' => $u->display_name, 'email' => $u->user_email ];
        }
    }
    wp_send_json_success( [ 'users' => $results ] );
} );

add_action( 'wp_ajax_glct_global_user_profile', function (): void {
    check_ajax_referer( 'glct_nonce', 'nonce' );
    $uid = (int) ( $_POST['user_id'] ?? 0 );
    $u = get_userdata( $uid );
    if ( ! $u ) wp_send_json_error( [ 'message' => 'User not found.' ] );

    $my_gids = array_map( fn($g) => $g->ID, glct_my_groups( get_current_user_id() ) );
    $u_gids = function_exists( 'learndash_get_users_group_ids' ) ? (array) learndash_get_users_group_ids( $uid ) : [];
    $shared_gids = array_intersect( $u_gids, $my_gids );

    if ( empty( $shared_gids ) ) {
        wp_send_json_error( [ 'message' => 'User is not in any of your managed groups.' ] );
    }
    
    $allow_wipe = get_option('glct_allow_wipe', 'yes') === 'yes';

    $html = '';
    foreach ( $shared_gids as $gid ) {
        $group_title = get_the_title( $gid );
        $courses = glct_all_courses( $gid );
        
        if ( empty( $courses ) ) continue;

        $html .= "<div style='margin-bottom:24px;'>";
        $html .= "<h4 style='font-size:1rem; font-weight:700; color:var(--ink); margin-bottom:12px; padding-bottom:8px; border-bottom:1px solid var(--border);'>" . esc_html( $group_title ) . "</h4>";
        $html .= "<table class='glct-table'><thead><tr><th>Course</th><th style='width:140px; text-align:center;'>Access</th></tr></thead><tbody>";
        
        foreach ( $courses as $c ) {
            $is_group_on = glct_is_enabled( $gid, $c->ID );
            $blocked = glct_is_user_blocked( $gid, $c->ID, $uid );
            $force_on = get_user_meta( $uid, "glct_force_on_{$gid}_{$c->ID}", true ) === '1';
            $enabled = $is_group_on ? ! $blocked : $force_on;
            $checked = $enabled ? 'checked' : '';
            
            $wipe_btn = $allow_wipe ? "<button class='glct-wipe-btn' data-uid='{$uid}' data-gid='{$gid}' data-cid='{$c->ID}' title='Wipe Course Progress'><svg width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'><path d='M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8'></path><path d='M3 3v5h5'></path></svg></button>" : "";

            $html .= "<tr>";
            $html .= "<td><span style='font-weight:600; color:var(--ink); font-size:.9rem;'>" . esc_html( $c->post_title ) . "</span></td>";
            $html .= "<td style='text-align:center; vertical-align:middle;'>
                        <div style='display:inline-flex; align-items:center; justify-content:center;'>
                            <label class='glct-toggle' style='margin:0;'>
                                <input type='checkbox' class='glct-toggle-inp glct-gu-toggle' data-uid='{$uid}' data-gid='{$gid}' data-cid='{$c->ID}' {$checked}>
                                <span class='glct-track'><span class='glct-thumb'></span></span>
                            </label>
                            {$wipe_btn}
                        </div>
                      </td>";
            $html .= "</tr>";
        }
        $html .= "</tbody></table></div>";
    }
    
    wp_send_json_success( [ 'html' => $html, 'name' => $u->display_name, 'email' => $u->user_email ] );
} );

add_action( 'wp_ajax_glct_wipe_progress', function (): void {
    check_ajax_referer( 'glct_nonce', 'nonce' );
    
    if ( get_option('glct_allow_wipe', 'yes') !== 'yes' ) {
        wp_send_json_error( [ 'message' => 'Progress wiping is disabled by Site Admin.' ] );
        return;
    }
    
    $gid = (int) ( $_POST['group_id'] ?? 0 );
    $cid = (int) ( $_POST['course_id'] ?? 0 );
    $uid = (int) ( $_POST['user_id'] ?? 0 );

    if ( ! glct_can_manage( $gid ) ) {
        wp_send_json_error( [ 'message' => 'Permission denied.' ] );
        return;
    }

    /* Security: verify user is actually a member of this group */
    $member_ids = array_map( fn( WP_User $u ): int => $u->ID, glct_members( $gid ) );
    if ( ! in_array( $uid, $member_ids, true ) ) {
        wp_send_json_error( [ 'message' => 'User is not a member of this group.' ] );
        return;
    }

    /* Security: verify course belongs to this group */
    if ( ! glct_course_in_group( $gid, $cid ) ) {
        wp_send_json_error( [ 'message' => 'Course does not belong to this group.' ] );
        return;
    }

    glct_wipe_course_progress( $uid, $cid );
    glct_log_event( 'user_wipe', $gid, $cid, $uid, false );
    wp_send_json_success( [ 'message' => 'User progress completely wiped.' ] );
} );

add_action( 'wp_ajax_glct_get_audit_log', function (): void {
    check_ajax_referer( 'glct_nonce', 'nonce' );

    $uid = get_current_user_id();
    $groups = glct_my_groups( $uid );
    if ( empty( $groups ) ) {
        wp_send_json_error( [ 'html' => '<p>No managed groups.</p>' ] );
        return;
    }

    $gids = array_map( fn($g) => $g->ID, $groups );
    $gids_list = implode( ',', array_map( 'intval', $gids ) );

    global $wpdb;
    $table_name = $wpdb->prefix . 'glct_audit_log';
    
    $query = "SELECT * FROM {$table_name} WHERE group_id IN ({$gids_list}) ORDER BY timestamp DESC LIMIT 40";
    $logs = $wpdb->get_results( $query );

    if ( empty( $logs ) ) {
        wp_send_json_success( [ 'html' => '<p style="padding:14px 0;color:#94a3b8">No recent activity.</p>' ] );
        return;
    }

    // Pre-fetch all referenced users in one query to eliminate N+1
    $user_ids = [];
    foreach ( $logs as $log ) {
        if ( $log->user_id ) $user_ids[] = (int) $log->user_id;
    }
    $user_map = [];
    if ( ! empty( $user_ids ) ) {
        $fetched = get_users( [ 'include' => array_unique( $user_ids ), 'fields' => [ 'ID', 'display_name' ] ] );
        foreach ( $fetched as $u ) { $user_map[ $u->ID ] = $u->display_name; }
    }

    // Pre-fetch all referenced post titles (courses, groups) to eliminate N+1
    $post_ids = [];
    foreach ( $logs as $log ) {
        if ( $log->course_id ) $post_ids[] = (int) $log->course_id;
        if ( $log->group_id )  $post_ids[] = (int) $log->group_id;
    }
    $title_map = [];
    if ( ! empty( $post_ids ) ) {
        _prime_post_caches( array_unique( $post_ids ), false, false );
        foreach ( array_unique( $post_ids ) as $pid ) {
            $title_map[ $pid ] = get_the_title( $pid ) ?: '';
        }
    }

    $html = '<table class="glct-table"><thead><tr>'
          . '<th>Time</th><th>Action</th><th>Activity</th><th>State</th>'
          . '</tr></thead><tbody>';

    foreach ( $logs as $log ) {
        $time = date_i18n( get_option( 'date_format' ) . ' g:ia', strtotime( $log->timestamp ) );

        // Action description
        $action_desc = $log->action;
        if ($log->action === 'group')          $action_desc = 'Group Default';
        if ($log->action === 'user')           $action_desc = 'User Override';
        if ($log->action === 'course_removed') $action_desc = 'Course Removed';
        if ($log->action === 'course_added')   $action_desc = 'Course Added';
        if ( strpos($log->action, 'wipe') !== false ) $action_desc = 'Progress Wiped';
        if ($log->action === 'learner_read')      $action_desc = 'Notification Viewed';
        if ($log->action === 'learner_read_all')  $action_desc = 'All Notifications Read';
        if ($log->action === 'learner_dismissed') $action_desc = 'Popup Dismissed';
        if ($log->action === 'learner_welcomed')  $action_desc = 'Update Acknowledged';
        if ($log->action === 'user_inactive')     $action_desc = 'Inactive Member';
        if ($log->action === 'deadline_set')      $action_desc = 'Deadline Set';
        if ($log->action === 'deadline_cleared')  $action_desc = 'Deadline Cleared';
        if ($log->action === 'deadline_remind')   $action_desc = 'Deadline Reminder';
        if ($log->action === 'deadline_overdue')  $action_desc = 'Deadline Overdue';

        $system_actions = [ 'user_inactive', 'deadline_overdue', 'deadline_remind' ];
        if ( $log->user_id && strpos($log->action, 'learner_') !== 0 && ! in_array( $log->action, $system_actions, true ) ) {
            $action_desc = isset( $user_map[ $log->user_id ] ) ? 'User: ' . $user_map[ $log->user_id ] : 'Deleted User';
        } elseif ( $log->user_id && ( strpos($log->action, 'learner_') === 0 || in_array( $log->action, $system_actions, true ) ) ) {
            $action_desc .= isset( $user_map[ $log->user_id ] ) ? ' — ' . $user_map[ $log->user_id ] : '';
        }

        // Activity description (uses pre-fetched title_map to avoid N+1)
        $activity_desc = '';
        $ctitle = $log->course_id ? esc_html( $title_map[ (int) $log->course_id ] ?? '' ) : '';
        if ( $log->action === 'learner_read' ) {
            $activity_desc = $ctitle ? $ctitle . ' — Acknowledged' : 'Notification Acknowledged';
        } elseif ( $log->action === 'learner_read_all' ) {
            $activity_desc = 'All Alerts Acknowledged';
        } elseif ( $log->action === 'learner_dismissed' ) {
            $activity_desc = 'Popup Dismissed';
        } elseif ( $log->action === 'learner_welcomed' ) {
            $activity_desc = 'Update Acknowledged';
        } elseif ( $log->action === 'user_inactive' ) {
            $last = get_user_meta( $log->user_id, 'glct_last_activity', true );
            $days = $last ? floor( ( time() - (int) $last ) / DAY_IN_SECONDS ) : '?';
            $activity_desc = 'Inactive — ' . $days . ' days';
        } elseif ( $log->action === 'deadline_set' || $log->action === 'deadline_cleared' ) {
            $activity_desc = $ctitle ? $ctitle . ' — ' . ucfirst( str_replace( 'deadline_', '', $log->action ) ) : ucfirst( str_replace( 'deadline_', '', $log->action ) );
        } elseif ( $log->action === 'deadline_remind' ) {
            $activity_desc = $ctitle ? $ctitle . ' — Reminders Sent' : 'Reminders Sent';
        } elseif ( $log->action === 'deadline_overdue' ) {
            $activity_desc = $ctitle ? $ctitle . ' — Overdue' : 'Overdue';
        } elseif ( strpos( $log->action, 'wipe' ) !== false ) {
            $activity_desc = $ctitle ? $ctitle . ' — Progress Reset' : 'Progress Reset';
        } elseif ( $log->action === 'course_removed' || $log->action === 'course_added' ) {
            $activity_desc = $ctitle ?: 'Course';
        } elseif ( $log->action === 'group' || $log->action === 'user' ) {
            $activity_desc = $ctitle ?: 'Group Setting';
        } else {
            $activity_desc = $ctitle ?: '—';
        }

        // State badges
        if ( strpos($log->action, 'wipe') !== false ) {
            $state_badge = '<span class="glct-badge" style="font-size:10px; background:#f2f4f8; color:#4a5876; border-color:#c5cfe4;">Wiped</span>';
        } elseif ( $log->action === 'course_removed' ) {
            $state_badge = '<span class="glct-badge" style="font-size:10px; background:#fff4f3; color:#c8332a; border-color:#f9b2ae;">Removed</span>';
        } elseif ( $log->action === 'course_added' ) {
            $state_badge = '<span class="glct-badge" style="font-size:10px; background:#eafaf4; color:#0b7d5c; border-color:#6dcfab;">Added</span>';
        } elseif ( $log->action === 'learner_read' || $log->action === 'learner_read_all' || $log->action === 'learner_welcomed' ) {
            $state_badge = '<span class="glct-badge" style="font-size:10px; background:#eef2ff; color:#3d63dd; border-color:#afc2ff;">Complete</span>';
        } elseif ( $log->action === 'learner_dismissed' ) {
            $state_badge = '<span class="glct-badge" style="font-size:10px; background:#eef2ff; color:#3d63dd; border-color:#afc2ff;">Dismissed</span>';
        } elseif ( $log->action === 'user_inactive' ) {
            $state_badge = '<span class="glct-badge" style="font-size:10px; background:#fef3c7; color:#b45309; border-color:#fcd34d;">Inactive</span>';
        } elseif ( $log->action === 'deadline_overdue' ) {
            $state_badge = '<span class="glct-badge" style="font-size:10px; background:#fff4f3; color:#c8332a; border-color:#f9b2ae;">Overdue</span>';
        } elseif ( strpos($log->action, 'deadline_') === 0 ) {
            $state_badge = '<span class="glct-badge" style="font-size:10px; background:#eef2ff; color:#3d63dd; border-color:#afc2ff;">' . esc_html( ucfirst( str_replace('deadline_', '', $log->action) ) ) . '</span>';
        } else {
            $state_badge = $log->state
                ? '<span class="glct-badge glct-badge--on" style="font-size:10px;">Enabled</span>'
                : '<span class="glct-badge glct-badge--off" style="font-size:10px; background:#fff4f3; color:#c8332a; border-color:#f9b2ae;">Disabled</span>';
        }

        $html .= '<tr>'
               . "<td><span style='font-size:12px; color:#4a5876;'>" . esc_html( $time ) . "</span></td>"
               . "<td><span style='font-size:13px; font-weight:600;'>" . esc_html( $action_desc ) . "</span></td>"
               . "<td><span style='font-size:13px;'>" . $activity_desc . "</span></td>"
               . "<td>{$state_badge}</td>"
               . '</tr>';
    }
    $html .= '</tbody></table>';

    wp_send_json_success( [ 'html' => $html ] );
} );

// GL Activity Log CSV Export
add_action( 'wp_ajax_glct_export_gl_csv', function (): void {
    check_ajax_referer( 'glct_nonce', 'nonce' );

    $uid    = get_current_user_id();
    $groups = glct_my_groups( $uid );
    if ( empty( $groups ) ) { wp_die( 'No managed groups.' ); }

    $gids      = array_map( fn($g) => $g->ID, $groups );
    $gids_list = implode( ',', array_map( 'intval', $gids ) );

    global $wpdb;
    $table = $wpdb->prefix . 'glct_audit_log';
    $logs  = $wpdb->get_results( "SELECT * FROM {$table} WHERE group_id IN ({$gids_list}) ORDER BY timestamp DESC LIMIT 500" );

    // Pre-fetch all referenced users in one query to eliminate N+1
    $user_ids = [];
    foreach ( $logs as $log ) {
        if ( $log->user_id ) $user_ids[] = (int) $log->user_id;
    }
    $user_map = [];
    if ( ! empty( $user_ids ) ) {
        $fetched = get_users( [ 'include' => array_unique( $user_ids ), 'fields' => [ 'ID', 'display_name' ] ] );
        foreach ( $fetched as $u ) { $user_map[ $u->ID ] = $u->display_name; }
    }

    // Pre-fetch all referenced post titles to eliminate N+1
    $post_ids = [];
    foreach ( $logs as $log ) {
        if ( $log->course_id ) $post_ids[] = (int) $log->course_id;
        if ( $log->group_id )  $post_ids[] = (int) $log->group_id;
    }
    $csv_title_map = [];
    if ( ! empty( $post_ids ) ) {
        _prime_post_caches( array_unique( $post_ids ), false, false );
        foreach ( array_unique( $post_ids ) as $pid ) {
            $csv_title_map[ $pid ] = get_the_title( $pid ) ?: '';
        }
    }

    nocache_headers();
    header( 'Content-Type: text/csv; charset=utf-8' );
    header( 'Content-Disposition: attachment; filename=activity_log_' . gmdate( 'Y-m-d' ) . '.csv' );
    $out = fopen( 'php://output', 'w' );

    fputcsv( $out, [ 'Date', 'Action', 'Activity', 'Group', 'User', 'State' ] );

    foreach ( $logs as $log ) {
        $group = ( $csv_title_map[ (int) $log->group_id ] ?? '' ) ?: 'Deleted Group';
        $user  = $log->user_id ? ( $user_map[ $log->user_id ] ?? 'Deleted User' ) : '—';
        $ctitle = $csv_title_map[ (int) $log->course_id ] ?? '';

        // Action label
        $action_label = $log->action;
        if ( $log->action === 'group' )          $action_label = 'Group Default';
        if ( $log->action === 'user' )           $action_label = 'User Override';
        if ( $log->action === 'course_removed' ) $action_label = 'Course Removed';
        if ( $log->action === 'course_added' )   $action_label = 'Course Added';
        if ( strpos( $log->action, 'wipe' ) !== false ) $action_label = 'Progress Wiped';
        if ( $log->action === 'learner_read' )      $action_label = 'Notification Viewed';
        if ( $log->action === 'learner_read_all' )  $action_label = 'All Notifications Read';
        if ( $log->action === 'learner_dismissed' ) $action_label = 'Popup Dismissed';
        if ( $log->action === 'learner_welcomed' )  $action_label = 'Update Acknowledged';
        if ( $log->action === 'user_inactive' )     $action_label = 'Inactive Member';
        if ( $log->action === 'deadline_set' )      $action_label = 'Deadline Set';
        if ( $log->action === 'deadline_cleared' )  $action_label = 'Deadline Cleared';
        if ( $log->action === 'deadline_remind' )   $action_label = 'Deadline Reminder';
        if ( $log->action === 'deadline_overdue' )  $action_label = 'Deadline Overdue';

        // Activity description (uses pre-fetched titles)
        $activity = '';
        if ( $log->action === 'learner_read' ) {
            $activity = $ctitle ? $ctitle . ' — Acknowledged' : 'Notification Acknowledged';
        } elseif ( $log->action === 'learner_read_all' ) {
            $activity = 'All Alerts Acknowledged';
        } elseif ( $log->action === 'learner_dismissed' ) {
            $activity = 'Popup Dismissed';
        } elseif ( $log->action === 'learner_welcomed' ) {
            $activity = 'Update Acknowledged';
        } elseif ( $log->action === 'user_inactive' ) {
            $last = get_user_meta( $log->user_id, 'glct_last_activity', true );
            $days = $last ? floor( ( time() - (int) $last ) / DAY_IN_SECONDS ) : '?';
            $activity = 'Inactive — ' . $days . ' days';
        } elseif ( $log->action === 'deadline_set' || $log->action === 'deadline_cleared' ) {
            $activity = $ctitle ? $ctitle . ' — ' . ucfirst( str_replace( 'deadline_', '', $log->action ) ) : ucfirst( str_replace( 'deadline_', '', $log->action ) );
        } elseif ( $log->action === 'deadline_remind' ) {
            $activity = $ctitle ? $ctitle . ' — Reminders Sent' : 'Reminders Sent';
        } elseif ( $log->action === 'deadline_overdue' ) {
            $activity = $ctitle ? $ctitle . ' — Overdue' : 'Overdue';
        } elseif ( strpos( $log->action, 'wipe' ) !== false ) {
            $activity = $ctitle ? $ctitle . ' — Progress Reset' : 'Progress Reset';
        } elseif ( $log->course_id ) {
            $activity = $ctitle ?: 'Course';
        } else {
            $activity = 'Group Setting';
        }

        // State
        $state = $log->state ? 'Enabled' : 'Disabled';
        if ( strpos( $log->action, 'wipe' ) !== false )                                                                           $state = 'Wiped';
        if ( $log->action === 'course_removed' )                                                                                   $state = 'Removed';
        if ( $log->action === 'course_added' )                                                                                     $state = 'Added';
        if ( $log->action === 'learner_read' || $log->action === 'learner_read_all' || $log->action === 'learner_welcomed' )       $state = 'Complete';
        if ( $log->action === 'learner_dismissed' )                                                                                $state = 'Dismissed';
        if ( $log->action === 'user_inactive' )                                                                                    $state = 'Inactive';
        if ( $log->action === 'deadline_set' )                                                                                     $state = 'Set';
        if ( $log->action === 'deadline_cleared' )                                                                                 $state = 'Cleared';
        if ( $log->action === 'deadline_remind' )                                                                                  $state = 'Sent';
        if ( $log->action === 'deadline_overdue' )                                                                                 $state = 'Overdue';

        fputcsv( $out, [ $log->timestamp, $action_label, $activity, $group, $user, $state ] );
    }
    fclose( $out );
    exit;
} );

add_action( 'wp_ajax_glct_send_notify', function (): void {
    check_ajax_referer( 'glct_nonce', 'nonce' );

    if ( get_option('glct_allow_email', 'yes') !== 'yes' ) {
        wp_send_json_error( [ 'message' => 'Email feature disabled by Site Admin.' ] );
        return;
    }

    $gid     = (int) ( $_POST['group_id'] ?? 0 );
    $subject = sanitize_text_field( wp_unslash( $_POST['subject'] ?? '' ) );
    $message = wp_kses_post( wp_unslash( $_POST['message'] ?? '' ) );

    if ( ! glct_can_manage( $gid ) ) {
        wp_send_json_error( [ 'message' => 'Permission denied.' ] );
        return;
    }

    $raw_ids = json_decode( wp_unslash( $_POST['user_ids'] ?? '[]' ), true );
    if ( ! is_array( $raw_ids ) || empty( $raw_ids ) ) {
        wp_send_json_error( [ 'message' => 'No recipients selected.' ] );
        return;
    }

    $member_ids = array_map( fn( WP_User $u ): int => $u->ID, glct_members( $gid ) );
    $valid_ids  = array_intersect( array_map( 'intval', $raw_ids ), $member_ids );

    if ( empty( $valid_ids ) ) {
        wp_send_json_error( [ 'message' => 'None of the selected recipients are group members.' ] );
        return;
    }

    $current_user = wp_get_current_user();
    $from_name    = trim( $current_user->display_name ) ?: 'Group Leader';
    $from_email   = $current_user->user_email ?: get_option( 'admin_email' );
    $headers      = [
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . $from_name . ' <' . $from_email . '>',
    ];

    $course_id   = (int) ( $_POST['course_id'] ?? 0 );
    $course_name = $course_id ? get_the_title( $course_id ) : '';
    $sent        = 0;

    foreach ( $valid_ids as $uid ) {
        $user = get_userdata( $uid );
        if ( ! $user instanceof WP_User ) continue;

        $body = str_replace(
            [ '{name}', '{first_name}', '{last_name}', '{course_name}' ],
            [ $user->display_name, $user->first_name, $user->last_name, $course_name ],
            $message
        );
        if ( wp_mail( $user->user_email, $subject, nl2br( $body ), $headers ) ) {
            $sent++;
            glct_create_notification( 'email_sent', $uid, $gid, $course_id,
                'Email: ' . $subject,
                $body
            );
        }
    }

    wp_send_json_success( [ 'message' => "Email sent to {$sent} of " . count( $valid_ids ) . ' recipient(s).' ] );
} );

// ── Course Activity Feed ─────────────────────────────────────────────────
add_action( 'wp_ajax_glct_get_course_activity', function (): void {
    check_ajax_referer( 'glct_nonce', 'nonce' );
    $gid = (int) ( $_POST['group_id']  ?? 0 );
    $cid = (int) ( $_POST['course_id'] ?? 0 );

    if ( ! glct_can_manage( $gid ) ) {
        wp_send_json_error( [ 'message' => 'Permission denied.' ] );
        return;
    }

    global $wpdb;
    $table = $wpdb->prefix . 'glct_audit_log';
    $logs  = $wpdb->get_results( $wpdb->prepare(
        "SELECT * FROM {$table} WHERE group_id = %d AND (course_id = %d OR course_id = 0) ORDER BY timestamp DESC LIMIT 20",
        $gid, $cid
    ) );

    if ( empty( $logs ) ) {
        wp_send_json_success( [ 'html' => '<p style="padding:10px 0;color:var(--ink4);font-size:.85rem;">No recent activity for this course.</p>' ] );
        return;
    }

    // Pre-fetch all referenced users in one query to eliminate N+1
    $user_ids = [];
    foreach ( $logs as $log ) {
        if ( $log->leader_id ) $user_ids[] = (int) $log->leader_id;
        if ( $log->user_id )   $user_ids[] = (int) $log->user_id;
    }
    $user_map = [];
    if ( ! empty( $user_ids ) ) {
        $fetched = get_users( [ 'include' => array_unique( $user_ids ), 'fields' => [ 'ID', 'display_name' ] ] );
        foreach ( $fetched as $u ) { $user_map[ $u->ID ] = $u->display_name; }
    }

    // Pre-fetch post titles for course references
    $ca_post_ids = [];
    foreach ( $logs as $log ) {
        if ( $log->course_id ) $ca_post_ids[] = (int) $log->course_id;
    }
    $ca_title_map = [];
    if ( ! empty( $ca_post_ids ) ) {
        _prime_post_caches( array_unique( $ca_post_ids ), false, false );
        foreach ( array_unique( $ca_post_ids ) as $_pid ) {
            $ca_title_map[ $_pid ] = get_the_title( $_pid ) ?: '';
        }
    }

    $html = '<div class="glct-activity-list">';
    foreach ( $logs as $log ) {
        $time   = human_time_diff( strtotime( $log->timestamp ), time() ) . ' ago';
        $leader = $log->leader_id ? ( $user_map[ $log->leader_id ] ?? 'Unknown' ) : 'System';
        $uname  = $log->user_id ? esc_html( $user_map[ $log->user_id ] ?? 'Unknown' ) : 'Unknown';

        $desc = $log->action;
        if ( $log->action === 'group' )          $desc = $log->state ? 'Enabled for group' : 'Disabled for group';
        if ( $log->action === 'user' )           {
            $desc = ( $log->state ? 'Enabled' : 'Disabled' ) . ' for ' . $uname;
        }
        if ( strpos( $log->action, 'wipe' ) !== false ) {
            $desc = 'Progress wiped' . ( $log->user_id ? ' for ' . $uname : '' );
        }
        if ( $log->action === 'course_removed' ) $desc = 'Course removed from group';
        if ( $log->action === 'course_added' )   $desc = 'Course added to group';
        // Learner accountability actions
        if ( $log->action === 'learner_read' ) {
            $ctitle = $log->course_id ? esc_html( $ca_title_map[ (int) $log->course_id ] ?? '' ) : '';
            $desc = $uname . ' viewed' . ( $ctitle ? ': ' . $ctitle . ' notification' : ' a notification' );
        }
        if ( $log->action === 'learner_read_all' ) {
            $desc = $uname . ' marked all notifications read';
        }
        if ( $log->action === 'learner_dismissed' ) {
            $desc = $uname . ' dismissed notification popup';
        }
        if ( $log->action === 'learner_welcomed' ) {
            $desc = $uname . ' acknowledged update';
        }
        if ( $log->action === 'user_inactive' ) {
            $last = get_user_meta( $log->user_id, 'glct_last_activity', true );
            $days = $last ? floor( ( time() - (int) $last ) / DAY_IN_SECONDS ) : '?';
            $desc = $uname . ' has not accessed training in ' . $days . ' days';
        }

        $icon = $log->state ? '🟢' : '🔴';
        if ( strpos( $log->action, 'wipe' ) !== false )  $icon = '🔄';
        if ( $log->action === 'course_added' )            $icon = '➕';
        if ( $log->action === 'learner_read' )            $icon = '👁';
        if ( $log->action === 'learner_read_all' )        $icon = '✅';
        if ( $log->action === 'learner_dismissed' )       $icon = '🔕';
        if ( $log->action === 'learner_welcomed' )        $icon = '👋';
        if ( $log->action === 'user_inactive' )           $icon = '⚠️';

        // For learner actions, show the learner's name instead of "by System"
        if ( strpos( $log->action, 'learner_' ) === 0 || $log->action === 'user_inactive' ) {
            $leader = $log->user_id ? ( $user_map[ $log->user_id ] ?? 'Unknown' ) : 'System';
        }

        $html .= '<div class="glct-activity-item">'
               . '<span class="glct-activity-ico">' . $icon . '</span>'
               . '<div class="glct-activity-content">'
               . '<span class="glct-activity-desc">' . $desc . '</span>'
               . '<span class="glct-activity-meta">by ' . esc_html( $leader ) . ' &middot; ' . esc_html( $time ) . '</span>'
               . '</div></div>';
    }
    $html .= '</div>';

    wp_send_json_success( [ 'html' => $html ] );
} );

// ── Course Tag Assignment ────────────────────────────────────────────────
add_action( 'wp_ajax_glct_set_course_tag', function (): void {
    check_ajax_referer( 'glct_nonce', 'nonce' );
    $gid = (int) ( $_POST['group_id']  ?? 0 );
    $cid = (int) ( $_POST['course_id'] ?? 0 );
    $tag = sanitize_text_field( wp_unslash( $_POST['tag'] ?? '' ) );

    if ( ! glct_can_manage( $gid ) ) {
        wp_send_json_error( [ 'message' => 'Permission denied.' ] );
        return;
    }

    if ( ! glct_course_in_group( $gid, $cid ) ) {
        wp_send_json_error( [ 'message' => 'Course does not belong to this group.' ] );
        return;
    }

    $available = array_map( 'trim', explode( ',', get_option( 'glct_available_tags', 'Onboarding, Advanced, Compliance, Optional' ) ) );
    $tags = glct_get_course_tags( $gid );

    if ( $tag === '' || $tag === '__none__' ) {
        unset( $tags[ $cid ] );
    } elseif ( in_array( $tag, $available, true ) ) {
        $tags[ $cid ] = $tag;
    } else {
        wp_send_json_error( [ 'message' => 'Invalid tag.' ] );
        return;
    }

    update_post_meta( $gid, 'glct_course_tags', $tags );
    wp_send_json_success( [ 'message' => 'Tag updated.', 'tag' => $tag === '__none__' ? '' : $tag ] );
} );

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 7B — COURSE EXPANSION AJAX
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Returns courses that match the group's expansion tags but aren't yet in the group.
 * Optionally filter by a specific tag slug.
 */
add_action( 'wp_ajax_glct_get_expansion_courses', function (): void {
    check_ajax_referer( 'glct_nonce', 'nonce' );

    if ( get_option( 'glct_allow_expansion', 'no' ) !== 'yes' ) {
        wp_send_json_error( [ 'message' => 'Course expansion is disabled.' ] );
        return;
    }

    $gid = (int) ( $_POST['group_id'] ?? 0 );
    $filter_tag = sanitize_text_field( wp_unslash( $_POST['filter_tag'] ?? '' ) );

    if ( ! glct_can_manage( $gid ) ) {
        wp_send_json_error( [ 'message' => 'Permission denied.' ] );
        return;
    }

    $expansion_tags = (array) get_post_meta( $gid, 'glct_expansion_tags', true );
    $expansion_tags = array_filter( array_map( 'intval', $expansion_tags ) );

    if ( empty( $expansion_tags ) ) {
        wp_send_json_success( [ 'courses' => [], 'tags' => [], 'message' => 'No expansion tags configured for this group.' ] );
        return;
    }

    // Get the tag names for filter UI
    $tag_terms = get_terms( [
        'taxonomy'   => 'ld_course_tag',
        'include'    => $expansion_tags,
        'hide_empty' => false,
    ] );
    $tag_names = [];
    $query_tags = $expansion_tags;
    if ( ! is_wp_error( $tag_terms ) ) {
        foreach ( $tag_terms as $t ) {
            $tag_names[] = [ 'id' => $t->term_id, 'name' => $t->name, 'slug' => $t->slug ];
        }
        // If filter_tag is set, only query that tag
        if ( $filter_tag ) {
            foreach ( $tag_terms as $t ) {
                if ( $t->slug === $filter_tag ) {
                    $query_tags = [ $t->term_id ];
                    break;
                }
            }
        }
    }

    // Get courses already in this group
    $existing = array_filter( array_map( 'intval',
        (array) get_post_meta( $gid, 'glct_master_courses', true )
    ) );
    $ld_enrolled = function_exists( 'learndash_group_enrolled_courses' )
        ? array_map( 'intval', (array) learndash_group_enrolled_courses( $gid ) )
        : [];
    $group_courses = array_unique( array_merge( $existing, $ld_enrolled ) );

    // Query courses matching expansion tags
    $args = [
        'post_type'      => 'sfwd-courses',
        'posts_per_page' => 50,
        'post_status'    => 'publish',
        'post__not_in'   => ! empty( $group_courses ) ? $group_courses : [ 0 ],
        'tax_query'      => [
            [
                'taxonomy' => 'ld_course_tag',
                'field'    => 'term_id',
                'terms'    => $query_tags,
            ],
        ],
        'orderby' => 'title',
        'order'   => 'ASC',
    ];
    $posts = get_posts( $args );

    $courses = [];
    foreach ( $posts as $p ) {
        $course_tags = wp_get_post_terms( $p->ID, 'ld_course_tag', [ 'fields' => 'names' ] );
        $courses[] = [
            'id'    => $p->ID,
            'title' => $p->post_title,
            'tags'  => is_wp_error( $course_tags ) ? [] : $course_tags,
        ];
    }

    wp_send_json_success( [ 'courses' => $courses, 'tags' => $tag_names ] );
} );

/**
 * Adds a course to the group via expansion.
 * Enrolls all group members and registers it in master_courses.
 */
add_action( 'wp_ajax_glct_add_expansion_course', function (): void {
    check_ajax_referer( 'glct_nonce', 'nonce' );

    if ( get_option( 'glct_allow_expansion', 'no' ) !== 'yes' ) {
        wp_send_json_error( [ 'message' => 'Course expansion is disabled.' ] );
        return;
    }

    $gid = (int) ( $_POST['group_id']  ?? 0 );
    $cid = (int) ( $_POST['course_id'] ?? 0 );

    if ( ! glct_can_manage( $gid ) ) {
        wp_send_json_error( [ 'message' => 'Permission denied.' ] );
        return;
    }

    // Verify the course is NOT already in the group
    if ( glct_course_in_group( $gid, $cid ) ) {
        wp_send_json_error( [ 'message' => 'Course is already in this group.' ] );
        return;
    }

    // Verify the course matches one of the group's expansion tags
    $expansion_tags = (array) get_post_meta( $gid, 'glct_expansion_tags', true );
    $expansion_tags = array_filter( array_map( 'intval', $expansion_tags ) );
    $course_tag_ids = wp_get_post_terms( $cid, 'ld_course_tag', [ 'fields' => 'ids' ] );
    if ( is_wp_error( $course_tag_ids ) ) $course_tag_ids = [];

    if ( empty( array_intersect( $course_tag_ids, $expansion_tags ) ) ) {
        wp_send_json_error( [ 'message' => 'Course does not match this group\'s allowed expansion tags.' ] );
        return;
    }

    // Add course to LearnDash group enrollment
    if ( function_exists( 'ld_update_course_group_access' ) ) {
        ld_update_course_group_access( $cid, $gid, false ); // false = add
    }

    // Add to master_courses
    $master = array_filter( array_map( 'intval',
        (array) get_post_meta( $gid, 'glct_master_courses', true )
    ) );
    if ( ! in_array( $cid, $master, true ) ) {
        $master[] = $cid;
        update_post_meta( $gid, 'glct_master_courses', array_values( $master ) );
    }

    // Enroll group members in the course.
    // ld_update_course_group_access above associates the course with the group,
    // but LearnDash may not auto-enroll existing members for all versions.
    // Batch-enroll in chunks to avoid PHP timeout on large groups (500+).
    $members = glct_members( $gid );
    if ( function_exists( 'ld_update_course_access' ) ) {
        $batch = array_chunk( $members, 50 );
        foreach ( $batch as $chunk ) {
            foreach ( $chunk as $u ) {
                ld_update_course_access( $u->ID, $cid, false );
            }
            // Clear per-user meta caches between batches to limit memory usage on large groups
            if ( count( $members ) > 100 ) {
                foreach ( $chunk as $u ) {
                    clean_user_cache( $u->ID );
                }
            }
        }
    }

    glct_log_event( 'course_added', $gid, $cid, 0, true );
    $exp_title = get_the_title( $cid );
    foreach ( $members as $u ) {
        glct_create_notification( 'course_added', $u->ID, $gid, $cid,
            'New Course Added: ' . $exp_title,
            'A new course "' . esc_html( $exp_title ) . '" has been added to your group and is now available.'
        );
    }

    wp_send_json_success( [
        'message' => 'Course "' . esc_html( $exp_title ) . '" added to group successfully.',
        'course_id' => $cid,
    ] );
} );


// ═══════════════════════════════════════════════════════════════════════════
// SECTION 8 — UI RENDER
// ═══════════════════════════════════════════════════════════════════════════

function glct_render( array $groups, array $all_groups = [] ): void {
    $nonce    = wp_create_nonce( 'glct_nonce' );
    $ajax_url = admin_url( 'admin-ajax.php' );
    $tz_obj   = new DateTimeZone( wp_timezone_string() );

    // Admin Toggles & Customization
    $allow_wipe         = glct_gl_can( 'wipe' );
    $allow_remove       = glct_gl_can( 'remove' );
    $allow_email        = glct_gl_can( 'email' );
    $allow_per_user     = glct_gl_can( 'per_user' );
    $allow_bulk_toggle  = glct_gl_can( 'bulk_toggle' );
    $allow_expansion    = get_option( 'glct_allow_expansion', 'no' ) === 'yes';
    $page_limit         = (int) get_option('glct_pagination_limit', 15);

    $email_subject  = get_option( 'glct_default_email_subject', GLCT_DEFAULT_SUBJECT );
    $email_body     = get_option( 'glct_default_email_body',    GLCT_DEFAULT_BODY );
    $available_tags = array_filter( array_map( 'trim', explode( ',', get_option( 'glct_available_tags', 'Onboarding, Advanced, Compliance, Optional' ) ) ) );
    ?>
    <div id="glct-app">

        <div id="glct-toasts" aria-live="polite" aria-atomic="false"></div>

        <div id="glct-modal-confirm" class="glct-overlay" hidden>
            <div class="glct-modal" role="dialog" aria-modal="true">
                <div class="glct-modal-emoji" id="glct-conf-emoji">⚠️</div>
                <h3 id="glct-conf-title"  class="glct-modal-h"></h3>
                <p  id="glct-conf-body"   class="glct-modal-p"></p>
                
                <?php if ( $allow_wipe ) : ?>
                <div id="glct-conf-wipe-wrap" class="glct-field" style="margin-top:16px; padding:12px; background:var(--red-bg); border:1px solid var(--red-bd); border-radius:var(--r6);" hidden>
                    <label style="display:flex; gap:8px; align-items:flex-start; cursor:pointer;">
                        <input type="checkbox" id="glct-conf-wipe-inp" style="margin-top:3px;">
                        <span style="font-size:0.85rem; color:var(--red); font-weight:600; line-height:1.4;">
                            Wipe previous progress?<br>
                            <span style="font-weight:400; font-size:0.75rem;">This permanently deletes past LearnDash test scores and completion states for all members.</span>
                        </span>
                    </label>
                </div>
                <?php endif; ?>

                <div class="glct-modal-row">
                    <button id="glct-conf-cancel" class="glct-btn glct-btn--ghost">Cancel</button>
                    <button id="glct-conf-ok"     class="glct-btn glct-btn--solid">Confirm</button>
                </div>
            </div>
        </div>
        
        <div id="glct-modal-audit" class="glct-overlay" hidden>
            <div class="glct-modal glct-modal--wide" role="dialog" aria-modal="true">
                <div class="glct-modal-topbar" style="margin-bottom:12px; padding-bottom:16px;">
                    <div>
                        <h3 class="glct-modal-h">Recent Activity Log</h3>
                        <p class="glct-modal-course">Showing latest activity for your groups.</p>
                    </div>
                    <div style="display:flex;align-items:center;gap:8px;">
                        <button id="glct-audit-export" class="glct-btn glct-btn--ghost" style="font-size:.8rem;padding:6px 14px;" title="Export activity log as CSV">📥 Export CSV</button>
                        <button class="glct-close" aria-label="Close" onclick="document.getElementById('glct-modal-audit').hidden = true;">
                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                                <path d="M14 4L4 14M4 4l10 10" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                            </svg>
                        </button>
                    </div>
                </div>
                <div id="glct-audit-body" style="max-height:60vh; overflow-y:auto; border:1px solid var(--border); border-radius:var(--r6);">
                    <p style="padding:14px; color:var(--ink4);">Loading...</p>
                </div>
            </div>
        </div>
        
        <div id="glct-modal-global-user" class="glct-overlay" hidden>
            <div class="glct-modal glct-modal--wide" role="dialog" aria-modal="true">
                <div class="glct-modal-topbar" style="margin-bottom:12px; padding-bottom:16px;">
                    <div>
                        <h3 id="glct-gu-title" class="glct-modal-h">User Access</h3>
                        <p id="glct-gu-email" class="glct-modal-course"></p>
                    </div>
                    <button class="glct-close" aria-label="Close" onclick="document.getElementById('glct-modal-global-user').hidden = true;">
                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                            <path d="M14 4L4 14M4 4l10 10" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                    </button>
                </div>
                <div id="glct-gu-body" style="max-height:60vh; overflow-y:auto; border:1px solid var(--border); border-radius:var(--r6); padding:16px; background:var(--surface);">
                </div>
            </div>
        </div>

        <div id="glct-modal-users" class="glct-overlay" hidden>
            <div class="glct-modal glct-modal--wide" role="dialog" aria-modal="true">

                <div class="glct-modal-topbar" style="margin-bottom:12px; padding-bottom:12px; border-bottom:1px solid var(--border);">
                    <div>
                        <h3 id="glct-users-title" class="glct-modal-h" style="margin-bottom:4px;">Individual Access</h3>
                        <p  id="glct-users-course" class="glct-modal-course"></p>
                    </div>
                    <button id="glct-users-close" class="glct-close" aria-label="Close">
                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                            <path d="M14 4L4 14M4 4l10 10" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                    </button>
                </div>

                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
                    <p class="glct-notify-hint" style="margin:0; font-size:.82rem;">These toggles override the group default for specific users.</p>
                    <?php if ( $allow_bulk_toggle ) : ?>
                    <div style="display:flex; gap:8px; flex-shrink:0;">
                        <button class="glct-btn glct-btn--ghost glct-btn--sm" id="glct-bulk-on">Enable All</button>
                        <button class="glct-btn glct-btn--ghost glct-btn--sm" id="glct-bulk-off">Disable All</button>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="glct-search-bar glct-search-bar--modal" id="glct-member-search-wrap" hidden>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="11" cy="11" r="8"></circle>
                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                    <input type="text" id="glct-member-search" class="glct-course-search" placeholder="Search members by name or email..." aria-label="Search members">
                </div>

                <div id="glct-users-body"></div>

                <!-- Activity Feed -->
                <div class="glct-activity-section">
                    <button type="button" id="glct-activity-toggle" class="glct-activity-btn">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                            <polyline points="12 8 12 12 14 14"></polyline><circle cx="12" cy="12" r="10"></circle>
                        </svg>
                        Recent Activity
                        <svg class="glct-activity-chev" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div id="glct-activity-body" class="glct-activity-body" hidden></div>
                </div>

                <?php if ( $allow_email ) : ?>
                <div class="glct-notify">
                    <div class="glct-notify-title">
                        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="2" y="4" width="20" height="16" rx="2"/>
                            <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>
                        </svg>
                        Send Notification
                    </div>
                    <p class="glct-notify-hint">
                        Merge tags: <code>{first_name}</code> <code>{last_name}</code> <code>{name}</code> <code>{course_name}</code>
                    </p>

                    <div class="glct-field">
                        <label class="glct-label">Recipients</label>
                        <div class="glct-recip-wrap">
                            <button type="button" id="glct-recip-toggle" class="glct-recip-btn">
                                <span id="glct-recip-label">Select recipients…</span>
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                            </button>
                            <div id="glct-recip-dropdown" class="glct-recip-dropdown" hidden>
                                <label class="glct-recip-item glct-recip-all">
                                    <input type="checkbox" id="glct-recip-all-cb" checked> <strong>Select All</strong>
                                </label>
                                <div id="glct-recip-list"></div>
                            </div>
                        </div>
                    </div>

                    <div class="glct-field">
                        <label class="glct-label" for="glct-subj">Subject</label>
                        <input id="glct-subj" class="glct-input" type="text" value="<?php echo esc_attr( $email_subject ); ?>">
                    </div>

                    <div class="glct-field">
                        <label class="glct-label" for="glct-body">Message</label>
                        <textarea id="glct-body" class="glct-textarea" rows="5"><?php echo esc_textarea( $email_body ); ?></textarea>
                    </div>

                    <button id="glct-notify-send" class="glct-send-btn">
                        Preview &amp; Send
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M5 12h14M13 6l6 6-6 6"/>
                        </svg>
                    </button>
                </div>
                <?php endif; ?>

            </div>
        </div>

        <?php if ( $allow_email ) : ?>
        <div id="glct-modal-send" class="glct-overlay" hidden>
            <div class="glct-modal" role="dialog" aria-modal="true">
                <div class="glct-modal-emoji">✉️</div>
                <h3 class="glct-modal-h">Confirm Send</h3>
                <p id="glct-send-desc" class="glct-modal-p"></p>
                <div class="glct-preview-box">
                    <div id="glct-prev-subj" class="glct-preview-subj"></div>
                    <div id="glct-prev-body" class="glct-preview-body"></div>
                </div>
                <div class="glct-modal-row">
                    <button id="glct-send-back" class="glct-btn glct-btn--ghost">← Edit</button>
                    <button id="glct-send-go"   class="glct-btn glct-btn--solid">Send Now</button>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <header class="glct-header">
            <div style="display:flex; align-items:center; gap:16px;">
                <div class="glct-header-icon">🎓</div>
                <div>
                    <h1 class="glct-header-title">Course Manager</h1>
                    <p class="glct-header-sub">Toggle course access for your groups and individual learners</p>
                </div>
            </div>
            
            <div class="glct-header-right" style="display:flex; align-items:center; gap:12px; margin-left:auto;">
                <div class="glct-global-search-wrap">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                        <circle cx="12" cy="7" r="4"></circle>
                    </svg>
                    <input type="text" id="glct-global-search" class="glct-input" placeholder="Find user across groups..." autocomplete="off">
                    <div id="glct-global-results" class="glct-global-results"></div>
                </div>
                
                <button id="glct-audit-btn" class="glct-btn glct-btn--ghost">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="12 8 12 12 14 14"></polyline>
                        <circle cx="12" cy="12" r="10"></circle>
                    </svg>
                    Activity Log
                </button>
            </div>
        </header>

        <?php if ( count( $all_groups ) > 1 ) :
            $current_url  = remove_query_arg( 'glct_group_id' );
            $selected_gid = isset( $_GET['glct_group_id'] ) ? (int) $_GET['glct_group_id'] : 0;
            $active_gid   = $groups[0]->ID ?? 0;
        ?>
        <div class="glct-group-selector">
            <label class="glct-selector-label" for="glct-group-select">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                    <circle cx="9" cy="7" r="4"/>
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                    <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                </svg>
                Select Group
            </label>
            <div class="glct-selector-wrap">
                <select id="glct-group-select" class="glct-select"
                    onchange="window.location = '<?php echo esc_js( $current_url ); ?>' + '?glct_group_id=' + this.value">
                    <?php foreach ( $all_groups as $g ) :
                        $is_sel = ( $g->ID === $active_gid );
                        $count  = count( glct_members( $g->ID ) );
                    ?>
                    <option value="<?php echo esc_attr( $g->ID ); ?>"<?php selected( $is_sel ); ?>>
                        <?php echo esc_html( $g->post_title ); ?> &mdash; <?php echo esc_html( $count ); ?> member<?php echo $count !== 1 ? 's' : ''; ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <span class="glct-select-chevron" aria-hidden="true">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M6 9l6 6 6-6"/>
                    </svg>
                </span>
            </div>
        </div>
        <?php endif; ?>

        <?php foreach ( $groups as $group ) :
            $courses       = glct_all_courses( $group->ID );
            $member_count  = count( glct_members( $group->ID ) );
            $disabled_ids  = glct_disabled_ids( $group->ID );
            $total_courses = count( $courses );
            $disabled_cnt  = 0;
            foreach ( $courses as $_c ) {
                if ( in_array( $_c->ID, $disabled_ids, true ) ) $disabled_cnt++;
            }
            $enabled_cnt   = $total_courses - $disabled_cnt;
            $group_tags    = glct_get_course_tags( $group->ID );
        ?>
        <section class="glct-group" id="glct-group-<?php echo esc_attr( $group->ID ); ?>">

            <div class="glct-group-header">
                <div class="glct-group-header-left">
                    <span class="glct-group-dot" aria-hidden="true"></span>
                    <h2 class="glct-group-name"><?php echo esc_html( $group->post_title ); ?></h2>
                </div>
                <div style="display:flex; align-items:center; gap:12px;">
                    <button class="glct-refresh-btn glct-btn glct-btn--ghost glct-btn--sm" data-gid="<?php echo esc_attr( $group->ID ); ?>" title="Sync list with LearnDash to clear old removed courses">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"></path><path d="M3 3v5h5"></path><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"></path><path d="M16 21v-5h5"></path></svg>
                        Refresh
                    </button>
                    <span class="glct-member-count">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
                            <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                            <circle cx="9" cy="7" r="4"/>
                            <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                            <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                        </svg>
                        <?php echo esc_html( $member_count ); ?> member<?php echo $member_count !== 1 ? 's' : ''; ?>
                    </span>
                </div>
            </div>

            <div class="glct-stats-bar">
                <div class="glct-stat">
                    <span class="glct-stat-val"><?php echo esc_html( $total_courses ); ?></span>
                    <span class="glct-stat-lbl">Courses</span>
                </div>
                <div class="glct-stat glct-stat--green">
                    <span class="glct-stat-val"><?php echo esc_html( $enabled_cnt ); ?></span>
                    <span class="glct-stat-lbl">Active</span>
                </div>
                <div class="glct-stat glct-stat--red">
                    <span class="glct-stat-val"><?php echo esc_html( $disabled_cnt ); ?></span>
                    <span class="glct-stat-lbl">Disabled</span>
                </div>
                <div class="glct-stat glct-stat--blue">
                    <span class="glct-stat-val"><?php echo esc_html( $member_count ); ?></span>
                    <span class="glct-stat-lbl">Members</span>
                </div>
            </div>

            <?php
            // Member Inactivity Alerts
            $glct_inact_days = (int) get_option( 'glct_inactivity_days', 0 );
            if ( $glct_inact_days > 0 ) :
                global $wpdb;
                $glct_inactive = $wpdb->get_results( $wpdb->prepare(
                    "SELECT DISTINCT user_id, MAX(timestamp) as latest
                     FROM {$wpdb->prefix}glct_audit_log
                     WHERE group_id = %d AND action = 'user_inactive'
                     AND timestamp > DATE_SUB(NOW(), INTERVAL %d DAY)
                     GROUP BY user_id ORDER BY latest DESC LIMIT 10",
                    $group->ID, $glct_inact_days
                ) );
                if ( ! empty( $glct_inactive ) ) : ?>
            <div style="margin-bottom:18px;">
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;">
                    <span style="font-size:1rem;">⚠️</span>
                    <span style="font-size:.88rem;font-weight:700;color:var(--ink2);">Member Inactivity Alerts</span>
                </div>
                <?php foreach ( $glct_inactive as $ia ) :
                    $ia_user = get_userdata( (int) $ia->user_id );
                    if ( ! $ia_user ) continue;
                    $ia_last = get_user_meta( (int) $ia->user_id, 'glct_last_activity', true );
                    $ia_days = $ia_last ? floor( ( time() - (int) $ia_last ) / DAY_IN_SECONDS ) : $glct_inact_days;
                ?>
                <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;background:#fef3c7;border:1px solid #fcd34d;border-radius:var(--r8);margin-bottom:6px;">
                    <span style="font-size:.85rem;">⚠️</span>
                    <span style="font-size:.82rem;font-weight:600;color:var(--ink2);"><?php echo esc_html( $ia_user->display_name ); ?> has not accessed training in <?php echo esc_html( $ia_days ); ?> days</span>
                </div>
                <?php endforeach; ?>
            </div>
                <?php endif;
            endif;
            ?>

            <?php if ( get_option( 'glct_enable_compliance_dashboard', 'yes' ) === 'yes' ) : ?>
            <div class="glct-compliance-dashboard glct-card" id="glct-compliance-<?php echo esc_attr( $group->ID ); ?>" data-gid="<?php echo esc_attr( $group->ID ); ?>">
                <div class="glct-compliance-header">
                    <div>
                        <h3 class="glct-compliance-title">Compliance Overview</h3>
                        <p class="glct-compliance-subtitle">Completion rates and at-risk learners</p>
                    </div>
                    <div style="display:flex;gap:8px;">
                        <button class="glct-compliance-refresh glct-btn glct-btn--ghost glct-btn--sm" data-gid="<?php echo esc_attr( $group->ID ); ?>">Refresh</button>
                        <button class="glct-compliance-export glct-btn glct-btn--ghost glct-btn--sm" data-gid="<?php echo esc_attr( $group->ID ); ?>">Export CSV</button>
                    </div>
                </div>
                <div class="glct-compliance-body" id="glct-compliance-body-<?php echo esc_attr( $group->ID ); ?>">
                    <p style="padding:14px 0;color:var(--ink4);font-size:.88rem;">Loading compliance data...</p>
                </div>
            </div>
            <?php endif; ?>

            <?php if ( empty( $courses ) ) : ?>
                <div class="glct-empty">
                    <span>📭</span>
                    <p>No courses are linked to this group yet.</p>
                </div>
            <?php else : ?>

            <?php
            // Collect used tags for filter bar
            $used_tags = [];
            foreach ( $courses as $_c ) {
                if ( ! empty( $group_tags[ $_c->ID ] ) && ! in_array( $group_tags[ $_c->ID ], $used_tags, true ) ) {
                    $used_tags[] = $group_tags[ $_c->ID ];
                }
            }
            ?>
            <?php if ( ! empty( $used_tags ) ) : ?>
            <div class="glct-tag-filter" data-gid="<?php echo esc_attr( $group->ID ); ?>">
                <span class="glct-tag-filter-lbl">Filter:</span>
                <button class="glct-tag-pill glct-tag-pill--active" data-tag="all">All</button>
                <?php foreach ( $used_tags as $ut ) : ?>
                <button class="glct-tag-pill" data-tag="<?php echo esc_attr( $ut ); ?>"><?php echo esc_html( $ut ); ?></button>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <div class="glct-search-sort-bar">
                <div class="glct-search-bar">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="11" cy="11" r="8"></circle>
                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                    <input type="text" class="glct-course-search" placeholder="Search courses in <?php echo esc_attr( $group->post_title ); ?>..." aria-label="Search courses">
                </div>
                <select class="glct-course-sort" aria-label="Sort courses">
                    <option value="default">Sort: Default</option>
                    <option value="az">Sort: A → Z</option>
                    <option value="za">Sort: Z → A</option>
                    <option value="newest">Sort: Newest</option>
                    <option value="completion-high">Sort: Highest Completion</option>
                    <option value="completion-low">Sort: Lowest Completion</option>
                    <option value="active">Sort: Active First</option>
                    <option value="inactive">Sort: Inactive First</option>
                </select>
            </div>

            <div class="glct-cards">
                <?php foreach ( $courses as $course ) :
                    $is_on      = glct_is_enabled( $group->ID, $course->ID );
                    $toggled    = get_post_meta( $group->ID, "glct_toggled_{$course->ID}", true );
                    $raw = get_post_field( 'post_excerpt', $course->ID );
                    if ( ! trim( $raw ) ) {
                        $raw = get_post_field( 'post_content', $course->ID );
                    }
                    $raw     = strip_shortcodes( wp_strip_all_tags( $raw ) );
                    $raw     = preg_replace( '/^CourseDetails\s*/i', '', $raw );
                    $excerpt  = wp_trim_words( $raw, 18, '…' );
                    
                    $time_ago = $toggled
                        ? 'Updated ' . human_time_diff( strtotime( $toggled ), time() ) . ' ago'
                        : 'Never updated';
                    $course_tag = $group_tags[ $course->ID ] ?? '';
                ?>
                <article class="glct-card <?php echo $is_on ? 'glct-card--on' : 'glct-card--off'; ?>" data-tag="<?php echo esc_attr( $course_tag ); ?>" data-date="<?php echo esc_attr( $course->post_date ); ?>" data-status="<?php echo $is_on ? 'active' : 'inactive'; ?>" data-completion="-1">

                    <div class="glct-card-info">
                        <div style="display:flex; align-items:center; flex-wrap:wrap; gap:10px;">
                            <span class="glct-badge <?php echo $is_on ? 'glct-badge--on' : 'glct-badge--off'; ?>">
                                <span class="glct-badge-dot"></span>
                                <?php echo $is_on ? 'Group Active' : 'Group Inactive'; ?>
                            </span>
                            <?php if ( $course_tag ) : ?>
                            <span class="glct-course-tag"><?php echo esc_html( $course_tag ); ?></span>
                            <?php endif; ?>
                        </div>
                        <h3 class="glct-card-title"><?php echo esc_html( $course->post_title ); ?></h3>
                        <a class="glct-card-link" href="<?php echo esc_url( get_permalink( $course->ID ) ); ?>" target="_blank" rel="noopener noreferrer">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
                            View Course
                        </a>
                        <?php if ( $excerpt ) : ?>
                            <p class="glct-card-excerpt"><?php echo esc_html( $excerpt ); ?></p>
                        <?php endif; ?>
                        <p class="glct-card-time"><?php echo esc_html( $time_ago ); ?></p>
                        <?php if ( $is_on ) : ?>
                        <span class="glct-card-progress" data-progress-gid="<?php echo esc_attr( $group->ID ); ?>" data-progress-cid="<?php echo esc_attr( $course->ID ); ?>">
                            <span class="glct-progress-loading">Loading progress...</span>
                        </span>
                        <?php endif; ?>
                        <?php if ( $is_on && get_option( 'glct_allow_deadlines', 'yes' ) === 'yes' ) :
                            $deadline  = glct_get_deadline( $group->ID, $course->ID );
                            $dl_status = $deadline ? glct_deadline_status( $deadline ) : null;
                        ?>
                        <div class="glct-deadline-row" data-gid="<?php echo esc_attr( $group->ID ); ?>" data-cid="<?php echo esc_attr( $course->ID ); ?>">
                            <?php if ( $dl_status ) : ?>
                            <span class="glct-deadline-badge <?php echo esc_attr( $dl_status['class'] ); ?>">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                                <?php echo esc_html( $dl_status['label'] ); ?>
                            </span>
                            <?php endif; ?>
                            <input type="date" class="glct-deadline-input" value="<?php echo esc_attr( $deadline ?? '' ); ?>" title="Set deadline">
                            <?php if ( $deadline ) : ?>
                            <button class="glct-deadline-clear" title="Clear deadline">&times;</button>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="glct-card-controls">
                        <div class="glct-toggle-row">
                            <span class="glct-toggle-lbl">All members</span>
                            <label class="glct-toggle">
                                <input
                                    type="checkbox"
                                    class="glct-toggle-inp"
                                    <?php checked( $is_on ); ?>
                                    data-action="group"
                                    data-gid="<?php echo esc_attr( $group->ID ); ?>"
                                    data-cid="<?php echo esc_attr( $course->ID ); ?>"
                                    data-on="<?php echo $is_on ? '1' : '0'; ?>"
                                    data-name="<?php echo esc_attr( $course->post_title ); ?>"
                                >
                                <span class="glct-track"><span class="glct-thumb"></span></span>
                            </label>
                        </div>

                        <?php if ( ! empty( $available_tags ) ) : ?>
                        <div style="margin-top:8px;">
                            <select class="glct-tag-select" data-gid="<?php echo esc_attr( $group->ID ); ?>" data-cid="<?php echo esc_attr( $course->ID ); ?>">
                                <option value="__none__"<?php echo $course_tag === '' ? ' selected' : ''; ?>>— Tag —</option>
                                <?php foreach ( $available_tags as $at ) : ?>
                                <option value="<?php echo esc_attr( $at ); ?>"<?php selected( $course_tag, $at ); ?>><?php echo esc_html( $at ); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <?php endif; ?>

                        <?php if ( $allow_per_user ) : ?>
                        <div style="display:flex; justify-content:center; margin-top:10px;">
                            <button
                                class="glct-user-btn glct-btn-half"
                                data-gid="<?php echo esc_attr( $group->ID ); ?>"
                                data-cid="<?php echo esc_attr( $course->ID ); ?>"
                                data-name="<?php echo esc_attr( $course->post_title ); ?>"
                                title="Per-User Access">
                                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
                                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                                    <circle cx="9" cy="7" r="4"/>
                                </svg>
                                Users
                            </button>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ( $allow_remove ) : ?>
                        <div style="display:flex; justify-content:flex-end; margin-top:10px;">
                            <button class="glct-remove-course-btn" 
                                data-gid="<?php echo esc_attr( $group->ID ); ?>" 
                                data-cid="<?php echo esc_attr( $course->ID ); ?>" 
                                data-name="<?php echo esc_attr( $course->post_title ); ?>">
                                Remove Course
                            </button>
                        </div>
                        <?php endif; ?>
                        
                    </div>

                </article>
                <?php endforeach; ?>
            </div>

            <?php endif; ?>

            <?php if ( $allow_expansion ) :
                $exp_tags = (array) get_post_meta( $group->ID, 'glct_expansion_tags', true );
                $exp_tags = array_filter( array_map( 'intval', $exp_tags ) );
            ?>
            <?php if ( ! empty( $exp_tags ) ) : ?>
            <div class="glct-expansion" data-gid="<?php echo esc_attr( $group->ID ); ?>">
                <button type="button" class="glct-expansion-toggle">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="16"></line>
                        <line x1="8" y1="12" x2="16" y2="12"></line>
                    </svg>
                    Add Courses
                    <svg class="glct-expansion-chev" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                </button>
                <div class="glct-expansion-body" hidden>
                    <div class="glct-expansion-filters"></div>
                    <div class="glct-expansion-list">
                        <p style="padding:12px 0;color:var(--ink4);">Click "Add Courses" to browse available courses...</p>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php endif; ?>

        </section>
        <?php endforeach; ?>

    </div><style>
    /* GLCT Course Manager — v2.0.0 */

    /* ── Tokens ───────────────────────────────────────────── */
    #glct-app {
        --white:    #ffffff;
        --surface:  #f7f9fc;
        --surface2: #eef1f8;
        --border:   #e1e7f0;
        --border2:  #c5cfe4;
        --ink:      #0d1526;
        --ink2:     #1e2d48;
        --ink3:     #4a5876;
        --ink4:     #8899b8;
        --blue:     #3d63dd;
        --blue-h:   #2c52cc;
        --blue-bg:  #eef2ff;
        --blue-bd:  #afc2ff;
        --green:    #0b7d5c;
        --green-bg: #eafaf4;
        --green-bd: #6dcfab;
        --red:      #c8332a;
        --red-bg:   #fff4f3;
        --red-bd:   #f9b2ae;
        --sh-sm: 0 1px 3px rgba(13,21,38,.06), 0 2px 6px rgba(13,21,38,.04);
        --sh-md: 0 4px 12px rgba(13,21,38,.08), 0 12px 24px rgba(13,21,38,.06);
        --sh-lg: 0 8px 24px rgba(13,21,38,.12), 0 24px 48px rgba(13,21,38,.08);
        --r4:  4px;
        --r6:  6px;
        --r8:  8px;
        --r10: 10px;
        --r99: 9999px;

        font-family: inherit;
        font-size: 15px;
        line-height: 1.6;
        color: var(--ink);
        background: var(--surface);
        padding: 40px 44px 64px !important;
        border-radius: var(--r8);
        -webkit-text-size-adjust: 100%;
        -webkit-tap-highlight-color: transparent;
    }
    #glct-app *, #glct-app *::before, #glct-app *::after {
        box-sizing: border-box; margin: 0; padding: 0;
    }
    #glct-app button, #glct-app input, #glct-app textarea, #glct-app select {
        font-family: inherit; font-size: inherit;
    }

    /* ── Page header ──────────────────────────────────────── */
    .glct-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        padding-bottom: 24px !important;
        margin: 0 0 16px 0 !important;
    }
    .glct-header-icon {
        flex-shrink: 0;
        width: 48px; height: 48px;
        background: var(--blue);
        border-radius: var(--r8);
        display: flex; align-items: center; justify-content: center;
        font-size: 1.5rem; line-height: 1;
    }
    .glct-header-title {
        font-size: 1.35rem;
        font-weight: 700;
        line-height: 1.2;
        color: var(--ink);
    }
    .glct-header-sub {
        font-size: .875rem;
        color: var(--ink4);
        margin-top: 3px !important;
        font-weight: 600;
    }

    /* Global User Search Dropdown */
    .glct-global-search-wrap {
        position: relative;
        flex: 1;
        max-width: 300px;
        margin-left: auto !important;
    }
    .glct-global-search-wrap svg {
        position: absolute;
        left: 12px;
        top: 50%;
        transform: translateY(-50%);
        color: var(--ink4);
        width: 16px;
        height: 16px;
    }
    #glct-global-search {
        width: 256px !important;
        padding: 8px 8px 8px 36px !important;
        border-radius: var(--r8);
    }
    .glct-global-results {
        position: absolute;
        top: calc(100% + 4px);
        left: 0;
        right: 0;
        background: var(--white);
        border: 1px solid var(--border);
        border-radius: var(--r6);
        box-shadow: var(--sh-md);
        z-index: 999;
        max-height: 300px;
        overflow-y: auto;
        display: none;
    }
    .glct-global-result {
        padding: 10px 14px !important;
        cursor: pointer;
        border-bottom: 1px solid var(--border2);
        font-size: 0.9rem;
        font-weight: 600;
        color: var(--ink);
    }
    .glct-global-result:hover { background: var(--surface2); }
    .glct-global-result:last-child { border-bottom: none; }

    /* ── Group section ────────────────────────────────────── */
    .glct-group { margin-bottom: 44px !important; }
    .glct-group:last-child { margin-bottom: 0 !important; }

    .glct-group-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 16px !important;
        margin-top: 8px !important;
    }
    .glct-group-header-left { display: flex; align-items: center; gap: 12px; }
    .glct-group-dot {
        width: 8px; height: 8px;
        border-radius: var(--r99);
        background: var(--blue);
        flex-shrink: 0;
    }
    .glct-group-name {
        font-size: 1rem;
        font-weight: 700;
        color: var(--ink);
    }
    .glct-member-count {
        display: inline-flex; align-items: center; gap: 5px;
        font-size: .75rem; font-weight: 600;
        color: var(--blue);
        background: var(--blue-bg);
        border: 1px solid var(--blue-bd);
        padding: 4px !important;
        border-radius: var(--r8);
    }

    .glct-empty {
        display: flex; align-items: center; gap: 12px;
        background: var(--white);
        border: 1px dashed var(--border2);
        border-radius: var(--r6);
        padding: 24px 20px !important;
        color: var(--ink4);
        font-size: .9rem;
    }
    .glct-empty span { font-size: 1.5rem; }

    /* ── Search + Sort Bar ────────────────────── */
    .glct-search-sort-bar {
        display: flex; align-items: stretch; gap: 10px;
        margin-bottom: 16px !important;
    }
    .glct-search-bar {
        position: relative;
        flex: 1; min-width: 0;
    }
    .glct-course-sort {
        flex-shrink: 0;
        background: var(--white); border: 1px solid var(--border2);
        border-radius: var(--r8); color: var(--ink2);
        font-size: .82rem; font-weight: 500;
        padding: 8px 12px !important; margin-top: 8px !important; margin-bottom: 8px !important;
        cursor: pointer; transition: border-color .15s;
        appearance: none; -webkit-appearance: none;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6'%3E%3Cpath d='M0 0l5 6 5-6z' fill='%23888'/%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 10px center;
        padding-right: 28px !important;
    }
    .glct-course-sort:focus {
        outline: none; border-color: var(--blue);
        box-shadow: 0 0 0 3px rgba(61,99,221,.1);
    }
    .glct-search-bar svg {
        position: absolute;
        left: 12px;
        top: 50%;
        transform: translateY(-50%);
        color: var(--ink4);
        pointer-events: none;
        width: 16px;
        height: 16px;
    }
    .glct-course-search {
        width: 100%;
        background: var(--white);
        border: 1px solid var(--border2);
        border-radius: var(--r8);
        color: var(--ink);
        font-size: .9rem;
        padding: 10px 12px 10px 36px !important;
        margin-top: 8px !important;
        margin-bottom: 8px !important;
        box-sizing: border-box;
        transition: border-color .15s, box-shadow .15s;
    }
    .glct-course-search:focus {
        outline: none;
        border-color: var(--blue);
        box-shadow: 0 0 0 3px rgba(61,99,221,.1);
    }
    .glct-search-bar--modal {
        margin-bottom: 12px !important;
    }

    /* ── Cards ────────────────────────────────────────────── */
    .glct-cards { display: flex; flex-direction: column; gap: 12px; }

    .glct-card {
        display: grid;
        grid-template-columns: 1fr 220px;
        align-items: stretch;
        background: var(--white);
        border: 1px solid var(--border);
        border-radius: var(--r6);
        overflow: hidden;
        box-shadow: var(--sh-sm);
        transition: box-shadow .15s ease, border-color .15s ease;
    }
    .glct-card:hover {
        box-shadow: var(--sh-md);
        border-color: var(--border2);
    }

    .glct-card--on  { border-left: 3px solid var(--green); }
    .glct-card--off { border-left: 3px solid var(--border2); background: #f9fafc; }

    /* Info column */
    .glct-card-info {
        padding: 20px 24px !important;
        display: flex;
        flex-direction: column;
        justify-content: center;
        gap: 8px;
        min-width: 0;
    }
    .glct-badge {
        display: inline-flex; align-items: center; gap: 5px;
        font-size: .7rem; font-weight: 600;
        letter-spacing: .4px; text-transform: uppercase;
        padding: 4px !important;
        border-radius: var(--r4);
        width: fit-content;
        white-space: nowrap;
    }
    .glct-badge--on  { background: var(--green-bg); color: var(--green);  border: 1px solid var(--green-bd); }
    .glct-badge--off { background: #f2f4f8;         color: var(--ink4);   border: 1px solid var(--border2);  }
    .glct-badge-dot  { width: 5px; height: 5px; border-radius: 50%; background: currentColor; flex-shrink: 0; }
    
    .glct-card-title {
        font-size: .95rem;
        font-weight: 700;
        color: var(--ink);
        line-height: 1.3;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .glct-card--off .glct-card-title { color: var(--ink3); }

    .glct-card-link {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        font-size: .78rem;
        color: var(--blue);
        text-decoration: none;
        font-weight: 500;
        margin-top: 2px !important;
    }
    .glct-card-link:hover { text-decoration: underline; }
    .glct-card--off .glct-card-link { color: var(--ink4); }

    .glct-card-excerpt {
        font-size: .85rem;
        color: var(--ink4);
        line-height: 1.5;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .glct-card-time {
        font-size: .75rem;
        color: var(--ink4);
        font-family: monospace;
    }

    /* Controls column */
    .glct-card-controls {
        display: flex;
        flex-direction: column;
        justify-content: center;
        gap: 12px;
        padding: 20px 22px !important;
        border-left: 1px solid var(--border);
        background: var(--surface);
    }

    /* Toggle */
    .glct-toggle-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
    }
    .glct-toggle-lbl {
        font-size: .875rem;
        font-weight: 600;
        color: var(--ink3);
        white-space: nowrap;
        text-transform: uppercase;
    }
    .glct-toggle      { position: relative; display: inline-flex; cursor: pointer; flex-shrink: 0; }
    .glct-toggle-inp  { position: absolute; opacity: 0; width: 0; height: 0; }

    .glct-track {
        display: block;
        width: 52px; height: 28px;
        border-radius: var(--r99);
        background: var(--border2);
        transition: background .2s ease;
        position: relative;
    }
    .glct-toggle-inp:checked  + .glct-track { background: var(--green); }
    .glct-toggle-inp:disabled + .glct-track { opacity: .4; cursor: not-allowed; }
    .glct-toggle-inp:focus-visible + .glct-track {
        outline: 2px solid var(--blue);
        outline-offset: 3px;
    }
    .glct-thumb {
        position: absolute;
        top: 4px; left: 4px;
        width: 20px; height: 20px;
        border-radius: 50%;
        background: var(--white);
        box-shadow: 0 1px 3px rgba(0,0,0,.25);
        transition: left .18s cubic-bezier(.4,0,.2,1);
        pointer-events: none;
    }
    .glct-toggle-inp:checked + .glct-track .glct-thumb { left: 28px; }

    /* Action buttons */
    .glct-btn-half {
        display: flex; align-items: center; justify-content: center; gap: 7px;
        width: 100%;
        font-size: .875rem; font-weight: 600;
        background: var(--white);
        border: 1px solid var(--blue-bd);
        border-radius: var(--r6);
        padding: 8px 12px !important;
        cursor: pointer;
        transition: background .14s, border-color .14s;
    }
    .glct-user-btn { color: var(--blue); }
    .glct-user-btn:hover { background: var(--blue-bg); border-color: var(--blue); }

    .glct-btn-half svg { flex-shrink: 0; }
    .glct-btn--sm { padding: 6px 12px; font-size: 0.8rem; }
    .glct-refresh-btn.glct-btn--sm { padding: 6px 4px !important; }
    #glct-audit-btn { padding: 4px !important; }
    #glct-group-select { padding: 8px !important; }
    
    .glct-remove-course-btn {
        background: none;
        border: none;
        color: var(--ink4);
        font-size: 0.75rem;
        font-weight: 600;
        cursor: pointer;
        text-decoration: underline;
        padding: 8px !important;
        transition: color .15s;
    }
    .glct-remove-course-btn:hover {
        color: var(--red);
    }
    
    .glct-wipe-btn {
        background: none;
        border: none;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        color: var(--red);
        padding: 6px !important;
        border-radius: var(--r4);
        margin-left: 12px !important;
        transition: background .15s, opacity .15s;
    }
    .glct-wipe-btn:hover {
        background: var(--red-bg);
    }
    .glct-wipe-btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
    }

    /* ── Modal overlay ────────────────────────────────────── */
    .glct-overlay {
        position: fixed; inset: 0; z-index: 999999;
        background: rgba(5,10,24,.5);
        backdrop-filter: blur(4px);
        -webkit-backdrop-filter: blur(4px);
        display: flex; align-items: center; justify-content: center;
        padding: 20px !important;
        animation: glct-bg .15s ease;
    }
    .glct-overlay[hidden] { display: none; }
    @keyframes glct-bg { from { opacity: 0; } to { opacity: 1; } }

    .glct-modal {
        background: var(--white);
        border-radius: var(--r8);
        padding: 36px 40px 40px !important;
        width: 100%; max-width: 480px;
        box-shadow: var(--sh-lg);
        border: 1px solid var(--border);
        animation: glct-pop .18s ease-out;
    }
    .glct-modal--wide {
        max-width: 720px;
        max-height: 90vh;
        overflow-y: auto;
        padding: 32px 36px 44px !important;
        display: flex;
        flex-direction: column;
    }
    @keyframes glct-pop {
        from { transform: translateY(8px); opacity: 0; }
        to   { transform: none; opacity: 1; }
    }

    .glct-modal-emoji  { font-size: 24px; line-height: 1; margin-bottom: 18px !important; }
    .glct-modal-h      { font-size: 1.15rem; font-weight: 700; color: var(--ink); margin-bottom: 10px !important; }
    .glct-modal-p      { font-size: .9rem; color: var(--ink3); line-height: 1.65; }
    .glct-modal-course { font-size: .9rem; color: var(--blue); font-weight: 600; margin-top: 6px !important; }

    /* Confirm modal overrides */
    #glct-modal-confirm .glct-modal { transform: translateX(0) translateY(0); }
    #glct-conf-ok     { padding: 8px !important; }
    #glct-conf-cancel { padding: 8px !important; }
    #glct-conf-body   { margin-top: 8px !important; margin-bottom: 8px !important; }

    /* Audit modal overrides */
    #glct-modal-audit .glct-modal--wide { transform: translateX(0) translateY(0); }

    .glct-modal-topbar {
        display: flex; align-items: flex-start; justify-content: space-between; gap: 16px;
        flex-shrink: 0;
    }

    .glct-close {
        flex-shrink: 0;
        width: 32px; height: 32px;
        border-radius: var(--r6);
        background: var(--surface);
        border: 1px solid var(--border);
        display: flex; align-items: center; justify-content: center;
        cursor: pointer; color: var(--ink4);
        transition: background .13s, color .13s;
    }
    .glct-close:hover { background: var(--surface2); color: var(--ink); }

    .glct-modal-row { display: flex; gap: 12px; justify-content: flex-end; margin-top: 32px !important; }

    /* Buttons */
    .glct-btn {
        font-family: inherit;
        font-size: .9rem; font-weight: 600;
        padding: 11px 24px !important;
        border-radius: var(--r6);
        border: none; cursor: pointer;
        line-height: 1;
        display: inline-flex; align-items: center; justify-content: center; gap: 6px;
        transition: background .13s, box-shadow .13s;
    }
    .glct-btn:active   { opacity: .88; }
    .glct-btn:disabled { opacity: .45; cursor: not-allowed; }
    .glct-btn--ghost {
        background: var(--surface);
        color: var(--ink3);
        border: 1px solid var(--border2);
    }
    .glct-btn--ghost:hover { background: var(--surface2); color: var(--ink); }
    .glct-btn--solid { background: var(--blue); color: #fff; }
    .glct-btn--solid:hover { background: var(--blue-h); }
    .glct-btn--solid.is-danger { background: var(--red); }
    .glct-btn--solid.is-danger:hover { filter: brightness(.92); }

    /* Members list */
    #glct-users-body {
        border: 1px solid var(--border);
        border-radius: var(--r6);
        overflow-y: auto;
        margin-bottom: 16px !important;
        min-height: 180px;
        max-height: 44vh;
        background: var(--white);
    }
    .glct-member-list {
        display: flex;
        flex-direction: column;
    }
    .glct-member-card {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        padding: 12px 16px !important;
        border-bottom: 1px solid var(--border);
        transition: background .1s;
    }
    .glct-member-card:last-child { border-bottom: none; }
    .glct-member-card:hover { background: var(--surface); }
    .glct-member-info {
        flex: 1;
        min-width: 0;
    }
    .glct-member-actions {
        display: flex;
        align-items: center;
        gap: 8px;
        flex-shrink: 0;
    }
    .glct-user-name  { display: block; font-size: .9rem; font-weight: 600; color: var(--ink); }
    .glct-user-email { display: block; font-size: .76rem; color: var(--ink4); font-family: monospace; margin-top: 2px !important; overflow: hidden; text-overflow: ellipsis; }

    /* ── Progress Bar & Badges ──────────────────────── */
    .glct-member-progress {
        display: flex; align-items: center; gap: 8px;
        min-width: 120px; flex-shrink: 0;
    }
    .glct-progress-bar-wrap {
        flex: 1; height: 6px; background: var(--surface2);
        border-radius: var(--r99); overflow: hidden; min-width: 60px;
    }
    .glct-progress-bar {
        height: 100%; background: var(--blue);
        border-radius: var(--r99); transition: width .3s ease;
    }
    .glct-progress-pct {
        font-size: .75rem; font-weight: 700; color: var(--ink3);
        white-space: nowrap;
    }
    .glct-progress-badge {
        font-size: .72rem; font-weight: 600;
        padding: 3px 8px !important; border-radius: var(--r99);
        white-space: nowrap;
    }
    .glct-progress-badge--done {
        background: var(--green-bg); color: var(--green);
        border: 1px solid var(--green-bd, var(--green));
    }
    .glct-progress-badge--none {
        background: var(--surface2); color: var(--ink4);
        border: 1px solid var(--border);
    }
    .glct-card-progress {
        display: block; margin-top: 4px !important;
        font-size: .8rem; font-weight: 600; color: var(--ink3);
    }
    .glct-progress-loading {
        font-size: .78rem; color: var(--ink4); font-style: italic;
    }

    /* ── Deadline Row on Course Card ──────────────────── */
    .glct-deadline-row {
        display: flex; align-items: center; gap: 8px;
        margin-top: 6px !important; flex-wrap: wrap;
    }
    .glct-deadline-badge {
        display: inline-flex; align-items: center; gap: 4px;
        font-size: .72rem; font-weight: 600; padding: 3px 8px !important;
        border-radius: var(--r99); white-space: nowrap;
    }
    .glct-deadline--normal  { background: var(--surface2); color: var(--ink3); border: 1px solid var(--border); }
    .glct-deadline--soon    { background: #fef3c7; color: #92400e; border: 1px solid #fcd34d; }
    .glct-deadline--urgent  { background: #fef3c7; color: #92400e; border: 1px solid #f59e0b; }
    .glct-deadline--overdue { background: var(--red-bg); color: var(--red); border: 1px solid var(--red); }
    .glct-deadline-input {
        font-size: .78rem; font-family: inherit; font-weight: 600;
        padding: 4px 8px !important; border: 1px solid var(--border2);
        border-radius: var(--r6); color: var(--ink2); background: var(--white);
        cursor: pointer; transition: border-color .15s;
    }
    .glct-deadline-input:focus { outline: none; border-color: var(--blue); box-shadow: 0 0 0 3px rgba(61,99,221,.1); }
    .glct-deadline-clear {
        background: none; border: none; color: var(--ink4); font-size: 1rem;
        cursor: pointer; padding: 2px 4px !important; line-height: 1;
        transition: color .15s;
    }
    .glct-deadline-clear:hover { color: var(--red); }

    /* ── Compliance Dashboard ──────────────────────── */
    .glct-compliance-dashboard { margin-bottom: 16px !important; display: block !important; grid-template-columns: none !important; }
    .glct-compliance-header {
        display: flex; justify-content: space-between; align-items: center;
        padding: 16px 20px !important; border-bottom: 1px solid var(--border);
    }
    .glct-compliance-title { font-size: 1rem; font-weight: 700; color: var(--ink); margin: 0 !important; }
    .glct-compliance-subtitle { font-size: .8rem; color: var(--ink4); margin: 2px 0 0 0 !important; }
    .glct-compliance-body { padding: 20px !important; }

    /* Stats row */
    .glct-compliance-stats {
        display: flex; gap: 14px; margin-bottom: 20px !important; flex-wrap: wrap;
        align-items: stretch;
    }
    .glct-compliance-stat-card {
        display: flex; align-items: center; gap: 12px;
        padding: 14px 18px !important; background: var(--surface);
        border: 1px solid var(--border); border-radius: var(--r8);
        flex: 1; min-width: 140px;
    }
    .glct-compliance-stat--mini {
        flex-direction: column; align-items: center; justify-content: center; gap: 4px;
        text-align: center; min-width: 100px; flex: 0 1 auto;
        padding: 14px 20px !important;
    }
    .glct-compliance-stat--alert { border-color: var(--red); background: var(--red-bg); }
    .glct-compliance-stat-num { font-size: 1.4rem; font-weight: 800; line-height: 1; }
    .glct-compliance-stat-text { display: flex; flex-direction: column; gap: 2px; }
    .glct-compliance-stat-value { font-size: .88rem; font-weight: 700; color: var(--ink); }
    .glct-compliance-stat-label { font-size: .74rem; color: var(--ink4); }

    .glct-compliance-ring { position: relative; display: inline-flex; align-items: center; justify-content: center; flex-shrink: 0; }
    .glct-compliance-pct {
        position: absolute; font-size: .9rem; font-weight: 800; color: var(--ink);
    }

    /* Two-column grid */
    .glct-compliance-grid {
        display: grid; grid-template-columns: 1fr 1fr; gap: 24px;
    }
    .glct-compliance-col { min-width: 0; }

    .glct-compliance-heading {
        font-size: .72rem; text-transform: uppercase; letter-spacing: .6px;
        font-weight: 700; color: var(--ink4); margin: 0 0 10px 0 !important;
        padding-bottom: 6px !important; border-bottom: 1px solid var(--border);
    }

    /* Course bars */
    .glct-compliance-course-row { margin-bottom: 10px !important; }
    .glct-compliance-course-top {
        display: flex; justify-content: space-between; align-items: baseline;
        margin-bottom: 4px !important;
    }
    .glct-compliance-course-name {
        font-size: .8rem; font-weight: 600; color: var(--ink2);
        overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1; min-width: 0;
    }
    .glct-compliance-bar-wrap {
        height: 6px; background: var(--surface2);
        border-radius: var(--r99); overflow: hidden;
    }
    .glct-compliance-bar {
        height: 100%; background: var(--green);
        border-radius: var(--r99); transition: width .3s ease;
    }
    .glct-compliance-course-pct {
        font-size: .74rem; font-weight: 700; color: var(--ink3);
        white-space: nowrap; margin-left: 8px; flex-shrink: 0;
    }
    .glct-compliance-course-pct.is-overdue { color: var(--red); }
    .glct-overdue-dot {
        display: inline-block; width: 6px; height: 6px;
        background: var(--red); border-radius: 50%; margin-left: 4px; vertical-align: middle;
    }

    /* Pagination controls */
    .glct-compliance-controls {
        display: flex; align-items: center; justify-content: space-between;
        margin-top: 14px !important; padding-top: 10px !important;
        border-top: 1px solid var(--border);
    }
    .glct-compliance-sort {
        font-size: .76rem !important; font-weight: 600 !important;
        padding: 5px 12px !important; border-radius: var(--r99) !important;
        border: 1px solid var(--border2) !important; background: var(--surface2) !important;
        color: var(--ink3) !important; cursor: pointer; transition: all .14s;
    }
    .glct-compliance-sort:hover {
        border-color: var(--blue-bd) !important; color: var(--blue) !important;
        background: var(--blue-bg) !important;
    }
    .glct-compliance-pager {
        display: flex; align-items: center; gap: 6px;
    }
    .glct-compliance-prev, .glct-compliance-next {
        font-size: .78rem !important; font-weight: 600 !important;
        padding: 4px 10px !important; border-radius: var(--r6) !important;
        border: 1px solid var(--border2) !important; background: var(--white) !important;
        color: var(--ink3) !important; cursor: pointer; transition: all .14s;
    }
    .glct-compliance-prev:hover:not(:disabled), .glct-compliance-next:hover:not(:disabled) {
        border-color: var(--blue-bd) !important; color: var(--blue) !important;
    }
    .glct-compliance-prev:disabled, .glct-compliance-next:disabled {
        opacity: 0.4 !important; cursor: not-allowed !important;
    }
    .glct-compliance-page-info {
        font-size: .76rem; color: var(--ink4); font-weight: 500; min-width: 80px; text-align: center;
    }

    /* At-risk learners */
    .glct-compliance-learner-row {
        display: flex; align-items: center; justify-content: space-between; gap: 8px;
        padding: 8px 0 !important; border-bottom: 1px solid var(--border);
    }
    .glct-compliance-learner-row:last-child { border-bottom: none; }
    .glct-compliance-learner-info { flex: 1; min-width: 0; }
    .glct-compliance-learner-name { display: block; font-size: .82rem; font-weight: 600; color: var(--ink2); }
    .glct-compliance-learner-email { display: block; font-size: .7rem; color: var(--ink4); font-family: monospace; overflow: hidden; text-overflow: ellipsis; }
    .glct-compliance-learner-reason {
        font-size: .68rem; font-weight: 600; padding: 2px 8px !important;
        border-radius: var(--r99); background: #fef3c7; color: #92400e; white-space: nowrap;
    }
    .glct-compliance-learner-activity {
        font-size: .68rem; color: var(--ink4); white-space: nowrap;
    }
    .glct-at-risk-controls {
        display: flex; align-items: center; justify-content: center;
        margin-top: 12px !important; padding-top: 8px !important;
        border-top: 1px solid var(--border);
    }
    .glct-at-risk-prev, .glct-at-risk-next {
        font-size: .78rem !important; font-weight: 600 !important;
        padding: 4px 10px !important; border-radius: var(--r6) !important;
        border: 1px solid var(--border2) !important; background: var(--white) !important;
        color: var(--ink3) !important; cursor: pointer; transition: all .14s;
    }
    .glct-at-risk-prev:hover:not(:disabled), .glct-at-risk-next:hover:not(:disabled) {
        border-color: var(--blue-bd) !important; color: var(--blue) !important;
    }
    .glct-at-risk-prev:disabled, .glct-at-risk-next:disabled {
        opacity: 0.4 !important; cursor: not-allowed !important;
    }
    .glct-at-risk-page-info {
        font-size: .76rem; color: var(--ink4); font-weight: 500; min-width: 80px; text-align: center;
    }

    /* Keep table styles for audit log and other tables */
    .glct-table { width: 100%; border-collapse: collapse; }
    .glct-table th {
        font-size: .72rem; text-transform: uppercase; letter-spacing: .6px;
        font-weight: 700; color: var(--ink4);
        padding: 10px 14px !important;
        border-bottom: 2px solid var(--border);
        text-align: left;
        background: var(--surface);
        position: sticky; top: 0; z-index: 2;
    }
    .glct-table td {
        padding: 10px 14px !important;
        border-bottom: 1px solid var(--border);
        vertical-align: middle;
    }
    .glct-table tr:last-child td { border-bottom: none; }
    .glct-table tbody tr:nth-child(even) td { background: var(--surface); }
    .glct-table tr:hover td      { background: var(--surface2); }
    .glct-table tr { transition: background .1s; cursor: default; }

    /* Notification section */
    .glct-notify { padding-top: 24px !important; border-top: 1px solid var(--border); flex-shrink: 0; }
    .glct-notify-title {
        display: flex; align-items: center; gap: 8px;
        font-size: .95rem; font-weight: 700; color: var(--ink);
        margin-bottom: 8px !important;
    }
    .glct-notify-hint {
        font-size: .85rem; color: var(--ink4); line-height: 1.6;
        margin-bottom: 18px !important;
    }
    .glct-notify-hint code {
        background: var(--surface2); border: 1px solid var(--border);
        border-radius: var(--r4); padding: 1px 6px !important;
        font-size: .8rem; color: var(--blue);
        font-family: monospace;
    }

    /* Form fields */
    .glct-field { margin-bottom: 18px !important; }
    .glct-label {
        display: block;
        font-size: .72rem; font-weight: 700;
        color: var(--ink4);
        text-transform: uppercase; letter-spacing: .6px;
        margin-bottom: 6px !important;
    }
    .glct-input, .glct-textarea {
        width: 100%;
        background: var(--white);
        border: 1px solid var(--border2);
        border-radius: var(--r6);
        color: var(--ink);
        font-size: .9rem;
        padding: 10px 12px !important;
        line-height: 1.6;
        transition: border-color .15s, box-shadow .15s;
        resize: vertical;
    }
    .glct-input:focus, .glct-textarea:focus {
        outline: none;
        border-color: var(--blue);
        box-shadow: 0 0 0 3px rgba(61,99,221,.1);
    }

    /* Recipient dropdown */
    .glct-recip-wrap { position: relative; }
    .glct-recip-btn {
        display: flex; align-items: center; justify-content: space-between; gap: 8px;
        width: 100%; padding: 10px 12px !important;
        font-size: .875rem; font-weight: 500; color: var(--ink);
        background: var(--surface); border: 1px solid var(--border);
        border-radius: var(--r6); cursor: pointer;
        transition: border-color .14s;
    }
    .glct-recip-btn:hover { border-color: var(--blue-bd); }
    .glct-recip-dropdown {
        position: absolute; left: 0; right: 0; top: 100%; z-index: 20;
        max-height: 220px; overflow-y: auto;
        background: var(--white); border: 1px solid var(--border2);
        border-radius: var(--r6); margin-top: 4px !important;
        box-shadow: 0 6px 20px rgba(0,0,0,.08);
    }
    .glct-recip-item {
        display: flex; align-items: center; gap: 10px;
        padding: 9px 14px !important; cursor: pointer; font-size: .85rem;
        transition: background .1s;
    }
    .glct-recip-item:hover { background: var(--surface2); }
    .glct-recip-item input[type="checkbox"] { accent-color: var(--blue); width: 16px; height: 16px; flex-shrink: 0; cursor: pointer; }
    .glct-recip-all { border-bottom: 1px solid var(--border); font-size: .85rem; }

    /* Send button */
    .glct-send-btn {
        display: flex; align-items: center; justify-content: center; gap: 8px;
        width: 100%;
        font-size: .95rem; font-weight: 700;
        color: #fff; background: var(--blue); border: none;
        border-radius: var(--r6);
        padding: 8px !important;
        cursor: pointer; margin-top: 20px !important;
        transition: background .14s;
    }
    .glct-send-btn:hover  { background: var(--blue-h); }
    .glct-send-btn:active { opacity: .9; }

    /* Email preview */
    .glct-preview-box {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--r6);
        padding: 18px 20px !important;
        margin-top: 16px !important;
    }
    .glct-preview-subj {
        font-size: .85rem; font-weight: 700; color: var(--ink3);
        padding-bottom: 10px !important; margin-bottom: 10px !important;
        border-bottom: 1px solid var(--border);
    }
    .glct-preview-body { font-size: .875rem; color: var(--ink); line-height: 1.7; }

    /* Toast */
    #glct-toasts {
        position: fixed; bottom: 24px; right: 24px; z-index: 9999999;
        display: flex; flex-direction: column-reverse; gap: 8px;
        pointer-events: none;
    }
    .glct-toast {
        display: flex; align-items: flex-start; gap: 10px;
        background: #0f1f38;
        border: 1px solid rgba(255,255,255,.08);
        border-radius: var(--r6);
        padding: 13px 16px !important;
        font-size: .875rem; color: #d4e2f6;
        box-shadow: 0 4px 20px rgba(0,0,0,.28);
        max-width: 300px; min-width: 200px; line-height: 1.5;
        pointer-events: auto;
        animation: glct-toast-in .18s ease-out;
    }
    .glct-toast-ico  { font-size: 1rem; flex-shrink: 0; }
    .glct-toast-text { flex: 1; }
    @keyframes glct-toast-in {
        from { transform: translateX(32px); opacity: 0; }
        to   { transform: none; opacity: 1; }
    }

    /* Toggle saving spinner */
    .glct-toggle-spin {
        display: inline-block; width: 16px; height: 16px;
        border: 2.5px solid var(--border2);
        border-top-color: var(--blue); border-radius: 50%;
        animation: glct-spin-r .5s linear infinite;
        margin-left: 10px !important; flex-shrink: 0;
    }

    /* Spinner */
    .glct-spin {
        display: inline-block; width: 13px; height: 13px;
        border: 2px solid rgba(255,255,255,.25);
        border-top-color: #fff; border-radius: 50%;
        animation: glct-spin-r .5s linear infinite;
        vertical-align: middle; margin-left: 6px !important;
    }
    @keyframes glct-spin-r { to { transform: rotate(360deg); } }

    /* Notice */
    .glct-notice {
        background: var(--blue-bg); color: var(--blue);
        padding: 13px 16px !important; border-radius: var(--r6);
        border: 1px solid var(--blue-bd); font-weight: 500;
        font-size: .9rem;
    }

    /* ── Stats Dashboard ──────────────────────────────────── */
    .glct-stats-bar {
        display: flex; gap: 10px; margin-bottom: 18px !important; flex-wrap: wrap;
    }
    .glct-stat {
        flex: 1; min-width: 80px;
        background: var(--white); border: 1px solid var(--border);
        border-radius: var(--r6); padding: 14px 18px !important;
        text-align: center; box-shadow: var(--sh-sm);
    }
    .glct-stat-val {
        display: block; font-size: 1.4rem; font-weight: 800; color: var(--ink); line-height: 1.2;
    }
    .glct-stat-lbl {
        display: block; font-size: .7rem; font-weight: 700; text-transform: uppercase;
        letter-spacing: .5px; color: var(--ink4); margin-top: 4px !important;
    }
    .glct-stat--green .glct-stat-val { color: var(--green); }
    .glct-stat--red   .glct-stat-val { color: var(--red); }
    .glct-stat--blue  .glct-stat-val { color: var(--blue); }

    /* ── Course Tags ─────────────────────────────────────── */
    .glct-course-tag {
        display: inline-flex; align-items: center;
        font-size: .65rem; font-weight: 700; text-transform: uppercase; letter-spacing: .4px;
        padding: 3px 8px !important; border-radius: var(--r99);
        background: var(--blue-bg); color: var(--blue); border: 1px solid var(--blue-bd);
    }
    .glct-tag-select {
        width: 100%; padding: 5px 8px !important; font-size: .78rem; font-weight: 600;
        border: 1px solid var(--border2); border-radius: var(--r4);
        background: var(--white); color: var(--ink3); cursor: pointer;
    }
    .glct-tag-select:focus { outline: none; border-color: var(--blue); }

    .glct-tag-filter {
        display: flex; align-items: center; gap: 8px; margin-bottom: 14px !important; flex-wrap: wrap;
    }
    .glct-tag-filter-lbl {
        font-size: .75rem; font-weight: 700; color: var(--ink4); text-transform: uppercase; letter-spacing: .4px;
    }
    .glct-tag-pill {
        font-size: .75rem; font-weight: 600; padding: 5px 14px !important;
        border-radius: var(--r99); border: 1px solid var(--border2);
        background: var(--white); color: var(--ink3); cursor: pointer;
        transition: all .14s;
    }
    .glct-tag-pill:hover { border-color: var(--blue-bd); color: var(--blue); }
    .glct-tag-pill--active {
        background: var(--blue); color: #fff; border-color: var(--blue);
    }
    .glct-tag-pill--active:hover { background: var(--blue-h); }

    /* ── Activity Feed ───────────────────────────────────── */
    .glct-activity-section {
        border-top: 1px solid var(--border); padding-top: 16px !important; margin-top: 14px !important; flex-shrink: 0;
    }
    .glct-activity-btn {
        display: flex; align-items: center; gap: 6px; width: 100%;
        background: none; border: none; cursor: pointer;
        font-size: .85rem; font-weight: 600; color: var(--ink3);
        padding: 6px 0 !important; transition: color .14s;
    }
    .glct-activity-btn:hover { color: var(--blue); }
    .glct-activity-chev { transition: transform .2s; }
    .glct-activity-btn.is-open .glct-activity-chev { transform: rotate(180deg); }
    .glct-activity-body {
        max-height: 200px; overflow-y: auto; margin-top: 8px !important;
        border: 1px solid var(--border); border-radius: var(--r6);
        background: var(--surface);
    }
    .glct-activity-list { padding: 4px 0 !important; }
    .glct-activity-item {
        display: flex; align-items: flex-start; gap: 8px; padding: 8px 14px !important;
        border-bottom: 1px solid var(--surface2);
    }
    .glct-activity-item:last-child { border-bottom: none; }
    .glct-activity-ico { font-size: .75rem; flex-shrink: 0; margin-top: 2px !important; }
    .glct-activity-content { flex: 1; min-width: 0; }
    .glct-activity-desc { display: block; font-size: .82rem; font-weight: 600; color: var(--ink2); }
    .glct-activity-meta { display: block; font-size: .72rem; color: var(--ink4); margin-top: 2px !important; }

    /* ── Course Expansion ────────────────────────────────── */
    .glct-expansion {
        margin-top: 20px !important;
        border: 1px dashed var(--border2);
        border-radius: var(--r8);
        background: var(--white);
        overflow: hidden;
    }
    .glct-expansion-toggle {
        display: flex; align-items: center; gap: 8px; width: 100%;
        background: none; border: none; cursor: pointer;
        font-size: .88rem; font-weight: 600; color: var(--blue);
        padding: 14px 18px !important; transition: background .14s;
    }
    .glct-expansion-toggle:hover { background: var(--blue-bg); }
    .glct-expansion-chev { transition: transform .2s; margin-left: auto; }
    .glct-expansion-toggle.is-open .glct-expansion-chev { transform: rotate(180deg); }
    .glct-expansion-body {
        border-top: 1px solid var(--border);
        padding: 16px 18px !important;
    }
    .glct-expansion-filters {
        display: flex; align-items: center; gap: 8px; margin-bottom: 14px !important; flex-wrap: wrap;
    }
    .glct-expansion-list {
        max-height: 400px; overflow-y: auto;
    }
    .glct-exp-course {
        display: flex; align-items: center; justify-content: space-between; gap: 12px;
        padding: 10px 14px !important;
        border: 1px solid var(--border);
        border-radius: var(--r6);
        margin-bottom: 8px !important;
        background: var(--surface);
        transition: border-color .14s, background .14s;
    }
    .glct-exp-course:hover { border-color: var(--blue-bd); background: var(--blue-bg); }
    .glct-exp-course-info { flex: 1; min-width: 0; }
    .glct-exp-course-title {
        display: block; font-size: .88rem; font-weight: 600; color: var(--ink);
    }
    .glct-exp-course-tags {
        display: flex; gap: 6px; margin-top: 4px !important; flex-wrap: wrap;
    }
    .glct-exp-tag {
        font-size: .68rem; font-weight: 600; padding: 2px 8px !important;
        border-radius: var(--r99); background: var(--blue-bg); color: var(--blue);
        border: 1px solid var(--blue-bd);
    }
    .glct-exp-add-btn {
        flex-shrink: 0; padding: 8px 16px !important;
        font-size: .8rem; font-weight: 600; color: var(--white);
        background: var(--green); border: none; border-radius: var(--r6);
        cursor: pointer; transition: background .14s;
        display: flex; align-items: center; gap: 6px;
    }
    .glct-exp-add-btn:hover { background: #096b4f; }
    .glct-exp-add-btn:disabled { opacity: .5; cursor: default; }
    .glct-exp-empty {
        text-align: center; padding: 24px 0 !important; color: var(--ink4); font-size: .88rem;
    }

    /* ── Group selector ───────────────────────────────────── */
    .glct-group-selector {
        display: flex;
        align-items: center;
        gap: 14px;
        margin-top: 16px !important;
        margin-bottom: 32px !important;
        padding: 16px 20px !important;
        background: var(--white);
        border: 1px solid var(--border);
        border-radius: var(--r6);
        box-shadow: var(--sh-sm);
        flex-wrap: wrap;
    }
    .glct-selector-label {
        display: flex;
        align-items: center;
        gap: 7px;
        font-size: .82rem;
        font-weight: 700;
        color: var(--ink3);
        text-transform: uppercase;
        letter-spacing: .5px;
        white-space: nowrap;
        flex-shrink: 0;
    }
    .glct-selector-wrap {
        position: relative;
        flex: 1;
        min-width: 200px;
    }
    .glct-select {
        width: 100%;
        appearance: none;
        -webkit-appearance: none;
        font-family: inherit;
        font-size: .9rem;
        font-weight: 600;
        color: var(--ink);
        background: var(--surface);
        border: 1px solid var(--border2);
        border-radius: var(--r6);
        padding: 10px 36px 10px 12px !important;
        cursor: pointer;
        transition: border-color .15s, box-shadow .15s;
    }
    .glct-select:focus {
        outline: none;
        border-color: var(--blue);
        box-shadow: 0 0 0 3px rgba(61,99,221,.1);
    }
    .glct-select:hover { background: var(--white); }
    .glct-select-chevron {
        position: absolute;
        right: 11px; top: 50%;
        transform: translateY(-50%);
        pointer-events: none;
        color: var(--ink4);
        display: flex; align-items: center;
    }

    /* ── Responsive ───────────────────────────────────────── */

    /* Tablet-ish compact (481–768px): tighten modals, cards, selector */
    @media (min-width:481px) {
        .glct-cards .glct-card .glct-card-info {
            padding: 16px !important;
        }
        #glct-modal-users .glct-modal--wide {
            padding: 16px !important;
        }
        #glct-modal-confirm .glct-modal {
            padding: 16px !important;
        }
        #glct-modal-audit .glct-modal--wide {
            padding: 16px !important;
        }
    }
    @media (min-width:681px) {
        .glct-cards .glct-card .glct-card-controls {
            padding: 8px !important;
        }
        #glct-app .glct-group-selector {
            padding: 8px !important;
            margin-bottom: 16px !important;
        }
    }

    /* Tablet (max 1024px) — keep 2-col cards but tighten */
    @media (max-width: 1024px) {
        #glct-app { padding: 28px 24px 48px !important; }
        .glct-card { grid-template-columns: 1fr 180px; }
        .glct-card-controls { padding: 14px 12px !important; gap: 10px; }
        .glct-card-info { padding: 16px 18px !important; }
        .glct-modal { max-width: 440px; }
        .glct-modal--wide { max-width: 640px; }
    }

    /* Small tablet / large phone (max 768px) — stack cards */
    @media (max-width: 768px) {
        #glct-app { padding: 20px 16px 48px !important; }
        .glct-header { flex-direction: column; align-items: stretch; gap: 12px; }
        .glct-header-right { flex-direction: column; margin-left: 0 !important; width: 100%; gap: 8px; }
        .glct-global-search-wrap { max-width: none; width: 100%; }
        #glct-global-search { width: 100% !important; }
        .glct-group-selector { padding: 12px 16px !important; gap: 10px; margin-bottom: 20px !important; flex-direction: column; align-items: stretch; }
        .glct-selector-wrap { min-width: 0; width: 100%; }
        .glct-select { width: 100%; }
        .glct-card { grid-template-columns: 1fr; }
        .glct-card-controls {
            border-left: none;
            border-top: 1px solid var(--border);
            padding: 16px 18px !important; gap: 12px;
        }
        .glct-stats-bar { gap: 8px; }
        .glct-stat { padding: 10px 12px !important; min-width: 70px; }
        .glct-stat-val { font-size: 1.2rem; }
        .glct-stat-lbl { font-size: .65rem; }
        /* Tag filter: horizontal scroll on small screens */
        .glct-tag-filter { flex-wrap: nowrap; overflow-x: auto; -webkit-overflow-scrolling: touch; padding-bottom: 4px !important; }
        .glct-tag-pill { white-space: nowrap; flex-shrink: 0; }
        /* Modal fills more of the screen */
        .glct-modal { max-width: 95vw; }
        .glct-modal--wide { max-width: 95vw; min-height: 50vh; padding: 24px 20px 32px !important; }
        /* Members card list */
        #glct-users-body { min-height: 240px; }
        .glct-member-card { padding: 10px 14px !important; }
        .glct-overlay { padding: 12px !important; }
        /* Touch-friendly tap targets */
        .glct-btn { min-height: 44px; }
        .glct-btn-half { min-height: 44px; padding: 10px 14px !important; }
        .glct-toggle-row { gap: 14px; }
        .glct-tag-select { padding: 8px !important; font-size: .82rem; }
        .glct-course-search { padding: 12px 14px 12px 38px !important; font-size: .92rem; }
        #glct-audit-btn { min-height: 44px; }
        .glct-refresh-btn.glct-btn--sm { min-height: 36px; }
        .glct-member-count { padding: 6px 8px !important; }
    }

    /* Phone (max 480px) — compact everything */
    @media (max-width: 480px) {
        #glct-app { padding: 16px 12px 40px !important; }
        .glct-header { gap: 10px; }
        .glct-header-icon { width: 40px; height: 40px; font-size: 1.2rem; }
        .glct-header-title { font-size: 1.1rem; }
        .glct-card-info { padding: 14px 16px !important; gap: 6px; }
        .glct-card-controls { padding: 14px 16px !important; gap: 10px; }
        .glct-card-title { font-size: .88rem; }
        .glct-card-excerpt { font-size: .8rem; }
        .glct-card-link { font-size: .75rem; }
        /* Members card list on phone */
        #glct-users-body { min-height: 180px; max-height: 40vh; }
        .glct-member-card { padding: 10px 12px !important; gap: 8px; }
        .glct-user-name { font-size: .85rem; }
        .glct-user-email { font-size: .72rem; }
        .glct-member-progress { min-width: 80px; }
        .glct-progress-bar-wrap { min-width: 40px; }
        .glct-compliance-grid { grid-template-columns: 1fr; }
        .glct-compliance-stats { flex-direction: column; }
        .glct-compliance-stat-card { min-width: auto; }
        .glct-compliance-header { flex-direction: column; gap: 10px; align-items: flex-start !important; }
        .glct-deadline-row { flex-wrap: wrap; }
        /* Modals: near-fullscreen on phone */
        .glct-overlay { padding: 8px !important; align-items: flex-end; }
        .glct-modal {
            max-width: 100%; width: 100%;
            padding: 24px 20px 28px !important;
            border-radius: var(--r8) var(--r8) 0 0;
            max-height: 92vh;
        }
        .glct-modal--wide {
            max-width: 100%; width: 100%;
            padding: 20px 16px 28px !important;
            border-radius: var(--r8) var(--r8) 0 0;
            max-height: 92vh;
        }
        .glct-modal-emoji { font-size: 20px; margin-bottom: 12px !important; }
        .glct-modal-h { font-size: 1.05rem; margin-bottom: 8px !important; }
        .glct-modal-row { flex-direction: column-reverse; margin-top: 20px !important; }
        .glct-btn { width: 100%; justify-content: center; min-height: 48px; font-size: .88rem; }
        /* Stats bar: 2x2 grid on phone */
        .glct-stats-bar { display: grid !important; grid-template-columns: 1fr 1fr; gap: 8px; }
        .glct-stat { min-width: 0; padding: 10px !important; }
        .glct-stat-val { font-size: 1.1rem; }
        /* Group header */
        .glct-group-header { flex-wrap: wrap; gap: 8px; }
        .glct-group-name { font-size: .92rem; }
        /* Fields */
        .glct-field { margin-bottom: 14px !important; }
        .glct-input, .glct-textarea { font-size: .88rem; padding: 10px !important; }
        /* Notification */
        .glct-notify { padding-top: 18px !important; }
        .glct-notify-title { font-size: .88rem; }
        .glct-notify-hint { font-size: .8rem; margin-bottom: 14px !important; }
        /* Audit table */
        .glct-table th { font-size: .68rem; padding: 6px 8px !important; }
        .glct-table td { padding: 6px 8px !important; }
        /* Toasts */
        #glct-toasts { bottom: 12px !important; right: 12px !important; left: 12px; }
        .glct-toast { max-width: none; min-width: 0; font-size: .82rem; padding: 10px 14px !important; }
        /* Activity */
        .glct-activity-item { padding: 6px 10px !important; }
        .glct-activity-desc { font-size: .78rem; }
        .glct-activity-meta { font-size: .68rem; }
    }

    /* Very small phone (max 375px) — iPhone SE/Mini */
    @media (max-width: 375px) {
        #glct-app { padding: 12px 10px 36px !important; }
        .glct-header-title { font-size: 1rem; }
        .glct-header-sub { font-size: .78rem; }
        .glct-card-info { padding: 12px 14px !important; }
        .glct-card-controls { padding: 12px 14px !important; }
        .glct-card-title { font-size: .84rem; }
        .glct-modal { padding: 20px 16px 24px !important; }
        .glct-modal--wide { padding: 16px 14px 24px !important; }
        .glct-stats-bar { gap: 6px; }
        .glct-stat { padding: 8px 6px !important; }
        .glct-stat-val { font-size: 1rem; }
        .glct-stat-lbl { font-size: .6rem; }
        .glct-group-name { font-size: .85rem; }
        .glct-btn { font-size: .82rem; min-height: 44px; }
        .glct-btn-half { font-size: .8rem; padding: 8px 10px !important; }
        /* Member cards on tiny phone */
        .glct-member-card { padding: 8px 10px !important; gap: 6px; }
        .glct-user-name { font-size: .82rem; }
        .glct-user-email { font-size: .68rem; }
    }
    
    </style>

    <script>
    /* ═══════════════════════════════════════════════════════════
       GLCT Front-end — vanilla JS, no dependencies
    ═══════════════════════════════════════════════════════════ */
    (function () {
        'use strict';

        var AJAX  = <?php echo wp_json_encode( $ajax_url ); ?>;
        var NONCE = <?php echo wp_json_encode( $nonce ); ?>;
        var PAGE_LIMIT = <?php echo wp_json_encode( $page_limit ); ?>;

        /* ── XHR helper ─────────────────────────────────── */
        function post(action, data, cb) {
            data.action = action;
            data.nonce  = NONCE;

            var body = Object.keys(data).map(function (k) {
                var v = (typeof data[k] === 'object') ? JSON.stringify(data[k]) : data[k];
                return encodeURIComponent(k) + '=' + encodeURIComponent(v);
            }).join('&');

            var xhr = new XMLHttpRequest();
            xhr.open('POST', AJAX, true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onload = function () {
                try { cb(JSON.parse(xhr.responseText)); }
                catch (e) { cb({ success: false, data: { message: 'Server error.' } }); }
            };
            xhr.onerror = function () { cb({ success: false, data: { message: 'Network error.' } }); };
            xhr.send(body);
        }

        /* ── Toast ──────────────────────────────────────── */
        function toast(msg, ok) {
            var el = document.createElement('div');
            el.className = 'glct-toast';
            el.innerHTML = '<span class="glct-toast-ico">' + (ok ? '✅' : '❌') + '</span>'
                         + '<span class="glct-toast-text">' + esc(msg) + '</span>';
            document.getElementById('glct-toasts').appendChild(el);
            setTimeout(function () {
                el.style.transition = 'opacity .3s, transform .3s';
                el.style.opacity    = '0';
                el.style.transform  = 'translateX(30px)';
            }, 3400);
            setTimeout(function () { el.remove(); }, 3750);
        }

        /* ── Modal helpers ──────────────────────────────── */
        function openModal(id) {
            document.getElementById(id).hidden = false;
            document.body.style.overflow = 'hidden';
        }
        function closeModal(id) {
            document.getElementById(id).hidden = true;
            var open = document.querySelectorAll('.glct-overlay:not([hidden])');
            if (!open.length) document.body.style.overflow = '';
        }

        document.querySelectorAll('.glct-overlay').forEach(function (wrap) {
            wrap.addEventListener('click', function (e) {
                if (e.target === wrap) closeModal(wrap.id);
            });
        });

        document.addEventListener('keydown', function (e) {
            if (e.key !== 'Escape') return;
            var open = document.querySelectorAll('.glct-overlay:not([hidden])');
            if (open.length) closeModal(open[open.length - 1].id);
        });

        /* ── Confirm dialog ─────────────────────────────── */
        var _confirmCb = null;

        function glctConfirm(emoji, title, body, label, danger, showWipe, cb) {
            document.getElementById('glct-conf-emoji').textContent = emoji;
            document.getElementById('glct-conf-title').textContent = title;
            document.getElementById('glct-conf-body').textContent  = body;
            
            var wipeWrap = document.getElementById('glct-conf-wipe-wrap');
            var wipeInp = document.getElementById('glct-conf-wipe-inp');
            if (wipeWrap) {
                if (showWipe) {
                    wipeWrap.hidden = false;
                    wipeInp.checked = false;
                } else {
                    wipeWrap.hidden = true;
                }
            }

            var ok = document.getElementById('glct-conf-ok');
            ok.textContent = label;
            ok.className   = 'glct-btn glct-btn--solid' + (danger ? ' is-danger' : '');
            _confirmCb     = cb;
            openModal('glct-modal-confirm');
        }

        document.getElementById('glct-conf-cancel').onclick = function () {
            closeModal('glct-modal-confirm');
            _confirmCb = null;
        };
        document.getElementById('glct-conf-ok').onclick = function () {
            closeModal('glct-modal-confirm');
            if (_confirmCb) { _confirmCb(); _confirmCb = null; }
        };
        
        /* ── Live Stats + Tag Filter Refresh ───────────── */
        function refreshGroupStats(groupEl) {
            if (!groupEl) return;
            var cards    = groupEl.querySelectorAll('.glct-card');
            var total    = cards.length;
            var active   = 0;
            var disabled = 0;
            cards.forEach(function (c) {
                if (c.classList.contains('glct-card--on'))  active++;
                if (c.classList.contains('glct-card--off')) disabled++;
            });
            var statsBar = groupEl.querySelector('.glct-stats-bar');
            if (statsBar) {
                var vals = statsBar.querySelectorAll('.glct-stat-val');
                if (vals[0]) vals[0].textContent = total;
                if (vals[1]) vals[1].textContent = active;
                if (vals[2]) vals[2].textContent = disabled;
                // vals[3] = Members — doesn't change on toggle/tag
            }
        }

        function refreshTagFilterBar(groupEl) {
            if (!groupEl) return;
            var cards = groupEl.querySelectorAll('.glct-card');
            var usedTags = [];
            cards.forEach(function (c) {
                var t = c.dataset.tag;
                if (t && usedTags.indexOf(t) === -1) usedTags.push(t);
            });

            var existing = groupEl.querySelector('.glct-tag-filter');

            // No tags in use → remove filter bar if it exists
            if (usedTags.length === 0) {
                if (existing) existing.remove();
                return;
            }

            // Build or replace filter bar
            var bar = document.createElement('div');
            bar.className = 'glct-tag-filter';
            bar.dataset.gid = groupEl.id.replace('glct-group-', '');

            var lbl = document.createElement('span');
            lbl.className = 'glct-tag-filter-lbl';
            lbl.textContent = 'Filter:';
            bar.appendChild(lbl);

            var allPill = document.createElement('button');
            allPill.className = 'glct-tag-pill glct-tag-pill--active';
            allPill.dataset.tag = 'all';
            allPill.textContent = 'All';
            bar.appendChild(allPill);

            usedTags.forEach(function (t) {
                var pill = document.createElement('button');
                pill.className = 'glct-tag-pill';
                pill.dataset.tag = t;
                pill.textContent = t;
                bar.appendChild(pill);
            });

            // Bind click events
            bar.querySelectorAll('.glct-tag-pill').forEach(function (pill) {
                pill.addEventListener('click', function () {
                    bar.querySelectorAll('.glct-tag-pill').forEach(function (p) { p.classList.remove('glct-tag-pill--active'); });
                    pill.classList.add('glct-tag-pill--active');
                    var tag = pill.dataset.tag;
                    groupEl.querySelectorAll('.glct-card').forEach(function (card) {
                        if (tag === 'all') { card.style.display = ''; }
                        else { card.style.display = (card.dataset.tag === tag) ? '' : 'none'; }
                    });
                });
            });

            if (existing) {
                existing.replaceWith(bar);
            } else {
                // Insert before the search bar
                var searchBar = groupEl.querySelector('.glct-search-bar');
                if (searchBar) {
                    searchBar.parentNode.insertBefore(bar, searchBar);
                }
            }
        }

        /* ── Sync Group (Refresh) ───────────────────────── */
        document.querySelectorAll('.glct-refresh-btn').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var gid = btn.dataset.gid;
                var sp = document.createElement('span');
                sp.className = 'glct-spin';
                btn.disabled = true;
                btn.appendChild(sp);
                
                post('glct_refresh_group', { group_id: gid }, function(res) {
                    if (res.success) {
                        toast(res.data.message, true);
                        setTimeout(function(){ window.location.reload(); }, 800);
                    } else {
                        btn.disabled = false;
                        sp.remove();
                        toast(res.data.message || 'Error syncing group.', false);
                    }
                });
            });
        });

        /* ── Remove Course ──────────────────────────────── */
        document.querySelectorAll('.glct-remove-course-btn').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var gid = btn.dataset.gid;
                var cid = btn.dataset.cid;
                var name = btn.dataset.name;
                
                glctConfirm(
                    '🗑️',
                    'Remove "' + esc(name) + '"?',
                    'Are you sure you want to remove this course from the group? This will permanently remove the course and unenroll all group members.',
                    'Yes, Remove Course',
                    true,
                    false,
                    function() {
                        var card = btn.closest('.glct-card');
                        card.style.opacity = '0.5';
                        post('glct_remove_course', { group_id: gid, course_id: cid }, function(res) {
                            if (res.success) {
                                card.style.transition = 'opacity 0.3s, transform 0.3s';
                                card.style.opacity = '0';
                                card.style.transform = 'scale(0.95)';
                                setTimeout(function(){ card.remove(); }, 300);
                                toast(res.data.message, true);
                            } else {
                                card.style.opacity = '1';
                                toast(res.data.message || 'Error removing course.', false);
                            }
                        });
                    }
                );
            });
        });

        /* ── Pagination (Load More) ─────────────────────── */
        function initPagination() {
            document.querySelectorAll('.glct-group').forEach(function(group) {
                var cards = group.querySelectorAll('.glct-card');
                var total = cards.length;
                var limit = PAGE_LIMIT;
                if (total > limit) {
                    cards.forEach(function(c, i) { if(i >= limit) c.style.display = 'none'; });
                    var shown = limit;
                    var btn = document.createElement('button');
                    btn.className = 'glct-btn glct-btn--ghost glct-load-more';
                    btn.dataset.shown = String(shown);
                    btn.style.width = '100%';
                    btn.style.marginTop = '16px';
                    var hidden = total - shown;
                    btn.innerHTML = 'Load More Courses &nbsp; <span class="glct-load-more-count" style="background:var(--surface2); color:var(--ink3); padding:2px 8px; border-radius:10px; font-size:12px;">' + hidden + ' hidden</span>';
                    btn.onclick = function() {
                        var nextShown = Math.min(shown + limit, total);
                        var allCards = group.querySelectorAll('.glct-card');
                        allCards.forEach(function(c, i) {
                            if (i < nextShown) c.style.display = '';
                        });
                        shown = nextShown;
                        btn.dataset.shown = String(shown);
                        var remaining = total - shown;
                        if (remaining <= 0) {
                            btn.remove();
                        } else {
                            var countSpan = btn.querySelector('.glct-load-more-count');
                            if (countSpan) countSpan.textContent = remaining + ' hidden';
                        }
                    };
                    group.querySelector('.glct-cards').after(btn);
                }
            });
        }
        initPagination();

        /* ── Group toggle ───────────────────────────────── */
        document.querySelectorAll('.glct-toggle-inp[data-action="group"]').forEach(function (inp) {
            inp.addEventListener('change', function () { handleGroup(inp); });
        });

        function handleGroup(inp) {
            var gid   = inp.dataset.gid;
            var cid   = inp.dataset.cid;
            var name  = inp.dataset.name;
            var wasOn = inp.dataset.on === '1';

            inp.checked = wasOn;

            glctConfirm(
                wasOn ? '🔒' : '🔓',
                (wasOn ? 'Disable' : 'Enable') + ' "' + esc(name) + '"?',
                wasOn
                    ? 'This will disable the course for the group (users explicitly granted access will keep it).'
                    : 'This will enable the course for the group (blocked users will stay blocked).',
                wasOn ? 'Yes, Disable' : 'Yes, Enable',
                wasOn,
                !wasOn, 
                function () {
                    var nowOn = !wasOn;
                    var wipeInp = document.getElementById('glct-conf-wipe-inp');
                    var doWipe = wipeInp ? wipeInp.checked : false;

                    inp.checked      = nowOn;
                    inp.dataset.on   = nowOn ? '1' : '0';
                    inp.disabled     = true;
                    applyCardState(inp, nowOn);

                    // Show a spinner next to the toggle while saving
                    var toggleWrap = inp.closest('.glct-toggle-row');
                    var spin = document.createElement('span');
                    spin.className = 'glct-toggle-spin';
                    if (toggleWrap) toggleWrap.appendChild(spin);

                    post('glct_toggle_group', { group_id: gid, course_id: cid, wipe_progress: doWipe ? 1 : 0 }, function (res) {
                        inp.disabled = false;
                        if (spin.parentNode) spin.remove();
                        if (res.success) {
                            if (res.data.enabled !== nowOn) {
                                inp.checked    = res.data.enabled;
                                inp.dataset.on = res.data.enabled ? '1' : '0';
                                applyCardState(inp, res.data.enabled);
                            }
                            toast(res.data.message, true);
                            // Auto-refresh stats
                            var groupEl = inp.closest('.glct-group');
                            refreshGroupStats(groupEl);
                        } else {
                            inp.checked    = wasOn;
                            inp.dataset.on = wasOn ? '1' : '0';
                            applyCardState(inp, wasOn);
                            toast(res.data.message || 'Something went wrong.', false);
                        }
                    });
                }
            );
        }

        function applyCardState(inp, nowOn) {
            var card  = inp.closest('.glct-card');
            var badge = card.querySelector('.glct-badge');
            var time  = card.querySelector('.glct-card-time');

            card.classList.toggle('glct-card--on',  nowOn);
            card.classList.toggle('glct-card--off', !nowOn);

            badge.className   = 'glct-badge ' + (nowOn ? 'glct-badge--on' : 'glct-badge--off');
            badge.innerHTML   = '<span class="glct-badge-dot"></span>' + (nowOn ? 'Group Active' : 'Group Inactive');

            if (time) time.textContent = 'Last changed just now';
        }

        /* ── Per-user modal ─────────────────────────────── */
        var MS = { gid: null, cid: null, members: [] };

        document.getElementById('glct-users-close').addEventListener('click', function () {
            closeModal('glct-modal-users');
        });

        document.querySelectorAll('.glct-user-btn').forEach(function (btn) {
            btn.addEventListener('click', function () {
                MS.gid     = btn.dataset.gid;
                MS.cid     = btn.dataset.cid;
                MS.members = [];
                actLoaded  = false; // Reset activity feed for new course

                var searchInp = document.getElementById('glct-member-search');
                if(searchInp) searchInp.value = '';
                if (actBody) { actBody.hidden = true; actBody.innerHTML = ''; }
                if (actToggle) actToggle.classList.remove('is-open');

                document.getElementById('glct-users-course').textContent = btn.dataset.name;
                document.getElementById('glct-users-body').innerHTML     = '<p style="padding:14px 0;color:#94a3b8">Loading members…</p>';
                document.getElementById('glct-member-search-wrap').hidden = true;

                var recipList = document.getElementById('glct-recip-list');
                if (recipList) recipList.innerHTML = '';
                var recipDd = document.getElementById('glct-recip-dropdown');
                if (recipDd) recipDd.hidden = true;
                var recipLabel = document.getElementById('glct-recip-label');
                if (recipLabel) recipLabel.textContent = 'Select recipients\u2026';

                openModal('glct-modal-users');

                post('glct_get_members', { group_id: MS.gid, course_id: MS.cid }, function (res) {
                    if (!res.success) {
                        document.getElementById('glct-users-body').innerHTML = '<p style="color:#dc2626;padding:12px 0">Failed to load members.</p>';
                        return;
                    }
                    MS.members = res.data.members;
                    buildTable(res.data.members);
                    if (typeof buildChips === 'function') buildChips(res.data.members);
                });
            });
        });

        function buildTable(members) {
            var wrap = document.getElementById('glct-users-body');
            var searchWrap = document.getElementById('glct-member-search-wrap');

            if (!members.length) {
                wrap.innerHTML = '<p style="padding:14px 0;color:#94a3b8">No members in this group.</p>';
                searchWrap.hidden = true;
                return;
            }

            searchWrap.hidden = false;

            var allowWipe = <?php echo $allow_wipe ? 'true' : 'false'; ?>;
            var html = '<div class="glct-member-list">';

            members.forEach(function (m) {
                var wipeBtn = allowWipe ? '<button class="glct-wipe-btn" data-uid="' + m.id + '" title="Wipe Course Progress"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"></path><path d="M3 3v5h5"></path></svg></button>' : '';

                // Progress column
                var progressHtml = '';
                if (typeof m.progress !== 'undefined') {
                    if (m.progress_status === 'completed') {
                        progressHtml = '<span class="glct-progress-badge glct-progress-badge--done">Completed &#10003;</span>';
                    } else if (m.progress_status === 'not_started') {
                        progressHtml = '<span class="glct-progress-badge glct-progress-badge--none">Not Started</span>';
                    } else {
                        progressHtml = '<div class="glct-progress-bar-wrap"><div class="glct-progress-bar" style="width:' + m.progress + '%"></div></div>'
                            + '<span class="glct-progress-pct">' + m.progress + '%</span>';
                    }
                }

                html += '<div class="glct-member-card" data-uid="' + m.id + '" data-name="' + esc(m.name) + '" data-email="' + esc(m.email) + '">'
                    + '<div class="glct-member-info">'
                    + '<span class="glct-user-name">' + esc(m.name) + '</span>'
                    + '<span class="glct-user-email">' + esc(m.email) + '</span>'
                    + '</div>'
                    + (progressHtml ? '<div class="glct-member-progress">' + progressHtml + '</div>' : '')
                    + '<div class="glct-member-actions">'
                    + '<label class="glct-toggle" style="margin:0;">'
                    + '<input type="checkbox" class="glct-toggle-inp" data-action="user" data-uid="' + m.id + '"' + (m.enabled ? ' checked' : '') + '>'
                    + '<span class="glct-track"><span class="glct-thumb"></span></span>'
                    + '</label>'
                    + wipeBtn
                    + '</div>'
                    + '</div>';
            });
            html += '</div>';
            wrap.innerHTML = html;

            wireUserToggles();
            wireMemberSearch();
        }

        function wireUserToggles() {
            var wrap = document.getElementById('glct-users-body');
            
            wrap.querySelectorAll('.glct-toggle-inp').forEach(function (inp) {
                inp.addEventListener('change', function () { doUserToggle(inp); });
            });
            
            wrap.querySelectorAll('.glct-wipe-btn').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    if(!confirm("Are you sure you want to permanently delete this course's progress and test scores for this user?")) return;
                    var uid = btn.dataset.uid;
                    btn.disabled = true;
                    post('glct_wipe_progress', { group_id: MS.gid, course_id: MS.cid, user_id: uid }, function(res) {
                        btn.disabled = false;
                        toast(res.success ? res.data.message : 'Error wiping progress', res.success);
                    });
                });
            });
        }

        function wireMemberSearch() {
            var inp = document.getElementById('glct-member-search');
            if (!inp) return;
            inp.removeEventListener('input', handleMemberSearch);
            inp.addEventListener('input', handleMemberSearch);
        }

        function handleMemberSearch(e) {
            var term = e.target.value.toLowerCase().trim();
            var cards = document.querySelectorAll('#glct-users-body .glct-member-card');
            cards.forEach(function(card) {
                if (!term) { card.style.display = ''; return; }
                var name  = (card.dataset.name  || '').toLowerCase();
                var email = (card.dataset.email || '').toLowerCase();
                card.style.display = (name.indexOf(term) > -1 || email.indexOf(term) > -1) ? '' : 'none';
            });
        }

        function doUserToggle(inp) {
            var uid   = inp.dataset.uid;
            var desiredState = inp.checked;

            inp.disabled = true;

            post('glct_toggle_user', { group_id: MS.gid, course_id: MS.cid, user_id: uid, state: desiredState ? 1 : 0 }, function (res) {
                inp.disabled = false;
                if (res.success) {
                    inp.checked = res.data.enabled;
                    MS.members.forEach(function (m) { if (String(m.id) === uid) m.enabled = res.data.enabled; });
                    toast(res.data.message, true);
                } else {
                    inp.checked = !desiredState; 
                    toast(res.data.message || 'Error.', false);
                }
            });
        }
        
        /* ── Bulk Actions ───────────────────────────────── */
        document.getElementById('glct-bulk-on').addEventListener('click', function() { doBulkToggle(true); });
        document.getElementById('glct-bulk-off').addEventListener('click', function() { doBulkToggle(false); });
        
        function doBulkToggle(state) {
            if(!MS.gid || !MS.cid) return;
            var label = state ? "Enable All" : "Disable All";
            if(!confirm("Are you sure you want to " + label + " users for this course?")) return;

            var btn = state ? document.getElementById('glct-bulk-on') : document.getElementById('glct-bulk-off');
            btn.disabled = true;
            var spin = document.createElement('span');
            spin.className = 'glct-spin';
            btn.appendChild(spin);

            post('glct_bulk_user_toggle', { group_id: MS.gid, course_id: MS.cid, state: state ? 1 : 0 }, function(res) {
                btn.disabled = false;
                if (spin.parentNode) spin.remove();
                if (res.success) {
                    toast(res.data.message, true);
                    document.querySelectorAll('#glct-users-body .glct-toggle-inp').forEach(function(inp) {
                        inp.checked = state;
                    });
                    MS.members.forEach(function (m) { m.enabled = state; });
                } else {
                    toast(res.data.message || 'Failed to update all users.', false);
                }
            });
        }

        /* ── Front End Audit Log ────────────────────────── */
        var auditBtn = document.getElementById('glct-audit-btn');
        if (auditBtn) {
            auditBtn.addEventListener('click', function() {
                var body = document.getElementById('glct-audit-body');
                body.innerHTML = '<p style="padding:14px; color:var(--ink4);">Loading activity...</p>';
                openModal('glct-modal-audit');

                post('glct_get_audit_log', {}, function(res) {
                    if (res.success) {
                        body.innerHTML = res.data.html;
                    } else {
                        body.innerHTML = '<p style="padding:14px; color:var(--red);">Failed to load logs.</p>';
                    }
                });
            });
        }

        /* ── GL Activity Log CSV Export ──────────────────── */
        var exportBtn = document.getElementById('glct-audit-export');
        if (exportBtn) {
            exportBtn.addEventListener('click', function() {
                var url = AJAX + '?action=glct_export_gl_csv&nonce=' + encodeURIComponent(NONCE);
                window.location.href = url;
            });
        }

        /* ── GLOBAL USER SEARCH ─────────────────────────── */
        var gsTimer;
        var gsInput = document.getElementById('glct-global-search');
        var gsResults = document.getElementById('glct-global-results');
        
        if (gsInput) {
            gsInput.addEventListener('input', function() {
                clearTimeout(gsTimer);
                var term = gsInput.value.trim();
                if (term.length < 2) { gsResults.style.display = 'none'; return; }
                
                gsTimer = setTimeout(function() {
                    gsResults.innerHTML = '<div style="padding:10px 14px; color:var(--ink4);">Searching...</div>';
                    gsResults.style.display = 'block';
                    
                    post('glct_global_user_search', { term: term }, function(res) {
                        if (!res.success || !res.data.users.length) {
                            gsResults.innerHTML = '<div style="padding:10px 14px; color:var(--ink4);">No matching users found in your groups.</div>';
                            return;
                        }
                        var html = '';
                        res.data.users.forEach(function(u) {
                            html += '<div class="glct-global-result" data-uid="' + u.id + '">' + esc(u.name) + ' <span style="color:var(--ink4); font-size:12px; font-weight:400;">(' + esc(u.email) + ')</span></div>';
                        });
                        gsResults.innerHTML = html;
                        
                        gsResults.querySelectorAll('.glct-global-result').forEach(function(el) {
                            el.addEventListener('click', function() {
                                gsResults.style.display = 'none';
                                gsInput.value = '';
                                openGlobalUserModal(el.dataset.uid);
                            });
                        });
                    });
                }, 400);
            });
            
            document.addEventListener('click', function(e) {
                if (!gsInput.contains(e.target) && !gsResults.contains(e.target)) {
                    gsResults.style.display = 'none';
                }
            });
        }
        
        function openGlobalUserModal(uid) {
            var body = document.getElementById('glct-gu-body');
            document.getElementById('glct-gu-title').textContent = 'Loading...';
            document.getElementById('glct-gu-email').textContent = '';
            body.innerHTML = '<p style="padding:14px; color:var(--ink4);">Fetching user access data...</p>';
            openModal('glct-modal-global-user');
            
            post('glct_global_user_profile', { user_id: uid }, function(res) {
                if(!res.success) {
                    body.innerHTML = '<p style="padding:14px; color:var(--red);">' + (res.data.message || 'Error loading user.') + '</p>';
                    document.getElementById('glct-gu-title').textContent = 'User Not Found';
                    return;
                }
                document.getElementById('glct-gu-title').textContent = res.data.name;
                document.getElementById('glct-gu-email').textContent = res.data.email;
                body.innerHTML = res.data.html;
                
                // Wire toggles inside the global modal
                body.querySelectorAll('.glct-gu-toggle').forEach(function(inp) {
                    inp.addEventListener('change', function() {
                        var u = inp.dataset.uid;
                        var g = inp.dataset.gid;
                        var c = inp.dataset.cid;
                        var desiredState = inp.checked;
                        inp.disabled = true;
                        post('glct_toggle_user', { group_id: g, course_id: c, user_id: u, state: desiredState ? 1 : 0 }, function(r) {
                            inp.disabled = false;
                            if(r.success) {
                                inp.checked = r.data.enabled;
                                toast(r.data.message, true);
                            } else {
                                inp.checked = !desiredState;
                                toast(r.data.message || 'Error', false);
                            }
                        });
                    });
                });
                
                // Wire wipe buttons
                body.querySelectorAll('.glct-wipe-btn').forEach(function(btn) {
                    btn.addEventListener('click', function() {
                        if(!confirm("Are you sure you want to permanently delete this course's progress and test scores for this user?")) return;
                        var u = btn.dataset.uid;
                        var g = btn.dataset.gid;
                        var c = btn.dataset.cid;
                        btn.disabled = true;
                        post('glct_wipe_progress', { group_id: g, course_id: c, user_id: u }, function(r) {
                            btn.disabled = false;
                            toast(r.success ? r.data.message : 'Error wiping progress', r.success);
                        });
                    });
                });
            });
        }

        /* ── COURSE LIVE SEARCH + SORT ────────────────────── */
        document.querySelectorAll('.glct-group').forEach(function(groupSection) {
            var searchInput = groupSection.querySelector('.glct-course-search');
            var sortSelect  = groupSection.querySelector('.glct-course-sort');
            if (!searchInput) return;
            if (searchInput.id === 'glct-member-search' || searchInput.id === 'glct-global-search') return;

            var cardsContainer = groupSection.querySelector('.glct-cards');
            if (!cardsContainer) return;

            // Store original order index on each card
            var allCards = Array.from(cardsContainer.querySelectorAll('.glct-card'));
            allCards.forEach(function(c, i) { c.dataset.origIndex = String(i); });

            function getVisibleCards() {
                return Array.from(cardsContainer.querySelectorAll('.glct-card'));
            }

            function applySearchAndPagination() {
                var term = searchInput.value.trim().toLowerCase();
                var cards = getVisibleCards();
                var loadMore = groupSection.querySelector('.glct-load-more');
                var matched = 0;

                if (term) {
                    if (loadMore) loadMore.style.display = 'none';
                    cards.forEach(function(card) {
                        var titleEl = card.querySelector('.glct-card-title');
                        if (!titleEl) { card.style.display = 'none'; return; }
                        var title = titleEl.textContent.toLowerCase();
                        if (title.indexOf(term) > -1) {
                            card.style.display = '';
                            matched++;
                        } else {
                            card.style.display = 'none';
                        }
                    });
                } else {
                    // Clear search — respect pagination
                    var shown = 0;
                    cards.forEach(function(card) {
                        card.style.display = '';
                        shown++;
                    });
                    // Re-apply pagination if Load More exists
                    if (loadMore) {
                        loadMore.style.display = '';
                        var limit = parseInt(loadMore.dataset.shown, 10) || PAGE_LIMIT;
                        cards.forEach(function(card, i) {
                            card.style.display = i < limit ? '' : 'none';
                        });
                        var hidden = cards.length - limit;
                        if (hidden > 0) {
                            var countSpan = loadMore.querySelector('.glct-load-more-count');
                            if (countSpan) countSpan.textContent = hidden + ' hidden';
                            loadMore.style.display = '';
                        } else {
                            loadMore.style.display = 'none';
                        }
                    }
                }
            }

            function cardTitle(card) {
                var el = card.querySelector('.glct-card-title');
                return el ? el.textContent : '';
            }

            function applySortOrder(sortVal) {
                var cards = Array.from(cardsContainer.querySelectorAll('.glct-card'));
                cards.sort(function(a, b) {
                    switch (sortVal) {
                        case 'az':
                            return cardTitle(a).localeCompare(cardTitle(b));
                        case 'za':
                            return cardTitle(b).localeCompare(cardTitle(a));
                        case 'newest':
                            return (b.dataset.date || '').localeCompare(a.dataset.date || '');
                        case 'completion-high':
                            return (parseInt(b.dataset.completion, 10) || 0) - (parseInt(a.dataset.completion, 10) || 0);
                        case 'completion-low':
                            return (parseInt(a.dataset.completion, 10) || 0) - (parseInt(b.dataset.completion, 10) || 0);
                        case 'active':
                            var aActive = a.dataset.status === 'active' ? 0 : 1;
                            var bActive = b.dataset.status === 'active' ? 0 : 1;
                            return aActive - bActive || cardTitle(a).localeCompare(cardTitle(b));
                        case 'inactive':
                            var aInact = a.dataset.status === 'inactive' ? 0 : 1;
                            var bInact = b.dataset.status === 'inactive' ? 0 : 1;
                            return aInact - bInact || cardTitle(a).localeCompare(cardTitle(b));
                        default: // 'default' — restore original order
                            return parseInt(a.dataset.origIndex, 10) - parseInt(b.dataset.origIndex, 10);
                    }
                });
                // Re-append in sorted order
                cards.forEach(function(card) { cardsContainer.appendChild(card); });
                applySearchAndPagination();
            }

            searchInput.addEventListener('input', function() {
                applySearchAndPagination();
            });

            // Also trigger on 'search' event (fires when × clear button is clicked in some browsers)
            searchInput.addEventListener('search', function() {
                applySearchAndPagination();
            });

            if (sortSelect) {
                sortSelect.addEventListener('change', function() {
                    applySortOrder(sortSelect.value);
                });
            }
        });

        /* ── Notification — Recipient Dropdown ──────────── */
        var selIds = [];
        var _recipCache = null; // cache current members array

        (function initRecipDropdown() {
            var toggle = document.getElementById('glct-recip-toggle');
            var dd     = document.getElementById('glct-recip-dropdown');
            if (!toggle || !dd) return;

            // Attach toggle & outside-click listeners ONCE
            toggle.addEventListener('click', function (e) {
                e.stopPropagation();
                dd.hidden = !dd.hidden;
            });
            document.addEventListener('click', function (e) {
                if (!dd.hidden && !dd.contains(e.target) && e.target !== toggle) {
                    dd.hidden = true;
                }
            });
        }());

        function buildChips(members) {
            var list   = document.getElementById('glct-recip-list');
            var allCb  = document.getElementById('glct-recip-all-cb');
            var label  = document.getElementById('glct-recip-label');
            if (!list) return;

            _recipCache = members;
            selIds = members.map(function (m) { return m.id; });

            // Build HTML fragment for fast DOM insertion
            var frag = document.createDocumentFragment();
            for (var i = 0; i < members.length; i++) {
                var m = members[i];
                var lbl = document.createElement('label');
                lbl.className = 'glct-recip-item';
                var cb = document.createElement('input');
                cb.type = 'checkbox';
                cb.checked = true;
                cb.dataset.uid = m.id;
                lbl.appendChild(cb);
                lbl.appendChild(document.createTextNode(' ' + m.name + ' '));
                var sp = document.createElement('span');
                sp.style.cssText = 'color:var(--ink4);font-size:12px';
                sp.textContent = '(' + m.email + ')';
                lbl.appendChild(sp);
                frag.appendChild(lbl);
            }
            list.innerHTML = '';
            list.appendChild(frag);

            function updateLabel() {
                var total = members.length;
                label.textContent = selIds.length === total
                    ? 'All members (' + total + ')'
                    : selIds.length + ' of ' + total + ' selected';
                if (allCb) allCb.checked = selIds.length === total;
            }
            updateLabel();

            // Use event delegation on the list container (attach ONCE via replaceWith trick)
            var newList = list.cloneNode(true);
            list.parentNode.replaceChild(newList, list);
            newList.addEventListener('change', function (e) {
                var cb = e.target;
                if (cb.tagName !== 'INPUT') return;
                var uid = parseInt(cb.dataset.uid, 10);
                if (cb.checked) {
                    if (selIds.indexOf(uid) === -1) selIds.push(uid);
                } else {
                    selIds = selIds.filter(function (i) { return i !== uid; });
                }
                updateLabel();
            });

            // Select All — remove old listener by replacing node
            if (allCb) {
                var newAllCb = allCb.cloneNode(true);
                allCb.parentNode.replaceChild(newAllCb, allCb);
                newAllCb.addEventListener('change', function () {
                    var checked = newAllCb.checked;
                    selIds = checked ? members.map(function (m) { return m.id; }) : [];
                    newList.querySelectorAll('input[type="checkbox"]').forEach(function (cb) {
                        cb.checked = checked;
                    });
                    updateLabel();
                });
            }
        }

        var notifySendBtn = document.getElementById('glct-notify-send');
        if (notifySendBtn) {
            notifySendBtn.addEventListener('click', function () {
                if (!selIds.length)  { toast('Select at least one recipient.', false); return; }
                var subj = document.getElementById('glct-subj').value.trim();
                var body = document.getElementById('glct-body').value.trim();
                if (!subj || !body)  { toast('Subject and message are required.', false); return; }

                document.getElementById('glct-send-desc').textContent  = 'This will send an email to ' + selIds.length + ' recipient' + (selIds.length !== 1 ? 's' : '') + '.';
                document.getElementById('glct-prev-subj').textContent  = subj;
                document.getElementById('glct-prev-body').innerHTML    = body.replace(/\n/g, '<br>');
                openModal('glct-modal-send');
            });
        }

        var sendBackBtn = document.getElementById('glct-send-back');
        if(sendBackBtn) {
            sendBackBtn.onclick = function () { closeModal('glct-modal-send'); };
        }

        var sendGoBtn = document.getElementById('glct-send-go');
        if(sendGoBtn) {
            sendGoBtn.addEventListener('click', function () {
                var btn  = this;
                var subj = document.getElementById('glct-subj').value.trim();
                var body = document.getElementById('glct-body').value.trim();
                var sp   = document.createElement('span');
                sp.className = 'glct-spin';
                btn.disabled = true;
                btn.appendChild(sp);

                post('glct_send_notify', { group_id: MS.gid, course_id: MS.cid, user_ids: selIds, subject: subj, message: body }, function (res) {
                    btn.disabled = false;
                    sp.remove();
                    closeModal('glct-modal-send');
                    toast(res.success ? res.data.message : (res.data.message || 'Failed to send.'), res.success);
                });
            });
        }

        /* ── Activity Feed Toggle ──────────────────────── */
        var actToggle = document.getElementById('glct-activity-toggle');
        var actBody   = document.getElementById('glct-activity-body');
        var actLoaded = false;

        if (actToggle && actBody) {
            actToggle.addEventListener('click', function () {
                var isOpen = !actBody.hidden;
                actBody.hidden = isOpen;
                actToggle.classList.toggle('is-open', !isOpen);
                if (!isOpen && !actLoaded && MS.gid && MS.cid) {
                    actLoaded = true;
                    actBody.innerHTML = '<p style="padding:10px 14px;color:var(--ink4);font-size:.85rem;">Loading activity...</p>';
                    post('glct_get_course_activity', { group_id: MS.gid, course_id: MS.cid }, function (res) {
                        actBody.innerHTML = res.success ? res.data.html : '<p style="padding:10px 14px;color:var(--red);">Failed to load.</p>';
                    });
                }
            });
        }

        /* ── Tag Filter ────────────────────────────────── */
        document.querySelectorAll('.glct-tag-filter').forEach(function (bar) {
            bar.querySelectorAll('.glct-tag-pill').forEach(function (pill) {
                pill.addEventListener('click', function () {
                    bar.querySelectorAll('.glct-tag-pill').forEach(function (p) { p.classList.remove('glct-tag-pill--active'); });
                    pill.classList.add('glct-tag-pill--active');
                    var tag = pill.dataset.tag;
                    var group = bar.closest('.glct-group');
                    if (!group) return;
                    group.querySelectorAll('.glct-card').forEach(function (card) {
                        if (tag === 'all') {
                            card.style.display = '';
                        } else {
                            card.style.display = (card.dataset.tag === tag) ? '' : 'none';
                        }
                    });
                });
            });
        });

        /* ── Tag Assignment ────────────────────────────── */
        document.querySelectorAll('.glct-tag-select').forEach(function (sel) {
            sel.addEventListener('change', function () {
                var gid = sel.dataset.gid;
                var cid = sel.dataset.cid;
                var tag = sel.value;
                post('glct_set_course_tag', { group_id: gid, course_id: cid, tag: tag }, function (res) {
                    if (res.success) {
                        var card = sel.closest('.glct-card');
                        if (card) card.dataset.tag = res.data.tag || '';
                        // Update or add badge
                        var existing = card ? card.querySelector('.glct-course-tag') : null;
                        if (res.data.tag) {
                            if (existing) {
                                existing.textContent = res.data.tag;
                            } else if (card) {
                                var badgeWrap = card.querySelector('.glct-card-info > div');
                                if (badgeWrap) {
                                    var sp = document.createElement('span');
                                    sp.className = 'glct-course-tag';
                                    sp.textContent = res.data.tag;
                                    badgeWrap.appendChild(sp);
                                }
                            }
                        } else if (existing) {
                            existing.remove();
                        }
                        toast('Tag updated.', true);
                        // Auto-refresh tag filter bar and stats
                        var groupEl = sel.closest('.glct-group');
                        refreshTagFilterBar(groupEl);
                        refreshGroupStats(groupEl);
                    } else {
                        toast(res.data.message || 'Error.', false);
                    }
                });
            });
        });

        /* ── Course Expansion ──────────────────────────── */
        document.querySelectorAll('.glct-expansion-toggle').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var wrap = btn.closest('.glct-expansion');
                var body = wrap.querySelector('.glct-expansion-body');
                var isOpen = !body.hidden;
                body.hidden = isOpen;
                btn.classList.toggle('is-open', !isOpen);

                if (!isOpen && !wrap.dataset.loaded) {
                    wrap.dataset.loaded = '1';
                    loadExpansionCourses(wrap, '');
                }
            });
        });

        function loadExpansionCourses(wrap, filterTag) {
            var gid = wrap.dataset.gid;
            var list = wrap.querySelector('.glct-expansion-list');
            list.innerHTML = '<p style="padding:12px 0;color:var(--ink4)">Loading available courses…</p>';

            post('glct_get_expansion_courses', { group_id: gid, filter_tag: filterTag }, function(res) {
                if (!res.success) {
                    list.innerHTML = '<p class="glct-exp-empty">' + esc(res.data.message || 'Error loading courses.') + '</p>';
                    return;
                }

                // Build filter pills
                var filtersWrap = wrap.querySelector('.glct-expansion-filters');
                if (res.data.tags && res.data.tags.length > 1) {
                    var fhtml = '<span class="glct-tag-filter-lbl">Filter:</span>';
                    fhtml += '<button class="glct-tag-pill' + (!filterTag ? ' glct-tag-pill--active' : '') + '" data-slug="">All</button>';
                    res.data.tags.forEach(function(t) {
                        fhtml += '<button class="glct-tag-pill' + (filterTag === t.slug ? ' glct-tag-pill--active' : '') + '" data-slug="' + esc(t.slug) + '">' + esc(t.name) + '</button>';
                    });
                    filtersWrap.innerHTML = fhtml;
                    filtersWrap.querySelectorAll('.glct-tag-pill').forEach(function(pill) {
                        pill.addEventListener('click', function() {
                            loadExpansionCourses(wrap, pill.dataset.slug);
                        });
                    });
                } else if (res.data.tags && res.data.tags.length === 1) {
                    filtersWrap.innerHTML = '<span class="glct-tag-filter-lbl">Tag: ' + esc(res.data.tags[0].name) + '</span>';
                }

                // Build course list
                var courses = res.data.courses;
                if (!courses.length) {
                    list.innerHTML = '<p class="glct-exp-empty">🎉 All matching courses are already in this group!</p>';
                    return;
                }

                var html = '';
                courses.forEach(function(c) {
                    var tagHtml = '';
                    if (c.tags && c.tags.length) {
                        tagHtml = '<div class="glct-exp-course-tags">';
                        c.tags.forEach(function(t) { tagHtml += '<span class="glct-exp-tag">' + esc(t) + '</span>'; });
                        tagHtml += '</div>';
                    }
                    html += '<div class="glct-exp-course" data-cid="' + c.id + '">'
                        + '<div class="glct-exp-course-info">'
                        + '<span class="glct-exp-course-title">' + esc(c.title) + '</span>'
                        + tagHtml
                        + '</div>'
                        + '<button class="glct-exp-add-btn" data-cid="' + c.id + '" data-gid="' + esc(gid) + '">'
                        + '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>'
                        + 'Add'
                        + '</button>'
                        + '</div>';
                });
                list.innerHTML = html;

                // Wire add buttons
                list.querySelectorAll('.glct-exp-add-btn').forEach(function(addBtn) {
                    addBtn.addEventListener('click', function() {
                        addExpansionCourse(addBtn, wrap);
                    });
                });
            });
        }

        function addExpansionCourse(btn, wrap) {
            var gid = btn.dataset.gid;
            var cid = btn.dataset.cid;
            btn.disabled = true;
            btn.textContent = 'Adding…';

            post('glct_add_expansion_course', { group_id: gid, course_id: cid }, function(res) {
                if (res.success) {
                    toast(res.data.message, true);
                    // Remove this item from the list with fade
                    var row = btn.closest('.glct-exp-course');
                    if (row) {
                        row.style.opacity = '0';
                        row.style.transform = 'translateX(20px)';
                        row.style.transition = 'opacity .3s, transform .3s';
                        setTimeout(function() {
                            row.remove();
                            // Check if list is now empty
                            var remaining = wrap.querySelectorAll('.glct-exp-course');
                            if (!remaining.length) {
                                wrap.querySelector('.glct-expansion-list').innerHTML = '<p class="glct-exp-empty">🎉 All matching courses are already in this group! Refresh the page to see them.</p>';
                            }
                        }, 300);
                    }
                } else {
                    toast(res.data.message || 'Failed to add course.', false);
                    btn.disabled = false;
                    btn.textContent = 'Add';
                }
            });
        }

        /* ── Progress Summaries on Course Cards ────────── */
        (function loadAllProgressSummaries() {
            var gids = [];
            document.querySelectorAll('.glct-card-progress[data-progress-gid]').forEach(function(el) {
                var gid = el.dataset.progressGid;
                if (gids.indexOf(gid) === -1) gids.push(gid);
            });
            gids.forEach(function(gid) {
                post('glct_get_course_progress_summary', { group_id: gid }, function(res) {
                    if (!res.success) {
                        // Clear all loading placeholders for this group on error
                        document.querySelectorAll('.glct-card-progress[data-progress-gid="' + gid + '"]').forEach(function(el) {
                            el.innerHTML = '';
                        });
                        return;
                    }
                    var sums = res.data.summaries;
                    // Update each card with progress data
                    document.querySelectorAll('.glct-card-progress[data-progress-gid="' + gid + '"]').forEach(function(el) {
                        var cid = el.dataset.progressCid;
                        var card = el.closest('.glct-card');
                        if (sums[cid]) {
                            var s = sums[cid];
                            if (s.total === 0) {
                                el.innerHTML = '';
                                if (card) card.dataset.completion = '0';
                            } else {
                                var pct = Math.round((s.completed / s.total) * 100);
                                el.innerHTML = '<span style="color:var(--green);font-weight:700;">' + s.completed + '</span> of ' + s.total + ' completed';
                                if (card) card.dataset.completion = String(pct);
                            }
                        } else {
                            // Course not in enrolled list — clear loading placeholder
                            el.innerHTML = '';
                            if (card) card.dataset.completion = '0';
                        }
                    });
                });
            });
        })();

        /* ── Deadline Management ──────────────────────── */
        document.querySelectorAll('.glct-deadline-input').forEach(function(inp) {
            inp.addEventListener('change', function() {
                var row  = inp.closest('.glct-deadline-row');
                var gid  = row.dataset.gid;
                var cid  = row.dataset.cid;
                var date = inp.value;

                post('glct_set_deadline', { group_id: gid, course_id: cid, deadline: date }, function(res) {
                    if (res.success) {
                        toast(res.data.message, true);
                        setTimeout(function() { window.location.reload(); }, 800);
                    } else {
                        toast(res.data.message || 'Error setting deadline.', false);
                    }
                });
            });
        });

        document.querySelectorAll('.glct-deadline-clear').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var row = btn.closest('.glct-deadline-row');
                var gid = row.dataset.gid;
                var cid = row.dataset.cid;

                post('glct_set_deadline', { group_id: gid, course_id: cid, deadline: '' }, function(res) {
                    if (res.success) {
                        toast(res.data.message, true);
                        setTimeout(function() { window.location.reload(); }, 800);
                    } else {
                        toast(res.data.message || 'Error clearing deadline.', false);
                    }
                });
            });
        });

        /* ── Compliance Dashboard ──────────────────────── */
        function loadCompliance(gid) {
            var body = document.getElementById('glct-compliance-body-' + gid);
            if (!body) return;
            body.innerHTML = '<p style="padding:14px 0;color:var(--ink4);font-size:.88rem;">Loading compliance data...</p>';
            post('glct_get_compliance_report', { group_id: gid }, function(res) {
                if (res.success) {
                    body.innerHTML = res.data.html;
                    wireCompliancePager(body);
                    wireAtRiskPager(body);
                } else {
                    body.innerHTML = '<p style="padding:14px 0;color:var(--red);font-size:.88rem;">Failed to load compliance data.</p>';
                }
            });
        }

        function wireCompliancePager(container) {
            var wrap = container.querySelector('.glct-compliance-courses');
            if (!wrap) return;
            var perPage = parseInt(wrap.dataset.perPage, 10) || 8;
            var allRows = Array.from(wrap.querySelectorAll('.glct-compliance-course-row'));
            if (allRows.length <= perPage) return; // No pagination needed

            var controls = container.querySelector('.glct-compliance-controls');
            if (!controls) return;
            var sortBtn  = controls.querySelector('.glct-compliance-sort');
            var prevBtn  = controls.querySelector('.glct-compliance-prev');
            var nextBtn  = controls.querySelector('.glct-compliance-next');
            var pageInfo = controls.querySelector('.glct-compliance-page-info');
            var curPage  = 1;
            var sortDir  = 'desc';

            function totalPages() { return Math.ceil(allRows.length / perPage); }

            function renderPage() {
                var start = (curPage - 1) * perPage;
                var end   = start + perPage;
                allRows.forEach(function(row, i) {
                    row.style.display = (i >= start && i < end) ? '' : 'none';
                });
                pageInfo.textContent = 'Page ' + curPage + ' of ' + totalPages();
                prevBtn.disabled = curPage <= 1;
                nextBtn.disabled = curPage >= totalPages();
            }

            function sortRows() {
                allRows.sort(function(a, b) {
                    var pa = parseInt(a.dataset.pct, 10) || 0;
                    var pb = parseInt(b.dataset.pct, 10) || 0;
                    return sortDir === 'desc' ? pb - pa : pa - pb;
                });
                // Re-append in sorted order
                allRows.forEach(function(row) { wrap.appendChild(row); });
            }

            sortBtn.addEventListener('click', function() {
                sortDir = sortDir === 'desc' ? 'asc' : 'desc';
                sortBtn.textContent = sortDir === 'desc' ? '\u2193 Highest First' : '\u2191 Lowest First';
                sortRows();
                curPage = 1;
                renderPage();
            });
            prevBtn.addEventListener('click', function() {
                if (curPage > 1) { curPage--; renderPage(); }
            });
            nextBtn.addEventListener('click', function() {
                if (curPage < totalPages()) { curPage++; renderPage(); }
            });

            renderPage();
        }

        function wireAtRiskPager(container) {
            var wrap = container.querySelector('.glct-at-risk-list');
            if (!wrap) return;
            var perPage = parseInt(wrap.dataset.perPage, 10) || 8;
            var allRows = Array.from(wrap.querySelectorAll('.glct-compliance-learner-row'));
            if (allRows.length <= perPage) return;

            var controls = container.querySelector('.glct-at-risk-controls');
            if (!controls) return;
            var prevBtn  = controls.querySelector('.glct-at-risk-prev');
            var nextBtn  = controls.querySelector('.glct-at-risk-next');
            var pageInfo = controls.querySelector('.glct-at-risk-page-info');
            var curPage  = 1;

            function totalPages() { return Math.ceil(allRows.length / perPage); }

            function renderPage() {
                var start = (curPage - 1) * perPage;
                var end   = start + perPage;
                allRows.forEach(function(row, i) {
                    row.style.display = (i >= start && i < end) ? '' : 'none';
                });
                pageInfo.textContent = 'Page ' + curPage + ' of ' + totalPages();
                prevBtn.disabled = curPage <= 1;
                nextBtn.disabled = curPage >= totalPages();
            }

            prevBtn.addEventListener('click', function() {
                if (curPage > 1) { curPage--; renderPage(); }
            });
            nextBtn.addEventListener('click', function() {
                if (curPage < totalPages()) { curPage++; renderPage(); }
            });

            renderPage();
        }

        document.querySelectorAll('.glct-compliance-dashboard').forEach(function(el) {
            loadCompliance(el.dataset.gid);
        });

        document.querySelectorAll('.glct-compliance-refresh').forEach(function(btn) {
            btn.addEventListener('click', function() {
                loadCompliance(btn.dataset.gid);
            });
        });

        document.querySelectorAll('.glct-compliance-export').forEach(function(btn) {
            btn.addEventListener('click', function() {
                window.location.href = '<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>?action=glct_export_compliance_csv&group_id=' + btn.dataset.gid + '&nonce=<?php echo esc_attr( wp_create_nonce( 'glct_nonce' ) ); ?>';
            });
        });

        /* ── Utility ────────────────────────────────────── */
        function esc(s) {
            return String(s)
                .replace(/&/g,  '&amp;')
                .replace(/</g,  '&lt;')
                .replace(/>/g,  '&gt;')
                .replace(/"/g,  '&quot;')
                .replace(/'/g,  '&#39;');
        }

    }());
    </script>
    <?php
}

/**
 * Render compliance dashboard HTML (called from AJAX handler, output buffered).
 */
function glct_render_compliance_html(
    int $overall_pct, int $member_count, int $course_count,
    int $overdue_count, array $course_stats, array $at_risk_learners,
    int $per_page = 8, int $at_risk_days = 14, int $at_risk_pct = 25
): void {
    // Count completed courses (100%)
    $fully_completed = 0;
    foreach ( $course_stats as $cs ) {
        if ( $cs['pct'] >= 100 ) $fully_completed++;
    }
    $ring_color = $overall_pct >= 80 ? 'var(--green)' : ( $overall_pct >= 50 ? '#f59e0b' : 'var(--red)' );
    ?>
    <div class="glct-compliance">
        <!-- Top Stats Row -->
        <div class="glct-compliance-stats">
            <div class="glct-compliance-stat-card">
                <div class="glct-compliance-ring">
                    <svg viewBox="0 0 72 72" width="72" height="72">
                        <circle cx="36" cy="36" r="30" fill="none" stroke="var(--surface2)" stroke-width="7"/>
                        <circle cx="36" cy="36" r="30" fill="none" stroke="<?php echo $ring_color; ?>" stroke-width="7"
                            stroke-dasharray="<?php echo (int) round( 188.5 * $overall_pct / 100 ); ?> 188.5"
                            stroke-linecap="round" transform="rotate(-90 36 36)"/>
                    </svg>
                    <span class="glct-compliance-pct"><?php echo esc_html( $overall_pct ); ?>%</span>
                </div>
                <div class="glct-compliance-stat-text">
                    <span class="glct-compliance-stat-value">Overall Completion</span>
                    <span class="glct-compliance-stat-label"><?php echo esc_html( $member_count ); ?> members &middot; <?php echo esc_html( $course_count ); ?> courses</span>
                </div>
            </div>
            <div class="glct-compliance-stat-card glct-compliance-stat--mini">
                <span class="glct-compliance-stat-num" style="color:var(--green);"><?php echo esc_html( $fully_completed ); ?></span>
                <span class="glct-compliance-stat-label">Courses at 100%</span>
            </div>
            <?php if ( $overdue_count > 0 ) : ?>
            <div class="glct-compliance-stat-card glct-compliance-stat--mini glct-compliance-stat--alert">
                <span class="glct-compliance-stat-num" style="color:var(--red);"><?php echo esc_html( $overdue_count ); ?></span>
                <span class="glct-compliance-stat-label">Learners Overdue</span>
            </div>
            <?php endif; ?>
            <?php
            $tooltip_parts = [];
            if ( $at_risk_days > 0 ) $tooltip_parts[] = 'Inactive > ' . $at_risk_days . ' days';
            if ( $at_risk_pct  > 0 ) $tooltip_parts[] = 'Completion < ' . $at_risk_pct . '%';
            $tooltip = $tooltip_parts ? implode( ' or ', $tooltip_parts ) : 'No thresholds set';
            ?>
            <div class="glct-compliance-stat-card glct-compliance-stat--mini" title="<?php echo esc_attr( $tooltip ); ?>">
                <span class="glct-compliance-stat-num" style="color:#f59e0b;"><?php echo count( $at_risk_learners ); ?></span>
                <span class="glct-compliance-stat-label">At-Risk Learners</span>
            </div>
        </div>

        <!-- Two-column content -->
        <div class="glct-compliance-grid">
            <!-- Left: Course completion bars -->
            <div class="glct-compliance-col">
                <?php if ( ! empty( $course_stats ) ) : ?>
                <h4 class="glct-compliance-heading">Course Completion Rates</h4>
                <div class="glct-compliance-courses" data-per-page="<?php echo esc_attr( $per_page ); ?>">
                <?php foreach ( $course_stats as $cs ) : ?>
                <div class="glct-compliance-course-row" data-pct="<?php echo esc_attr( $cs['pct'] ); ?>">
                    <div class="glct-compliance-course-top">
                        <span class="glct-compliance-course-name"><?php echo esc_html( $cs['title'] ); ?></span>
                        <span class="glct-compliance-course-pct <?php echo $cs['is_overdue'] ? 'is-overdue' : ''; ?>">
                            <?php echo esc_html( $cs['completed'] ); ?>/<?php echo esc_html( $cs['completed'] + $cs['in_progress'] + $cs['not_started'] ); ?>
                            (<?php echo esc_html( $cs['pct'] ); ?>%)
                            <?php if ( $cs['is_overdue'] ) : ?><span class="glct-overdue-dot"></span><?php endif; ?>
                        </span>
                    </div>
                    <div class="glct-compliance-bar-wrap">
                        <div class="glct-compliance-bar" style="width:<?php echo esc_attr( $cs['pct'] ); ?>%"></div>
                    </div>
                </div>
                <?php endforeach; ?>
                </div>
                <?php if ( count( $course_stats ) > $per_page ) : ?>
                <div class="glct-compliance-controls">
                    <button class="glct-compliance-sort" data-dir="desc">↓ Highest First</button>
                    <div class="glct-compliance-pager">
                        <button class="glct-compliance-prev" disabled>←</button>
                        <span class="glct-compliance-page-info"></span>
                        <button class="glct-compliance-next">→</button>
                    </div>
                </div>
                <?php endif; ?>
                <?php else : ?>
                <p style="color:var(--ink4);font-size:.84rem;">No active courses to track.</p>
                <?php endif; ?>
            </div>

            <!-- Right: At-risk learners -->
            <div class="glct-compliance-col">
                <?php if ( ! empty( $at_risk_learners ) ) : ?>
                <h4 class="glct-compliance-heading">At-Risk Learners <span style="font-weight:400;font-size:.72rem;color:var(--ink4);">(<?php echo count( $at_risk_learners ); ?>)</span></h4>
                <div class="glct-at-risk-list" data-per-page="<?php echo esc_attr( $per_page ); ?>">
                <?php foreach ( $at_risk_learners as $lr ) : ?>
                <div class="glct-compliance-learner-row">
                    <div class="glct-compliance-learner-info">
                        <span class="glct-compliance-learner-name"><?php echo esc_html( $lr['name'] ); ?></span>
                        <span class="glct-compliance-learner-email"><?php echo esc_html( $lr['email'] ); ?></span>
                    </div>
                    <div style="display:flex;flex-direction:column;align-items:flex-end;gap:2px;">
                        <span class="glct-compliance-learner-reason"><?php echo esc_html( $lr['reason'] ); ?></span>
                        <span class="glct-compliance-learner-activity">Last active: <?php echo esc_html( $lr['last_active'] ); ?></span>
                    </div>
                </div>
                <?php endforeach; ?>
                </div>
                <?php if ( count( $at_risk_learners ) > $per_page ) : ?>
                <div class="glct-at-risk-controls">
                    <div class="glct-compliance-pager">
                        <button class="glct-at-risk-prev" disabled>←</button>
                        <span class="glct-at-risk-page-info"></span>
                        <button class="glct-at-risk-next">→</button>
                    </div>
                </div>
                <?php endif; ?>
                <?php else : ?>
                <h4 class="glct-compliance-heading">At-Risk Learners</h4>
                <p style="color:var(--green);font-size:.84rem;font-weight:600;">All learners are on track.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php
}


// ═══════════════════════════════════════════════════════════════════════════
// SECTION 9 — ADMIN SETTINGS
// ═══════════════════════════════════════════════════════════════════════════

define( 'GLCT_DEFAULT_SUBJECT', 'Course Access Update' );
define( 'GLCT_DEFAULT_BODY',    "Hi {first_name},\n\nYour course access has been updated. Please log in to view your courses.\n\nThank you." );

add_action( 'admin_menu', function (): void {
    add_options_page(
        'GLCT Settings',
        'GLCT Settings',
        'manage_options',
        'glct-settings',
        'glct_settings_page'
    );
} );

add_action( 'admin_init', function (): void {
    
    // --- General Settings ---
    register_setting( 'glct_general_settings', 'glct_pagination_limit', [
        'type' => 'integer',
        'sanitize_callback' => 'absint',
        'default' => 15,
    ] );
    add_settings_section('glct_general_section', 'General Settings', null, 'glct-settings');

    add_settings_field('glct_pagination_limit', 'Pagination Limit', function() {
        $val = get_option('glct_pagination_limit', 15);
        echo '<input type="number" name="glct_pagination_limit" value="'.esc_attr($val).'" class="small-text"> courses per page';
    }, 'glct-settings', 'glct_general_section');


    // --- Feature Toggles ---
    register_setting( 'glct_general_settings', 'glct_allow_wipe', [
        'type' => 'string',
        'sanitize_callback' => 'sanitize_text_field',
        'default' => 'yes',
    ] );
    register_setting( 'glct_general_settings', 'glct_allow_remove', [
        'type' => 'string',
        'sanitize_callback' => 'sanitize_text_field',
        'default' => 'yes',
    ] );
    register_setting( 'glct_general_settings', 'glct_allow_email', [
        'type' => 'string',
        'sanitize_callback' => 'sanitize_text_field',
        'default' => 'yes',
    ] );

    add_settings_section('glct_features_section', 'Feature Toggles (Governance)', function() {
        echo '<p>Disable these features to restrict what Group Leaders are allowed to do.</p>';
    }, 'glct-settings');

    add_settings_field('glct_allow_wipe', 'Allow Progress Wiping', function() {
        $val = get_option('glct_allow_wipe', 'yes');
        echo '<label><input type="radio" name="glct_allow_wipe" value="yes" '.checked($val, 'yes', false).'> Enabled (Destructive)</label><br>';
        echo '<label><input type="radio" name="glct_allow_wipe" value="no" '.checked($val, 'no', false).'> Disabled (Protects LearnDash Data)</label>';
    }, 'glct-settings', 'glct_features_section');

    add_settings_field('glct_allow_remove', 'Allow Course Removal', function() {
        $val = get_option('glct_allow_remove', 'yes');
        echo '<label><input type="radio" name="glct_allow_remove" value="yes" '.checked($val, 'yes', false).'> Enabled</label><br>';
        echo '<label><input type="radio" name="glct_allow_remove" value="no" '.checked($val, 'no', false).'> Disabled (Leaders can only turn ON/OFF)</label>';
    }, 'glct-settings', 'glct_features_section');

    add_settings_field('glct_allow_email', 'Allow Email Notifications', function() {
        $val = get_option('glct_allow_email', 'yes');
        echo '<label><input type="radio" name="glct_allow_email" value="yes" '.checked($val, 'yes', false).'> Enabled</label><br>';
        echo '<label><input type="radio" name="glct_allow_email" value="no" '.checked($val, 'no', false).'> Disabled</label>';
    }, 'glct-settings', 'glct_features_section');

    // Per-User Override Restriction
    register_setting( 'glct_general_settings', 'glct_allow_per_user', [
        'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => 'yes',
    ] );
    add_settings_field('glct_allow_per_user', 'Allow Per-User Access Overrides', function() {
        $val = get_option('glct_allow_per_user', 'yes');
        echo '<label><input type="radio" name="glct_allow_per_user" value="yes" '.checked($val, 'yes', false).'> Enabled (Leaders can toggle individual users)</label><br>';
        echo '<label><input type="radio" name="glct_allow_per_user" value="no" '.checked($val, 'no', false).'> Disabled (Group-level toggles only)</label>';
    }, 'glct-settings', 'glct_features_section');

    // Bulk Toggle Restriction
    register_setting( 'glct_general_settings', 'glct_allow_bulk_toggle', [
        'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => 'yes',
    ] );
    add_settings_field('glct_allow_bulk_toggle', 'Allow Enable All / Disable All', function() {
        $val = get_option('glct_allow_bulk_toggle', 'yes');
        echo '<label><input type="radio" name="glct_allow_bulk_toggle" value="yes" '.checked($val, 'yes', false).'> Enabled</label><br>';
        echo '<label><input type="radio" name="glct_allow_bulk_toggle" value="no" '.checked($val, 'no', false).'> Disabled (No bulk user toggles)</label>';
    }, 'glct-settings', 'glct_features_section');


    // Course Expansion
    register_setting( 'glct_general_settings', 'glct_allow_expansion', [
        'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => 'no',
    ] );
    add_settings_field('glct_allow_expansion', 'Allow Course Expansion via Tags', function() {
        $val = get_option('glct_allow_expansion', 'no');
        echo '<label><input type="radio" name="glct_allow_expansion" value="yes" '.checked($val, 'yes', false).'> Enabled (Leaders can add courses matched by admin-assigned LD tags)</label><br>';
        echo '<label><input type="radio" name="glct_allow_expansion" value="no" '.checked($val, 'no', false).'> Disabled</label>';
        echo '<p class="description">When enabled, admins assign LearnDash Course Tags to each group. Group Leaders can then browse and add matching courses to their group.</p>';
    }, 'glct-settings', 'glct_features_section');


    // --- Course Tags ---
    register_setting( 'glct_general_settings', 'glct_available_tags', [
        'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => 'Onboarding, Advanced, Compliance, Optional',
    ] );
    add_settings_section('glct_tags_section', 'Course Tags', function() {
        echo '<p>Group Leaders can tag courses for easier filtering. Define the available tag names below (comma-separated).</p>';
    }, 'glct-settings');

    add_settings_field('glct_available_tags', 'Available Tags', function() {
        $val = get_option('glct_available_tags', 'Onboarding, Advanced, Compliance, Optional');
        echo '<input type="text" name="glct_available_tags" value="'.esc_attr($val).'" class="regular-text">';
        echo '<p class="description">Comma-separated list. E.g.: Onboarding, Advanced, Compliance, Optional</p>';
    }, 'glct-settings', 'glct_tags_section');


    // --- Audit Log Settings ---
    register_setting( 'glct_general_settings', 'glct_log_retention', [
        'type' => 'integer',
        'sanitize_callback' => 'absint',
        'default' => 90,
    ] );

    add_settings_section('glct_audit_section', 'Audit Log Management', null, 'glct-settings');

    add_settings_field('glct_log_retention', 'Auto-Purge Logs', function() {
        $val = get_option('glct_log_retention', 90);
        echo '<input type="number" name="glct_log_retention" value="'.esc_attr($val).'" class="small-text"> days';
        echo '<p class="description">Logs older than this will be automatically deleted. Set to 0 to keep logs forever.</p>';
    }, 'glct-settings', 'glct_audit_section');


    // --- Email Templates ---
    register_setting( 'glct_general_settings', 'glct_default_email_subject', [
        'type' => 'string',
        'sanitize_callback' => 'sanitize_text_field',
        'default' => GLCT_DEFAULT_SUBJECT,
    ] );
    register_setting( 'glct_general_settings', 'glct_default_email_body', [
        'type' => 'string',
        'sanitize_callback' => 'wp_kses_post',
        'default' => GLCT_DEFAULT_BODY,
    ] );

    add_settings_section('glct_email_section', 'Default Email Template', null, 'glct-settings');

    add_settings_field('glct_default_email_subject', 'Subject', function() {
        $val = get_option('glct_default_email_subject', GLCT_DEFAULT_SUBJECT);
        echo '<input type="text" name="glct_default_email_subject" value="'.esc_attr($val).'" class="regular-text">';
    }, 'glct-settings', 'glct_email_section');

    add_settings_field('glct_default_email_body', 'Message', function() {
        $val = get_option('glct_default_email_body', GLCT_DEFAULT_BODY);
        echo '<textarea name="glct_default_email_body" rows="6" class="large-text">'.esc_textarea($val).'</textarea>';
        echo '<p class="description">Tags: <code>{first_name}</code> <code>{last_name}</code> <code>{name}</code> <code>{course_name}</code></p>';
    }, 'glct-settings', 'glct_email_section');


    // --- Learner Notifications ---
    add_settings_section('glct_notif_section', 'Learner Notifications', function() {
        echo '<p>Configure the learner-facing notification popup and alerts page.</p>';
    }, 'glct-settings');

    register_setting( 'glct_general_settings', 'glct_alerts_page_id', [
        'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 0,
    ] );
    add_settings_field('glct_alerts_page_id', 'Learner Alerts Page', function() {
        $val = (int) get_option('glct_alerts_page_id', 0);
        $pages = get_pages();
        echo '<select name="glct_alerts_page_id">';
        echo '<option value="0"' . selected($val, 0, false) . '>— Select a Page —</option>';
        foreach ($pages as $page) {
            echo '<option value="' . esc_attr($page->ID) . '"' . selected($val, $page->ID, false) . '>'
                 . esc_html($page->post_title) . '</option>';
        }
        echo '</select>';
        echo '<p class="description">Create a page with <code>[glct_learner_alerts]</code> shortcode and select it here. The login popup links learners to this page.</p>';
    }, 'glct-settings', 'glct_notif_section');

    register_setting( 'glct_general_settings', 'glct_notification_retention', [
        'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 90,
    ] );
    add_settings_field('glct_notification_retention', 'Notification Retention', function() {
        $val = get_option('glct_notification_retention', 90);
        echo '<input type="number" name="glct_notification_retention" value="' . esc_attr($val) . '" class="small-text"> days';
        echo '<p class="description">Notifications older than this will be auto-purged. Set to 0 to keep forever.</p>';
    }, 'glct-settings', 'glct_notif_section');

    register_setting( 'glct_general_settings', 'glct_allow_login_popup', [
        'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => 'yes',
    ] );
    add_settings_field('glct_allow_login_popup', 'Login Notification Popup', function() {
        $val = get_option('glct_allow_login_popup', 'yes');
        echo '<label><input type="radio" name="glct_allow_login_popup" value="yes" ' . checked($val, 'yes', false) . '> Enabled (Show popup to learners with new alerts)</label><br>';
        echo '<label><input type="radio" name="glct_allow_login_popup" value="no" ' . checked($val, 'no', false) . '> Disabled</label>';
    }, 'glct-settings', 'glct_notif_section');

    // --- Admin Broadcast / Updates ---
    // Note: Broadcast sending is handled via AJAX (glct_send_broadcast), not via settings save.
    // The settings page renders the compose form which POSTs via JS.
    add_settings_section('glct_broadcast_section', 'Send Update to Learners', function() {
        echo '<p>Compose and send an update notification to learners. Updates appear on their Alerts page and can optionally be emailed.</p>';
    }, 'glct-settings');

    add_settings_field( 'glct_broadcast_compose', '', function() {
        $groups = [];
        if ( function_exists( 'learndash_get_groups' ) ) {
            $all_groups = learndash_get_groups();
            foreach ( $all_groups as $g ) {
                $groups[] = [ 'id' => $g->ID, 'title' => $g->post_title ];
            }
        }
        // Sort groups alphabetically A–Z
        usort( $groups, function( $a, $b ) { return strnatcasecmp( $a['title'], $b['title'] ); } );
        ?>
        <div id="glct-broadcast-form" style="max-width:600px;">
            <div style="margin-bottom:14px;">
                <label style="display:block;font-weight:600;margin-bottom:4px;">Title</label>
                <input type="text" id="glct-bc-title" class="regular-text" style="width:100%;" placeholder="e.g. System Update, New Policy, Training Reminder">
            </div>
            <div style="margin-bottom:14px;">
                <label style="display:block;font-weight:600;margin-bottom:4px;">Message</label>
                <textarea id="glct-bc-message" rows="5" class="large-text" placeholder="Write your update here..."></textarea>
                <p class="description">Tags: <code>{first_name}</code> <code>{last_name}</code> <code>{name}</code> <code>{group_name}</code></p>
            </div>
            <div style="margin-bottom:14px;">
                <label style="display:block;font-weight:600;margin-bottom:4px;">Send To</label>
                <div id="glct-bc-target-wrap" style="position:relative;max-width:460px;">
                    <div id="glct-bc-selected-tags" style="display:flex;flex-wrap:wrap;gap:4px;padding:6px 8px;min-height:38px;border:1px solid #8c8f94;border-radius:4px;background:#fff;cursor:text;align-items:center;">
                        <span class="glct-bc-tag" data-value="all" style="display:inline-flex;align-items:center;gap:4px;background:#2271b1;color:#fff;border-radius:3px;padding:2px 8px;font-size:12px;font-weight:600;">All Learners<span class="glct-bc-tag-x" style="cursor:pointer;font-size:14px;line-height:1;margin-left:2px;">&times;</span></span>
                        <input type="text" id="glct-bc-search" placeholder="Search groups..." style="border:none;outline:none;flex:1;min-width:120px;font-size:13px;padding:2px 4px;">
                    </div>
                    <div id="glct-bc-dropdown" style="display:none;position:absolute;top:100%;left:0;right:0;z-index:999;background:#fff;border:1px solid #8c8f94;border-top:none;border-radius:0 0 4px 4px;max-height:220px;overflow-y:auto;box-shadow:0 4px 12px rgba(0,0,0,.12);">
                        <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;border-bottom:1px solid #f0f0f0;font-weight:600;background:#f9f9f9;">
                            <input type="checkbox" value="all" checked style="width:16px;height:16px;"> All Learners (All Groups)
                        </label>
                        <?php foreach ( $groups as $g ) : ?>
                        <label style="display:flex;align-items:center;gap:8px;padding:7px 12px;cursor:pointer;font-size:13px;" data-name="<?php echo esc_attr( strtolower( $g['title'] ) ); ?>">
                            <input type="checkbox" value="<?php echo esc_attr( $g['id'] ); ?>" style="width:16px;height:16px;"> <?php echo esc_html( $g['title'] ); ?>
                        </label>
                        <?php endforeach; ?>
                        <div id="glct-bc-no-results" style="display:none;padding:10px 12px;color:#8c8f94;font-size:13px;font-style:italic;">No groups match your search.</div>
                    </div>
                    <input type="hidden" id="glct-bc-target" value="all">
                </div>
                <p class="description">Select "All Learners" or pick individual groups. Use the search to find groups quickly.</p>
            </div>
            <div style="margin-bottom:18px;">
                <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                    <input type="checkbox" id="glct-bc-email" value="1" style="width:18px;height:18px;">
                    <span style="font-weight:600;">Also send via Email</span>
                </label>
                <p class="description" style="margin-left:26px;">If checked, each learner also receives this update as an email (in addition to their Alerts page).</p>
            </div>
            <button type="button" id="glct-bc-send" class="button button-primary" style="padding:6px 24px;font-size:14px;">📢 Send Update</button>
            <span id="glct-bc-status" style="margin-left:12px;font-weight:600;"></span>
        </div>
        <script>
        (function(){
            /* ── Multi-select group picker ──────────────────── */
            var wrap     = document.getElementById('glct-bc-target-wrap');
            var tagsBox  = document.getElementById('glct-bc-selected-tags');
            var searchIn = document.getElementById('glct-bc-search');
            var dropdown = document.getElementById('glct-bc-dropdown');
            var hidden   = document.getElementById('glct-bc-target');
            var noRes    = document.getElementById('glct-bc-no-results');
            var allCbs   = dropdown.querySelectorAll('input[type="checkbox"]');

            function syncHidden(){
                var vals=[];
                allCbs.forEach(function(c){ if(c.checked) vals.push(c.value); });
                if(vals.indexOf('all')!==-1) hidden.value='all';
                else hidden.value=vals.join(',');
            }
            function renderTags(){
                var tags=tagsBox.querySelectorAll('.glct-bc-tag');
                tags.forEach(function(t){t.remove()});
                allCbs.forEach(function(c){
                    if(!c.checked)return;
                    var lbl=c.value==='all'?'All Learners':c.parentElement.textContent.trim();
                    var tag=document.createElement('span');
                    tag.className='glct-bc-tag';
                    tag.dataset.value=c.value;
                    tag.style.cssText='display:inline-flex;align-items:center;gap:4px;background:#2271b1;color:#fff;border-radius:3px;padding:2px 8px;font-size:12px;font-weight:600;';
                    tag.innerHTML=lbl+'<span class="glct-bc-tag-x" style="cursor:pointer;font-size:14px;line-height:1;margin-left:2px;">&times;</span>';
                    tagsBox.insertBefore(tag,searchIn);
                });
                syncHidden();
            }
            // Toggle dropdown
            tagsBox.addEventListener('click',function(e){
                if(e.target.classList.contains('glct-bc-tag-x')){
                    var val=e.target.parentElement.dataset.value;
                    allCbs.forEach(function(c){if(c.value===val)c.checked=false;});
                    renderTags();
                    return;
                }
                dropdown.style.display=dropdown.style.display==='none'?'block':'none';
                if(dropdown.style.display==='block')searchIn.focus();
            });
            // Checkbox change
            allCbs.forEach(function(cb){
                cb.addEventListener('change',function(){
                    if(cb.value==='all'&&cb.checked){
                        allCbs.forEach(function(c){if(c.value!=='all')c.checked=false;});
                    } else if(cb.value!=='all'&&cb.checked){
                        allCbs.forEach(function(c){if(c.value==='all')c.checked=false;});
                    }
                    // If nothing selected, re-check All
                    var any=false;
                    allCbs.forEach(function(c){if(c.checked)any=true;});
                    if(!any){allCbs.forEach(function(c){if(c.value==='all')c.checked=true;});}
                    renderTags();
                });
            });
            // Search filter
            searchIn.addEventListener('input',function(){
                var q=searchIn.value.toLowerCase();
                var visible=0;
                dropdown.querySelectorAll('label[data-name]').forEach(function(lbl){
                    var match=lbl.dataset.name.indexOf(q)!==-1;
                    lbl.style.display=match?'':'none';
                    if(match)visible++;
                });
                noRes.style.display=visible===0&&q?'block':'none';
                dropdown.style.display='block';
            });
            // Close dropdown on outside click
            document.addEventListener('click',function(e){
                if(!wrap.contains(e.target))dropdown.style.display='none';
            });

            /* ── Send broadcast ─────────────────────────────── */
            document.getElementById('glct-bc-send').addEventListener('click', function(){
                var btn = this;
                var title = document.getElementById('glct-bc-title').value.trim();
                var message = document.getElementById('glct-bc-message').value.trim();
                var target = hidden.value;
                var sendEmail = document.getElementById('glct-bc-email').checked ? '1' : '0';
                var status = document.getElementById('glct-bc-status');

                if (!title || !message) {
                    status.textContent = 'Please enter a title and message.';
                    status.style.color = '#c8332a';
                    return;
                }

                btn.disabled = true;
                btn.textContent = 'Sending...';
                status.textContent = '';

                var fd = new FormData();
                fd.append('action', 'glct_send_broadcast');
                fd.append('nonce', '<?php echo wp_create_nonce("glct_broadcast_nonce"); ?>');
                fd.append('title', title);
                fd.append('message', message);
                fd.append('target', target);
                fd.append('send_email', sendEmail);

                fetch('<?php echo esc_js( admin_url("admin-ajax.php") ); ?>', {
                    method: 'POST', body: fd, credentials: 'same-origin'
                })
                .then(function(r){ return r.json(); })
                .then(function(res){
                    if (res.success) {
                        status.textContent = '\u2713 ' + res.data.message;
                        status.style.color = '#0b7d5c';
                        document.getElementById('glct-bc-title').value = '';
                        document.getElementById('glct-bc-message').value = '';
                    } else {
                        status.textContent = 'Error: ' + (res.data ? res.data.message : 'Unknown error');
                        status.style.color = '#c8332a';
                    }
                    btn.disabled = false;
                    btn.textContent = '\uD83D\uDCE2 Send Update';
                })
                .catch(function(){
                    status.textContent = 'Network error. Please try again.';
                    status.style.color = '#c8332a';
                    btn.disabled = false;
                    btn.textContent = '\uD83D\uDCE2 Send Update';
                });
            });
        })();
        </script>
        <?php
    }, 'glct-settings', 'glct_broadcast_section' );

    // --- Inactivity Alerts ---
    register_setting( 'glct_general_settings', 'glct_inactivity_days', [
        'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 0,
    ] );
    add_settings_field( 'glct_inactivity_days', 'Inactivity Alert Period', function() {
        $val = get_option( 'glct_inactivity_days', 0 );
        echo '<input type="number" name="glct_inactivity_days" value="' . esc_attr( $val ) . '" class="small-text" min="0"> days';
        echo '<p class="description">Alert Group Leaders when a member has not accessed training for this many days. Set to 0 to disable.</p>';
    }, 'glct-settings', 'glct_notif_section' );

    // ── Compliance & Deadlines Section ──────────────────────
    add_settings_section( 'glct_compliance_section', 'Compliance & Deadlines', function() {
        echo '<p>Configure the compliance dashboard and deadline features available to Group Leaders.</p>';
    }, 'glct-settings' );

    register_setting( 'glct_general_settings', 'glct_enable_compliance_dashboard', [
        'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => 'yes',
    ] );
    add_settings_field( 'glct_enable_compliance_dashboard', 'Compliance Dashboard', function() {
        $val = get_option( 'glct_enable_compliance_dashboard', 'yes' );
        echo '<label><input type="radio" name="glct_enable_compliance_dashboard" value="yes" ' . checked( $val, 'yes', false ) . '> Enabled</label><br>';
        echo '<label><input type="radio" name="glct_enable_compliance_dashboard" value="no" ' . checked( $val, 'no', false ) . '> Disabled</label>';
        echo '<p class="description">Show compliance overview (completion rates, at-risk learners) on the Group Leader Course Manager.</p>';
    }, 'glct-settings', 'glct_compliance_section' );

    register_setting( 'glct_general_settings', 'glct_compliance_per_page', [
        'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 8,
    ] );
    add_settings_field( 'glct_compliance_per_page', 'Courses Per Page (Compliance)', function() {
        $val = get_option( 'glct_compliance_per_page', 8 );
        echo '<input type="number" name="glct_compliance_per_page" value="' . esc_attr( $val ) . '" class="small-text" min="1" max="100">';
        echo '<p class="description">Number of courses to show per page in the Compliance Dashboard course completion list. Default: 8.</p>';
    }, 'glct-settings', 'glct_compliance_section' );

    // ── At-Risk Learner Thresholds ──
    register_setting( 'glct_general_settings', 'glct_at_risk_inactive_days', [
        'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 14,
    ] );
    add_settings_field( 'glct_at_risk_inactive_days', 'At-Risk: Days Since Last Login', function() {
        $val = get_option( 'glct_at_risk_inactive_days', 14 );
        echo '<input type="number" name="glct_at_risk_inactive_days" value="' . esc_attr( $val ) . '" class="small-text" min="0"> days';
        echo '<p class="description">Learners who have not logged in for this many days are flagged as <strong>at-risk</strong> on the Compliance Dashboard. Set to 0 to ignore inactivity.</p>';
    }, 'glct-settings', 'glct_compliance_section' );

    register_setting( 'glct_general_settings', 'glct_at_risk_completion_pct', [
        'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 25,
    ] );
    add_settings_field( 'glct_at_risk_completion_pct', 'At-Risk: Completion Threshold', function() {
        $val = get_option( 'glct_at_risk_completion_pct', 25 );
        echo '<input type="number" name="glct_at_risk_completion_pct" value="' . esc_attr( $val ) . '" class="small-text" min="0" max="100"> %';
        echo '<p class="description">Learners whose <strong>average completion</strong> across all enrolled courses is below this percentage are flagged as at-risk. Set to 0 to ignore completion rate.</p>';
    }, 'glct-settings', 'glct_compliance_section' );

    register_setting( 'glct_general_settings', 'glct_allow_deadlines', [
        'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => 'yes',
    ] );
    add_settings_field( 'glct_allow_deadlines', 'Allow Group Leaders to Set Deadlines', function() {
        $val = get_option( 'glct_allow_deadlines', 'yes' );
        echo '<label><input type="radio" name="glct_allow_deadlines" value="yes" ' . checked( $val, 'yes', false ) . '> Enabled</label><br>';
        echo '<label><input type="radio" name="glct_allow_deadlines" value="no" ' . checked( $val, 'no', false ) . '> Disabled</label>';
    }, 'glct-settings', 'glct_compliance_section' );

    register_setting( 'glct_general_settings', 'glct_deadline_reminder_days', [
        'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '7,1',
    ] );
    add_settings_field( 'glct_deadline_reminder_days', 'Deadline Reminder Intervals', function() {
        $val = get_option( 'glct_deadline_reminder_days', '7,1' );
        echo '<input type="text" name="glct_deadline_reminder_days" value="' . esc_attr( $val ) . '" class="regular-text">';
        echo '<p class="description">Comma-separated days before deadline to send learner reminders. E.g.: 7,1 means reminders at 7 days and 1 day before due date.</p>';
    }, 'glct-settings', 'glct_compliance_section' );

    register_setting( 'glct_general_settings', 'glct_allow_progress_visibility', [
        'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => 'yes',
    ] );
    add_settings_field( 'glct_allow_progress_visibility', 'Learner Progress Visibility', function() {
        $val = get_option( 'glct_allow_progress_visibility', 'yes' );
        echo '<label><input type="radio" name="glct_allow_progress_visibility" value="yes" ' . checked( $val, 'yes', false ) . '> Show (Group Leaders see completion % per learner)</label><br>';
        echo '<label><input type="radio" name="glct_allow_progress_visibility" value="no" ' . checked( $val, 'no', false ) . '> Hide (Progress data hidden from Group Leaders)</label>';
    }, 'glct-settings', 'glct_compliance_section' );

} );

// Admin Broadcast AJAX handler
add_action( 'wp_ajax_glct_send_broadcast', function(): void {
    check_ajax_referer( 'glct_broadcast_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'Permission denied.' ] );
        return;
    }

    $title     = sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) );
    $message   = wp_kses_post( wp_unslash( $_POST['message'] ?? '' ) );
    $target    = sanitize_text_field( wp_unslash( $_POST['target'] ?? 'all' ) );
    $sendEmail = ( $_POST['send_email'] ?? '0' ) === '1';

    if ( empty( $title ) || empty( $message ) ) {
        wp_send_json_error( [ 'message' => 'Title and message are required.' ] );
        return;
    }

    // Determine target users (supports "all" or comma-separated group IDs)
    $users = [];
    if ( $target === 'all' ) {
        // Get all users in all LearnDash groups
        if ( function_exists( 'learndash_get_groups' ) ) {
            $all_groups = learndash_get_groups();
            foreach ( $all_groups as $g ) {
                $members = glct_members( $g->ID );
                foreach ( $members as $m ) {
                    $users[ $m->ID ] = [ 'user' => $m, 'group_id' => $g->ID, 'group_name' => $g->post_title ];
                }
            }
        }
    } else {
        // Support comma-separated group IDs for multi-select
        $target_ids = array_filter( array_map( 'intval', explode( ',', $target ) ) );
        foreach ( $target_ids as $gid ) {
            $group_name = get_the_title( $gid ) ?: 'Group';
            $members = glct_members( $gid );
            foreach ( $members as $m ) {
                if ( ! isset( $users[ $m->ID ] ) ) {
                    $users[ $m->ID ] = [ 'user' => $m, 'group_id' => $gid, 'group_name' => $group_name ];
                }
            }
        }
    }

    if ( empty( $users ) ) {
        wp_send_json_error( [ 'message' => 'No learners found in the selected target.' ] );
        return;
    }

    // Personalize per user and prepare batched insert rows
    global $wpdb;
    $table  = $wpdb->prefix . 'glct_notifications';
    $now    = current_time( 'mysql' );
    $count  = 0;
    $batch  = [];
    $emails = []; // queue for async sending

    foreach ( $users as $uid => $data ) {
        $user = $data['user'];
        $personalized = str_replace(
            [ '{first_name}', '{last_name}', '{name}', '{group_name}' ],
            [ $user->first_name, $user->last_name, $user->display_name, $data['group_name'] ],
            $message
        );
        $personalized_title = str_replace(
            [ '{first_name}', '{last_name}', '{name}', '{group_name}' ],
            [ $user->first_name, $user->last_name, $user->display_name, $data['group_name'] ],
            $title
        );

        $batch[] = $wpdb->prepare(
            '(%d, %s, %d, %d, %s, %s, %s)',
            $uid, 'update', $data['group_id'], 0, $personalized_title, $personalized, $now
        );
        $count++;

        // Queue email for async processing
        if ( $sendEmail && $user->user_email ) {
            $emails[] = [
                'to'      => $user->user_email,
                'subject' => $personalized_title,
                'body'    => nl2br( $personalized ),
            ];
        }

        // Flush insert batch every 100 rows
        if ( count( $batch ) >= 100 ) {
            $wpdb->query( "INSERT INTO {$table} (user_id, type, group_id, course_id, title, message, created_at) VALUES " . implode( ',', $batch ) );
            $batch = [];
        }
    }
    // Flush remaining rows
    if ( ! empty( $batch ) ) {
        $wpdb->query( "INSERT INTO {$table} (user_id, type, group_id, course_id, title, message, created_at) VALUES " . implode( ',', $batch ) );
    }

    // Queue emails via WP Cron (processed in batches of 25)
    $email_count = count( $emails );
    if ( $email_count > 0 ) {
        $batch_id = 'glct_email_' . time() . '_' . wp_rand();
        update_option( $batch_id, $emails, false ); // autoload = false
        if ( ! wp_next_scheduled( 'glct_process_email_queue', [ $batch_id ] ) ) {
            wp_schedule_single_event( time(), 'glct_process_email_queue', [ $batch_id ] );
        }
    }

    $msg = "Update sent to {$count} learner" . ( $count !== 1 ? 's' : '' );
    if ( $sendEmail ) {
        $msg .= " ({$email_count} email" . ( $email_count !== 1 ? 's' : '' ) . " queued)";
    }
    $msg .= '.';

    wp_send_json_success( [ 'message' => $msg ] );
} );

// Async email queue processor — sends emails in batches of 25 to prevent timeouts
add_action( 'glct_process_email_queue', function ( string $batch_id ): void {
    $emails = get_option( $batch_id, [] );
    if ( empty( $emails ) ) {
        delete_option( $batch_id );
        return;
    }

    $chunk = array_splice( $emails, 0, 25 );
    foreach ( $chunk as $mail ) {
        wp_mail( $mail['to'], $mail['subject'], $mail['body'], [ 'Content-Type: text/html; charset=UTF-8' ] );
    }

    if ( ! empty( $emails ) ) {
        // More emails remain — re-queue for next cron tick
        update_option( $batch_id, $emails, false );
        wp_schedule_single_event( time() + 10, 'glct_process_email_queue', [ $batch_id ] );
    } else {
        delete_option( $batch_id );
    }
} );

function glct_settings_page(): void {
    ?>
    <div class="wrap">
        <h1>LearnDash Group Leader Course Toggle — Settings</h1>
        <hr>
        <form method="post" action="options.php">
            <?php
            settings_fields( 'glct_general_settings' );
            do_settings_sections( 'glct-settings' );
            submit_button( 'Save All Settings' );
            ?>
        </form>

    </div>
    <?php
}


// ═══════════════════════════════════════════════════════════════════════════
// SECTION 10 — AUDIT LOGGING & EXPORT
// ═══════════════════════════════════════════════════════════════════════════

add_action( 'plugins_loaded', 'glct_check_audit_db' );
function glct_check_audit_db(): void {
    if ( get_option( 'glct_db_version' ) !== '2.1.0' ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'glct_audit_log';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            timestamp datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            leader_id bigint(20) NOT NULL,
            action varchar(20) NOT NULL,
            group_id bigint(20) NOT NULL,
            course_id bigint(20) NOT NULL,
            user_id bigint(20) DEFAULT 0 NOT NULL,
            state tinyint(1) NOT NULL,
            PRIMARY KEY  (id),
            KEY idx_group_ts (group_id, timestamp),
            KEY idx_action_ts (action, timestamp),
            KEY idx_user_ts (user_id, timestamp),
            KEY idx_timestamp (timestamp)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
        update_option( 'glct_db_version', '2.1.0' );
    }
}

function glct_log_event( string $action, int $group_id, int $course_id, int $user_id, bool $state ): void {
    global $wpdb;
    $wpdb->insert(
        $wpdb->prefix . 'glct_audit_log',
        [
            'timestamp' => current_time( 'mysql' ),
            'leader_id' => get_current_user_id() ?: 0, 
            'action'    => $action,
            'group_id'  => $group_id,
            'course_id' => $course_id,
            'user_id'   => $user_id,
            'state'     => $state ? 1 : 0,
        ],
        [ '%s', '%d', '%s', '%d', '%d', '%d', '%d' ]
    );
}

// Admin Audit Log Page
add_action( 'admin_menu', function (): void {
    add_submenu_page(
        'glct-settings',
        'GLCT Audit Log',
        'Audit Log',
        'manage_options',
        'glct-audit-log',
        'glct_render_audit_log_page'
    );
} );

function glct_render_audit_log_page(): void {
    global $wpdb;
    $table_name = $wpdb->prefix . 'glct_audit_log';

    // Filters
    $where = "WHERE 1=1";
    if ( !empty($_GET['glct_action']) ) {
        $where .= $wpdb->prepare(" AND action = %s", sanitize_text_field($_GET['glct_action']));
    }
    if ( !empty($_GET['glct_search']) ) {
        $search = '%' . $wpdb->esc_like(sanitize_text_field($_GET['glct_search'])) . '%';
        $where .= $wpdb->prepare(" AND (group_id IN (SELECT ID FROM {$wpdb->prefix}posts WHERE post_title LIKE %s) OR course_id IN (SELECT ID FROM {$wpdb->prefix}posts WHERE post_title LIKE %s))", $search, $search);
    }

    $logs = $wpdb->get_results( "SELECT * FROM {$table_name} {$where} ORDER BY timestamp DESC LIMIT 300" );
    
    $export_url = wp_nonce_url(
        add_query_arg(['action' => 'glct_export_csv', 'glct_action' => sanitize_text_field( $_GET['glct_action'] ?? '' ), 'glct_search' => sanitize_text_field( $_GET['glct_search'] ?? '' )], admin_url('admin-post.php')),
        'glct_export_csv'
    );
    ?>
    <div class="wrap">
        <h1 class="wp-heading-inline">Course Manager Audit Log</h1>
        <a href="<?php echo esc_url($export_url); ?>" class="page-title-action">Export to CSV</a>
        <hr class="wp-header-end">
        
        <form method="get" style="margin-bottom:20px; display:flex; gap:10px; align-items:center;">
            <input type="hidden" name="page" value="glct-audit-log">
            <select name="glct_action">
                <option value="">All Action Types</option>
                <option value="group" <?php selected($_GET['glct_action']??'', 'group'); ?>>Group Toggle</option>
                <option value="user" <?php selected($_GET['glct_action']??'', 'user'); ?>>Per-User Toggle</option>
                <option value="user_wipe" <?php selected($_GET['glct_action']??'', 'user_wipe'); ?>>Progress Wiped</option>
                <option value="course_removed" <?php selected($_GET['glct_action']??'', 'course_removed'); ?>>Course Removed</option>
                <option value="course_added" <?php selected($_GET['glct_action']??'', 'course_added'); ?>>Course Added</option>
                <option value="learner_read" <?php selected($_GET['glct_action']??'', 'learner_read'); ?>>Notification Viewed</option>
                <option value="learner_read_all" <?php selected($_GET['glct_action']??'', 'learner_read_all'); ?>>All Read</option>
                <option value="learner_dismissed" <?php selected($_GET['glct_action']??'', 'learner_dismissed'); ?>>Popup Dismissed</option>
                <option value="learner_welcomed" <?php selected($_GET['glct_action']??'', 'learner_welcomed'); ?>>Update Acknowledged</option>
                <option value="user_inactive" <?php selected($_GET['glct_action']??'', 'user_inactive'); ?>>Inactive Member</option>
                <option value="deadline_set" <?php selected($_GET['glct_action']??'', 'deadline_set'); ?>>Deadline Set</option>
                <option value="deadline_cleared" <?php selected($_GET['glct_action']??'', 'deadline_cleared'); ?>>Deadline Cleared</option>
                <option value="deadline_remind" <?php selected($_GET['glct_action']??'', 'deadline_remind'); ?>>Deadline Reminder</option>
                <option value="deadline_overdue" <?php selected($_GET['glct_action']??'', 'deadline_overdue'); ?>>Deadline Overdue</option>
            </select>
            <input type="text" name="glct_search" placeholder="Search Group or Course Name..." value="<?php echo esc_attr($_GET['glct_search']??''); ?>">
            <input type="submit" class="button" value="Filter">
        </form>

        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th style="width: 15%">Date / Time</th>
                    <th style="width: 15%">Leader</th>
                    <th style="width: 15%">Action Type</th>
                    <th style="width: 20%">Group</th>
                    <th style="width: 15%">Course</th>
                    <th style="width: 10%">Target User</th>
                    <th style="width: 10%">State</th>
                </tr>
            </thead>
            <tbody>
                <?php if ( empty( $logs ) ) : ?>
                    <tr><td colspan="7">No logs found.</td></tr>
                <?php else : ?>
                    <?php
                    // Pre-fetch all users and post titles referenced in logs to eliminate N+1
                    $_admin_user_ids = [];
                    $_admin_post_ids = [];
                    foreach ( $logs as $_l ) {
                        if ( $_l->leader_id ) $_admin_user_ids[] = (int) $_l->leader_id;
                        if ( $_l->user_id )   $_admin_user_ids[] = (int) $_l->user_id;
                        if ( $_l->group_id )  $_admin_post_ids[] = (int) $_l->group_id;
                        if ( $_l->course_id ) $_admin_post_ids[] = (int) $_l->course_id;
                    }
                    $_admin_user_map = [];
                    if ( ! empty( $_admin_user_ids ) ) {
                        $_fetched = get_users( [ 'include' => array_unique( $_admin_user_ids ), 'fields' => [ 'ID', 'display_name' ] ] );
                        foreach ( $_fetched as $_u ) { $_admin_user_map[ (int) $_u->ID ] = $_u->display_name; }
                    }
                    $_admin_title_map = [];
                    if ( ! empty( $_admin_post_ids ) ) {
                        _prime_post_caches( array_unique( $_admin_post_ids ), false, false );
                        foreach ( array_unique( $_admin_post_ids ) as $_pid ) {
                            $_admin_title_map[ $_pid ] = get_the_title( $_pid ) ?: '';
                        }
                    }
                    ?>
                    <?php foreach ( $logs as $log ) :
                        $leader_name = 'Unknown';
                        if ( $log->leader_id == 0 ) {
                            $leader_name = 'System (Automated)';
                        } else {
                            $leader_name = $_admin_user_map[ (int) $log->leader_id ] ?? 'Unknown';
                        }

                        $group_name = ( $_admin_title_map[ (int) $log->group_id ] ?? '' ) ?: 'Deleted Group';
                        $course_name = ( $_admin_title_map[ (int) $log->course_id ] ?? '' ) ?: 'Deleted Course';

                        $target_user = '-';
                        if ( $log->user_id ) {
                            $target_user = $_admin_user_map[ (int) $log->user_id ] ?? 'Deleted User';
                        }
                        
                        $action_display = $log->action;
                        if ($log->action === 'group')          $action_display = 'Group-wide Default';
                        if ($log->action === 'user')           $action_display = 'Per-User Override';
                        if ($log->action === 'course_removed') $action_display = 'Course Removed';
                        if ($log->action === 'course_added')   $action_display = 'Course Added';
                        if (strpos($log->action, 'wipe') !== false) $action_display = 'Progress Wiped';
                        if ($log->action === 'learner_read')      $action_display = 'Notification Viewed';
                        if ($log->action === 'learner_read_all')  $action_display = 'All Notifications Read';
                        if ($log->action === 'learner_dismissed') $action_display = 'Popup Dismissed';
                        if ($log->action === 'learner_welcomed')  $action_display = 'Update Acknowledged';
                        if ($log->action === 'user_inactive')     $action_display = 'Inactive Member';
                        if ($log->action === 'deadline_set')      $action_display = 'Deadline Set';
                        if ($log->action === 'deadline_cleared')  $action_display = 'Deadline Cleared';
                        if ($log->action === 'deadline_remind')   $action_display = 'Deadline Reminder';
                        if ($log->action === 'deadline_overdue')  $action_display = 'Deadline Overdue';

                        if ( strpos($log->action, 'wipe') !== false ) {
                            $state_badge = '<span style="background:#f2f4f8;color:#4a5876;padding:3px 8px;border-radius:4px;font-weight:600;font-size:12px;border:1px solid #c5cfe4;">Wiped</span>';
                        } elseif ( $log->action === 'course_removed' ) {
                            $state_badge = '<span style="background:#fff4f3;color:#c8332a;padding:3px 8px;border-radius:4px;font-weight:600;font-size:12px;border:1px solid #f9b2ae;">Removed</span>';
                        } elseif ( strpos($log->action, 'learner_') === 0 ) {
                            $state_badge = '<span style="background:#eef2ff;color:#3d63dd;padding:3px 8px;border-radius:4px;font-weight:600;font-size:12px;border:1px solid #afc2ff;">Acknowledged</span>';
                        } elseif ( $log->action === 'user_inactive' ) {
                            $state_badge = '<span style="background:#fef3c7;color:#b45309;padding:3px 8px;border-radius:4px;font-weight:600;font-size:12px;border:1px solid #fcd34d;">Inactive</span>';
                        } elseif ( $log->action === 'deadline_overdue' ) {
                            $state_badge = '<span style="background:#fff4f3;color:#c8332a;padding:3px 8px;border-radius:4px;font-weight:600;font-size:12px;border:1px solid #f9b2ae;">Overdue</span>';
                        } elseif ( strpos($log->action, 'deadline_') === 0 ) {
                            $state_badge = '<span style="background:#eef2ff;color:#3d63dd;padding:3px 8px;border-radius:4px;font-weight:600;font-size:12px;border:1px solid #afc2ff;">' . esc_html( ucfirst( str_replace('deadline_', '', $log->action) ) ) . '</span>';
                        } else {
                            $state_badge = $log->state
                                ? '<span style="background:#eafaf4;color:#0b7d5c;padding:3px 8px;border-radius:4px;font-weight:600;font-size:12px;">Enabled</span>'
                                : '<span style="background:#fff4f3;color:#c8332a;padding:3px 8px;border-radius:4px;font-weight:600;font-size:12px;">Disabled</span>';
                        }
                    ?>
                    <tr>
                        <td><?php echo esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $log->timestamp ) ) ); ?></td>
                        <td><?php echo esc_html( $leader_name ); ?></td>
                        <td><?php echo esc_html( $action_display ); ?></td>
                        <td><?php echo esc_html( $group_name ); ?></td>
                        <td><?php echo esc_html( $course_name ); ?></td>
                        <td><?php echo esc_html( $target_user ); ?></td>
                        <td><?php echo $state_badge; ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}

// Handle CSV Export
add_action('admin_post_glct_export_csv', function() {
    if ( ! current_user_can('manage_options') ) wp_die('Unauthorized');
    check_admin_referer( 'glct_export_csv' );

    global $wpdb;
    $table_name = $wpdb->prefix . 'glct_audit_log';
    
    $where = "WHERE 1=1";
    if ( !empty($_GET['glct_action']) ) {
        $where .= $wpdb->prepare(" AND action = %s", sanitize_text_field($_GET['glct_action']));
    }
    if ( !empty($_GET['glct_search']) ) {
        $search = '%' . $wpdb->esc_like(sanitize_text_field($_GET['glct_search'])) . '%';
        $where .= $wpdb->prepare(" AND (group_id IN (SELECT ID FROM {$wpdb->prefix}posts WHERE post_title LIKE %s) OR course_id IN (SELECT ID FROM {$wpdb->prefix}posts WHERE post_title LIKE %s))", $search, $search);
    }

    $logs = $wpdb->get_results( "SELECT * FROM {$table_name} {$where} ORDER BY timestamp DESC LIMIT 10000" );

    // Pre-fetch all referenced users in one query to eliminate N+1
    $user_ids = [];
    foreach ( $logs as $log ) {
        if ( $log->leader_id ) $user_ids[] = (int) $log->leader_id;
        if ( $log->user_id )   $user_ids[] = (int) $log->user_id;
    }
    $user_map = [];
    if ( ! empty( $user_ids ) ) {
        $fetched = get_users( [ 'include' => array_unique( $user_ids ), 'fields' => [ 'ID', 'display_name' ] ] );
        foreach ( $fetched as $u ) { $user_map[ $u->ID ] = $u->display_name; }
    }

    // Pre-fetch all referenced post titles to eliminate N+1
    $post_ids = [];
    foreach ( $logs as $log ) {
        if ( $log->group_id )  $post_ids[] = (int) $log->group_id;
        if ( $log->course_id ) $post_ids[] = (int) $log->course_id;
    }
    $admin_csv_title_map = [];
    if ( ! empty( $post_ids ) ) {
        _prime_post_caches( array_unique( $post_ids ), false, false );
        foreach ( array_unique( $post_ids ) as $pid ) {
            $admin_csv_title_map[ $pid ] = get_the_title( $pid ) ?: '';
        }
    }

    nocache_headers();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=glct_audit_log_' . gmdate('Y-m-d') . '.csv');
    $output = fopen('php://output', 'w');

    fputcsv($output, ['Date', 'Leader', 'Action', 'Group', 'Course', 'Target User', 'State']);

    foreach ($logs as $log) {
        $leader = $log->leader_id == 0 ? 'System (Automated)' : ( $user_map[ $log->leader_id ] ?? 'Unknown' );
        $group = ( $admin_csv_title_map[ (int) $log->group_id ] ?? '' ) ?: 'Deleted Group';
        $course = ( $admin_csv_title_map[ (int) $log->course_id ] ?? '' ) ?: 'Deleted Course';
        $user = $log->user_id ? ( $user_map[ $log->user_id ] ?? 'Deleted User' ) : '-';

        $action_label = $log->action;
        if ($log->action === 'group')          $action_label = 'Group-wide Default';
        if ($log->action === 'user')           $action_label = 'Per-User Override';
        if ($log->action === 'course_removed') $action_label = 'Course Removed';
        if ($log->action === 'course_added')   $action_label = 'Course Added';
        if (strpos($log->action, 'wipe') !== false) $action_label = 'Progress Wiped';
        if ($log->action === 'learner_read')      $action_label = 'Notification Viewed';
        if ($log->action === 'learner_read_all')  $action_label = 'All Notifications Read';
        if ($log->action === 'learner_dismissed') $action_label = 'Popup Dismissed';
        if ($log->action === 'learner_welcomed')  $action_label = 'Update Acknowledged';
        if ($log->action === 'user_inactive')     $action_label = 'Inactive Member';
        if ($log->action === 'deadline_set')      $action_label = 'Deadline Set';
        if ($log->action === 'deadline_cleared')  $action_label = 'Deadline Cleared';
        if ($log->action === 'deadline_remind')   $action_label = 'Deadline Reminder';
        if ($log->action === 'deadline_overdue')  $action_label = 'Deadline Overdue';

        $state = $log->state ? 'Enabled' : 'Disabled';
        if (strpos($log->action, 'wipe') !== false)    $state = 'Wiped';
        if ($log->action === 'course_removed')          $state = 'Removed';
        if (strpos($log->action, 'learner_') === 0)    $state = 'Acknowledged';
        if ($log->action === 'user_inactive')           $state = 'Inactive';
        if ($log->action === 'deadline_set')            $state = 'Set';
        if ($log->action === 'deadline_cleared')        $state = 'Cleared';
        if ($log->action === 'deadline_remind')         $state = 'Sent';
        if ($log->action === 'deadline_overdue')        $state = 'Overdue';

        fputcsv($output, [$log->timestamp, $leader, $action_label, $group, $course, $user, $state]);
    }
    fclose($output);
    exit;
});


// ═══════════════════════════════════════════════════════════════════════════
// SECTION 11 — AUTO-PURGE (AUDIT LOG RETENTION)
// ═══════════════════════════════════════════════════════════════════════════

register_deactivation_hook( __FILE__, function (): void {
    wp_clear_scheduled_hook( 'glct_daily_cleanup' );
} );

add_action( 'init', function (): void {
    if ( ! wp_next_scheduled( 'glct_daily_cleanup' ) ) {
        wp_schedule_event( time(), 'daily', 'glct_daily_cleanup' );
    }
} );

add_action( 'glct_daily_cleanup', function(): void {
    global $wpdb;

    $days = (int) get_option( 'glct_log_retention', 90 );
    if ( $days > 0 ) {
        $table = $wpdb->prefix . 'glct_audit_log';
        $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$table} WHERE timestamp < DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ) );
    }

    // Purge old learner notifications
    $notif_days = (int) get_option( 'glct_notification_retention', 90 );
    if ( $notif_days > 0 ) {
        $ntable = $wpdb->prefix . 'glct_notifications';
        $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$ntable} WHERE created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
            $notif_days
        ) );
    }

    // Inactivity alerts — check for users who haven't accessed training
    $inactivity_days = (int) get_option( 'glct_inactivity_days', 0 );
    if ( $inactivity_days > 0 ) {
        $cutoff      = time() - ( $inactivity_days * DAY_IN_SECONDS );
        $audit_table = $wpdb->prefix . 'glct_audit_log';

        // Only find learners (subscribers) in LD groups — JOIN on usermeta role to filter early
        // instead of querying ALL wp_users and checking roles in PHP
        $inactive_users = $wpdb->get_results( $wpdb->prepare(
            "SELECT u.ID as user_id, um.meta_value as last_activity
             FROM {$wpdb->users} u
             LEFT JOIN {$wpdb->usermeta} um ON u.ID = um.user_id AND um.meta_key = 'glct_last_activity'
             INNER JOIN {$wpdb->usermeta} cap ON u.ID = cap.user_id AND cap.meta_key = %s
             WHERE ( um.meta_value IS NULL OR um.meta_value < %d )
             AND cap.meta_value NOT LIKE %s
             AND cap.meta_value NOT LIKE %s
             LIMIT 500",
            $wpdb->get_blog_prefix() . 'capabilities',
            $cutoff,
            '%administrator%',
            '%group_leader%'
        ) );

        if ( ! empty( $inactive_users ) ) {
            $inactive_uids = array_map( fn( $r ) => (int) $r->user_id, $inactive_users );

            // Batch-fetch existing inactivity alerts for all these users in one query
            $uid_placeholders = implode( ',', array_fill( 0, count( $inactive_uids ), '%d' ) );
            $existing_alerts  = $wpdb->get_results( $wpdb->prepare(
                "SELECT user_id, group_id FROM {$audit_table}
                 WHERE action = 'user_inactive' AND user_id IN ($uid_placeholders)
                 AND timestamp > DATE_SUB(NOW(), INTERVAL %d DAY)",
                ...array_merge( $inactive_uids, [ $inactivity_days ] )
            ) );
            $existing_set = [];
            foreach ( $existing_alerts as $ea ) {
                $existing_set[ (int) $ea->user_id . '_' . (int) $ea->group_id ] = true;
            }

            // Collect all inserts in a batch
            $insert_batch = [];
            $now_str = current_time( 'mysql' );
            foreach ( $inactive_users as $row ) {
                $uid = (int) $row->user_id;
                $user_groups = function_exists( 'learndash_get_users_group_ids' )
                    ? learndash_get_users_group_ids( $uid ) : [];
                if ( empty( $user_groups ) ) continue;

                foreach ( $user_groups as $gid ) {
                    $key = $uid . '_' . (int) $gid;
                    if ( isset( $existing_set[ $key ] ) ) continue;
                    $insert_batch[] = $wpdb->prepare(
                        '(%s, %d, %s, %d, %d, %d, %d)',
                        $now_str, 0, 'user_inactive', (int) $gid, 0, $uid, 0
                    );
                    if ( count( $insert_batch ) >= 100 ) {
                        $wpdb->query( "INSERT INTO {$audit_table} (timestamp, leader_id, action, group_id, course_id, user_id, state) VALUES " . implode( ',', $insert_batch ) );
                        $insert_batch = [];
                    }
                }
            }
            if ( ! empty( $insert_batch ) ) {
                $wpdb->query( "INSERT INTO {$audit_table} (timestamp, leader_id, action, group_id, course_id, user_id, state) VALUES " . implode( ',', $insert_batch ) );
            }
        }
    }

    // Deadline reminders and overdue alerts
    if ( get_option( 'glct_allow_deadlines', 'yes' ) === 'yes' ) {
        $reminder_days_opt   = get_option( 'glct_deadline_reminder_days', '7,1' );
        $reminder_intervals  = array_filter( array_map( 'intval', explode( ',', $reminder_days_opt ) ) );
        $audit_table         = $wpdb->prefix . 'glct_audit_log';
        $ntable              = $wpdb->prefix . 'glct_notifications';

        $all_groups = get_posts( [
            'post_type'      => glct_group_post_type(),
            'posts_per_page' => -1,
            'post_status'    => 'publish',
            'fields'         => 'ids',
        ] );

        foreach ( $all_groups as $group_id ) {
            $group_id  = (int) $group_id;
            $deadlines = glct_get_all_deadlines( $group_id );
            if ( empty( $deadlines ) ) continue;

            $members    = glct_members( $group_id );
            $member_ids = array_map( fn( WP_User $u ): int => $u->ID, $members );
            if ( empty( $member_ids ) ) continue;

            // Fetch all course progress in one pass for this group
            $deadline_course_ids = array_map( 'intval', array_keys( $deadlines ) );
            $all_course_progress = glct_batch_multi_course_progress( $member_ids, $deadline_course_ids );

            // Batch-fetch existing overdue alerts for this group to avoid per-user queries
            $overdue_course_ids = [];
            foreach ( $deadlines as $course_id => $deadline_date ) {
                $now  = new DateTime( current_time( 'Y-m-d' ) );
                $due  = new DateTime( $deadline_date );
                $diff = (int) $now->diff( $due )->format( '%r%a' );
                if ( $diff < 0 ) $overdue_course_ids[] = (int) $course_id;
            }

            $existing_overdue_set = [];
            if ( ! empty( $overdue_course_ids ) ) {
                $cid_placeholders = implode( ',', array_fill( 0, count( $overdue_course_ids ), '%d' ) );
                $existing_rows    = $wpdb->get_results( $wpdb->prepare(
                    "SELECT user_id, course_id FROM {$audit_table}
                     WHERE action = 'deadline_overdue' AND group_id = %d
                     AND course_id IN ($cid_placeholders)
                     AND timestamp > DATE_SUB(NOW(), INTERVAL 1 DAY)",
                    $group_id, ...$overdue_course_ids
                ) );
                foreach ( $existing_rows as $er ) {
                    $existing_overdue_set[ (int) $er->user_id . '_' . (int) $er->course_id ] = true;
                }
            }

            $now_str      = current_time( 'mysql' );
            $audit_batch  = [];
            $notif_batch  = [];

            foreach ( $deadlines as $course_id => $deadline_date ) {
                $course_id = (int) $course_id;
                $now  = new DateTime( current_time( 'Y-m-d' ) );
                $due  = new DateTime( $deadline_date );
                $diff = (int) $now->diff( $due )->format( '%r%a' );

                $course_title = get_the_title( $course_id );
                $progress     = $all_course_progress[ $course_id ] ?? [];

                // Overdue — log once per day per user, notify learners + group leaders
                if ( $diff < 0 ) {
                    $overdue_learner_count = 0;
                    foreach ( $progress as $uid => $p ) {
                        if ( $p['status'] === 'completed' ) continue;
                        $key = (int) $uid . '_' . $course_id;
                        if ( isset( $existing_overdue_set[ $key ] ) ) continue;

                        // Audit log entry
                        $audit_batch[] = $wpdb->prepare(
                            '(%s, %d, %s, %d, %d, %d, %d)',
                            $now_str, 0, 'deadline_overdue', $group_id, $course_id, (int) $uid, 0
                        );

                        // Notify the learner that their deadline was missed
                        $overdue_days = abs( $diff );
                        $notif_batch[] = $wpdb->prepare(
                            '(%d, %s, %d, %d, %s, %s, %s)',
                            (int) $uid,
                            'deadline',
                            $group_id,
                            $course_id,
                            "Deadline Missed: {$course_title}",
                            "The deadline for \"{$course_title}\" was {$overdue_days} day(s) ago. Please complete this course as soon as possible.",
                            $now_str
                        );
                        $overdue_learner_count++;

                        if ( count( $audit_batch ) >= 100 ) {
                            $wpdb->query( "INSERT INTO {$audit_table} (timestamp, leader_id, action, group_id, course_id, user_id, state) VALUES " . implode( ',', $audit_batch ) );
                            $audit_batch = [];
                        }
                        if ( count( $notif_batch ) >= 100 ) {
                            $wpdb->query( "INSERT INTO {$ntable} (user_id, type, group_id, course_id, title, message, created_at) VALUES " . implode( ',', $notif_batch ) );
                            $notif_batch = [];
                        }
                    }

                    // Notify Group Leaders about missed deadlines (once per day per course)
                    if ( $overdue_learner_count > 0 ) {
                        $gl_ids = glct_group_leaders( $group_id );
                        $group_name = get_the_title( $group_id );
                        $learner_word = $overdue_learner_count === 1 ? 'learner has' : 'learners have';
                        foreach ( $gl_ids as $gl_id ) {
                            $notif_batch[] = $wpdb->prepare(
                                '(%d, %s, %d, %d, %s, %s, %s)',
                                $gl_id,
                                'deadline',
                                $group_id,
                                $course_id,
                                "Deadline Missed: {$course_title}",
                                "{$overdue_learner_count} {$learner_word} missed the deadline for \"{$course_title}\" in {$group_name}. Review the Compliance Dashboard for details.",
                                $now_str
                            );
                            if ( count( $notif_batch ) >= 100 ) {
                                $wpdb->query( "INSERT INTO {$ntable} (user_id, type, group_id, course_id, title, message, created_at) VALUES " . implode( ',', $notif_batch ) );
                                $notif_batch = [];
                            }
                        }
                    }
                    continue;
                }

                // Approaching deadline — send reminders
                foreach ( $reminder_intervals as $interval ) {
                    if ( $diff === $interval ) {
                        foreach ( $progress as $uid => $p ) {
                            if ( $p['status'] === 'completed' ) continue;
                            $notif_batch[] = $wpdb->prepare(
                                '(%d, %s, %d, %d, %s, %s, %s)',
                                (int) $uid,
                                'deadline',
                                $group_id,
                                $course_id,
                                "Deadline Approaching: {$course_title}",
                                "Your course \"{$course_title}\" is due in {$interval} day(s). Please complete it before the deadline.",
                                $now_str
                            );
                            if ( count( $notif_batch ) >= 100 ) {
                                $wpdb->query( "INSERT INTO {$ntable} (user_id, type, group_id, course_id, title, message, created_at) VALUES " . implode( ',', $notif_batch ) );
                                $notif_batch = [];
                            }
                        }
                        // Log the reminder event once
                        $audit_batch[] = $wpdb->prepare(
                            '(%s, %d, %s, %d, %d, %d, %d)',
                            $now_str, 0, 'deadline_remind', $group_id, $course_id, 0, 1
                        );
                    }
                }
            }

            // Flush remaining batches for this group
            if ( ! empty( $audit_batch ) ) {
                $wpdb->query( "INSERT INTO {$audit_table} (timestamp, leader_id, action, group_id, course_id, user_id, state) VALUES " . implode( ',', $audit_batch ) );
            }
            if ( ! empty( $notif_batch ) ) {
                $wpdb->query( "INSERT INTO {$ntable} (user_id, type, group_id, course_id, title, message, created_at) VALUES " . implode( ',', $notif_batch ) );
            }
        }
    }
} );


// ═══════════════════════════════════════════════════════════════════════════
// SECTION 12 — LEARNDASH PROGRESS WIPER HELPER
// ═══════════════════════════════════════════════════════════════════════════

function glct_wipe_course_progress( int $user_id, int $course_id ): void {
    delete_user_meta( $user_id, 'course_completed_' . $course_id );
    
    $progress = get_user_meta( $user_id, '_sfwd-course_progress', true );
    if ( is_array( $progress ) && isset( $progress[$course_id] ) ) {
        unset( $progress[$course_id] );
        update_user_meta( $user_id, '_sfwd-course_progress', $progress );
    }
    
    global $wpdb;
    $table = $wpdb->prefix . 'learndash_user_activity';
    if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) === $table ) {
        $wpdb->delete( 
            $table, 
            [ 'user_id' => $user_id, 'course_id' => $course_id ], 
            [ '%d', '%d' ] 
        );
    }
}


// ═══════════════════════════════════════════════════════════════════════════
// SECTION 13 — NATIVE LEARNDASH META BOXES (BACKEND)
// ═══════════════════════════════════════════════════════════════════════════

add_action('add_meta_boxes', function() {
    add_meta_box('glct_group_status', 'GLCT Access Overrides', 'glct_render_group_metabox', 'groups', 'side', 'default');
    add_meta_box('glct_course_status', 'GLCT Access Overrides', 'glct_render_course_metabox', 'sfwd-courses', 'side', 'default');

    if ( get_option( 'glct_allow_expansion', 'no' ) === 'yes' ) {
        add_meta_box( 'glct_expansion_tags', 'GLCT Course Expansion Tags', 'glct_render_expansion_metabox', 'groups', 'normal', 'high' );
    }
});

/**
 * Renders the Course Expansion Tags meta box on the Group edit page.
 * Admin selects which LearnDash course tags Group Leaders can browse.
 */
function glct_render_expansion_metabox( $post ) {
    $gid = $post->ID;
    wp_nonce_field( 'glct_expansion_save', 'glct_expansion_nonce' );

    $saved_tags = (array) get_post_meta( $gid, 'glct_expansion_tags', true );
    $saved_tags = array_filter( array_map( 'intval', $saved_tags ) );

    // Get all LearnDash course tags (taxonomy: ld_course_tag)
    $ld_tags = get_terms( [
        'taxonomy'   => 'ld_course_tag',
        'hide_empty' => false,
    ] );

    if ( is_wp_error( $ld_tags ) || empty( $ld_tags ) ) {
        echo '<p style="color:#646970;">No LearnDash Course Tags found. Create tags under LearnDash → Courses → Tags first.</p>';
        return;
    }

    echo '<p style="margin-top:0;">Select which LearnDash course tags this group\'s leader can use to browse and add courses. <strong>Uncheck to remove.</strong></p>';
    echo '<div style="display:flex; align-items:center; gap:12px; margin-bottom:8px;">';
    echo '<a href="#" onclick="document.querySelectorAll(\'#glct-expansion-tag-list input[type=checkbox]\').forEach(function(c){c.checked=true});return false;" style="font-size:12px;">Select All</a>';
    echo '<a href="#" onclick="document.querySelectorAll(\'#glct-expansion-tag-list input[type=checkbox]\').forEach(function(c){c.checked=false});return false;" style="font-size:12px; color:#b32d2e;">Clear All</a>';
    echo '</div>';
    echo '<div id="glct-expansion-tag-list" style="display:flex; flex-wrap:wrap; gap:8px; margin-bottom:12px;">';
    foreach ( $ld_tags as $tag ) {
        $checked = in_array( $tag->term_id, $saved_tags, true ) ? ' checked' : '';
        $bg = $checked ? '#e6f0ff; border:1px solid #afc2ff' : '#f0f0f1; border:1px solid transparent';
        echo '<label style="display:inline-flex; align-items:center; gap:6px; padding:6px 12px; background:' . $bg . '; border-radius:4px; cursor:pointer; font-size:13px; transition: all .15s;">';
        echo '<input type="checkbox" name="glct_expansion_tags[]" value="' . esc_attr( $tag->term_id ) . '"' . $checked . ' onchange="this.parentElement.style.background=this.checked?\'#e6f0ff\':\'#f0f0f1\';this.parentElement.style.border=this.checked?\'1px solid #afc2ff\':\'1px solid transparent\'">';
        echo esc_html( $tag->name );
        $count = $tag->count;
        echo ' <span style="color:#646970; font-size:11px;">(' . $count . ' course' . ( $count !== 1 ? 's' : '' ) . ')</span>';
        echo '</label>';
    }
    echo '</div>';
    if ( ! empty( $saved_tags ) ) {
        echo '<p style="font-size:12px; color:#646970; margin-bottom:8px;"><em>💡 Removing a tag here only prevents the leader from adding new courses with that tag. Courses already added to the group remain until manually removed.</em></p>';
    }

    // Preview which courses match
    if ( ! empty( $saved_tags ) ) {
        $existing_courses = array_filter( array_map( 'intval',
            (array) get_post_meta( $gid, 'glct_master_courses', true )
        ) );
        $ld_enrolled = function_exists( 'learndash_group_enrolled_courses' )
            ? array_map( 'intval', (array) learndash_group_enrolled_courses( $gid ) )
            : [];
        $group_courses = array_unique( array_merge( $existing_courses, $ld_enrolled ) );

        $args = [
            'post_type'      => 'sfwd-courses',
            'posts_per_page' => -1,
            'post_status'    => 'publish',
            'tax_query'      => [
                [
                    'taxonomy' => 'ld_course_tag',
                    'field'    => 'term_id',
                    'terms'    => $saved_tags,
                ],
            ],
            'fields' => 'ids',
        ];
        $available = get_posts( $args );
        $available = array_map( 'intval', $available );
        $not_in_group = array_diff( $available, $group_courses );

        echo '<div style="background:#f9f9f9; border:1px solid #ddd; border-radius:4px; padding:12px; margin-top:8px;">';
        echo '<strong style="font-size:12px; color:#646970; text-transform:uppercase; letter-spacing:.5px;">Preview:</strong> ';
        echo '<span style="font-size:13px;">' . count( $available ) . ' total courses match • ' . count( $not_in_group ) . ' available to add (not yet in group)</span>';
        if ( ! empty( $not_in_group ) ) {
            echo '<ul style="margin:8px 0 0; padding-left:20px; font-size:12px; color:#646970; max-height:120px; overflow-y:auto;">';
            foreach ( array_slice( $not_in_group, 0, 15 ) as $cid ) {
                echo '<li>' . esc_html( get_the_title( $cid ) ) . '</li>';
            }
            if ( count( $not_in_group ) > 15 ) {
                echo '<li><em>…and ' . ( count( $not_in_group ) - 15 ) . ' more</em></li>';
            }
            echo '</ul>';
        }
        echo '</div>';
    }
}

/**
 * Save expansion tags when group is saved.
 */
add_action( 'save_post_groups', function( $post_id ) {
    if ( ! isset( $_POST['glct_expansion_nonce'] ) || ! wp_verify_nonce( $_POST['glct_expansion_nonce'], 'glct_expansion_save' ) ) {
        return;
    }
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    $tags = isset( $_POST['glct_expansion_tags'] ) ? array_map( 'intval', (array) $_POST['glct_expansion_tags'] ) : [];
    update_post_meta( $post_id, 'glct_expansion_tags', $tags );
} );

function glct_render_group_metabox($post) {
    $gid = $post->ID;
    $disabled = glct_disabled_ids($gid);
    $master = (array) get_post_meta($gid, 'glct_master_courses', true);
    $has_overrides = false;
    
    echo '<ul style="margin:0; padding:0;">';
    foreach ($master as $cid) {
        $is_disabled = in_array($cid, $disabled);
        if ($is_disabled) {
            $has_overrides = true;
            $title = get_the_title($cid);
            echo '<li style="margin-bottom:8px; padding-bottom:8px; border-bottom:1px solid #f0f0f1;">';
            echo '<strong>' . esc_html($title) . '</strong><br>';
            echo '<span style="color:#c8332a; font-size:12px; font-weight:600;">Currently Disabled</span>';
            echo '</li>';
        }
    }
    echo '</ul>';

    if (!$has_overrides) {
        echo '<p style="color:#646970;">No active overrides. All linked courses are enabled for this group.</p>';
    }
}

function glct_render_course_metabox($post) {
    $cid = $post->ID;
    $groups = get_posts(['post_type' => glct_group_post_type(), 'posts_per_page' => -1, 'fields' => 'ids']);
    $has_overrides = false;

    echo '<ul style="margin:0; padding:0;">';
    foreach ($groups as $gid) {
        $disabled = glct_disabled_ids($gid);
        if (in_array($cid, $disabled)) {
            $has_overrides = true;
            $title = get_the_title($gid);
            echo '<li style="margin-bottom:8px; padding-bottom:8px; border-bottom:1px solid #f0f0f1;">';
            echo 'Disabled in <strong>' . esc_html($title) . '</strong>';
            echo '</li>';
        }
    }
    echo '</ul>';

    if (!$has_overrides) {
        echo '<p style="color:#646970;">No active overrides. This course is enabled in all groups it is assigned to.</p>';
    }
}


// ═══════════════════════════════════════════════════════════════════════════
// SECTION 14 — LEARNER NOTIFICATIONS & ALERTS
// ═══════════════════════════════════════════════════════════════════════════

// 14A — Notifications DB Table
add_action( 'plugins_loaded', 'glct_check_notifications_db' );
function glct_check_notifications_db(): void {
    if ( get_option( 'glct_notif_db_version' ) !== '1.1.0' ) {
        global $wpdb;
        $table = $wpdb->prefix . 'glct_notifications';
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            type varchar(30) NOT NULL,
            group_id bigint(20) NOT NULL DEFAULT 0,
            course_id bigint(20) NOT NULL DEFAULT 0,
            title varchar(255) NOT NULL,
            message text NOT NULL,
            read_at datetime DEFAULT NULL,
            seen_at datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY  (id),
            KEY idx_user_created (user_id, created_at),
            KEY idx_user_unread (user_id, read_at),
            KEY idx_user_unseen (user_id, seen_at)
        ) $charset_collate;";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
        update_option( 'glct_notif_db_version', '1.1.0' );
    }
}

// 14B — Notification Helpers

function glct_create_notification( string $type, int $user_id, int $group_id, int $course_id, string $title, string $message = '' ): void {
    global $wpdb;
    $wpdb->insert(
        $wpdb->prefix . 'glct_notifications',
        [
            'user_id'    => $user_id,
            'type'       => $type,
            'group_id'   => $group_id,
            'course_id'  => $course_id,
            'title'      => $title,
            'message'    => $message,
            'created_at' => current_time( 'mysql' ),
        ],
        [ '%d', '%s', '%d', '%d', '%s', '%s', '%s' ]
    );
}

function glct_notify_group_members( int $group_id, int $course_id, string $type, string $title, string $message = '' ): void {
    $members = glct_members( $group_id );
    foreach ( $members as $u ) {
        glct_create_notification( $type, $u->ID, $group_id, $course_id, $title, $message );
    }
}

// 14C — Learner AJAX Handlers

add_action( 'wp_ajax_glct_get_my_notifications', function (): void {
    check_ajax_referer( 'glct_learner_nonce', 'nonce' );
    $user_id  = get_current_user_id();
    $page     = max( 1, (int) ( $_POST['page'] ?? 1 ) );
    $filter   = sanitize_text_field( $_POST['filter'] ?? 'all' );
    $per_page = 15;
    $offset   = ( $page - 1 ) * $per_page;

    global $wpdb;
    $table = $wpdb->prefix . 'glct_notifications';
    $where = $wpdb->prepare( "WHERE user_id = %d", $user_id );

    if ( $filter === 'unread' ) {
        $where .= " AND read_at IS NULL";
    } elseif ( $filter === 'email_sent' ) {
        $where .= " AND type = 'email_sent'";
    } elseif ( $filter === 'course_change' ) {
        $where .= " AND type IN ('course_added','course_removed','course_enabled','course_disabled','user_enabled','user_disabled')";
    } elseif ( $filter === 'update' ) {
        $where .= " AND type = 'update'";
    } elseif ( $filter === 'deadline' ) {
        $where .= " AND type IN ('deadline','deadline_reminder')";
    }

    $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} {$where}" );
    $rows  = $wpdb->get_results(
        "SELECT * FROM {$table} {$where} ORDER BY created_at DESC LIMIT {$per_page} OFFSET {$offset}"
    );

    // Collect unique course IDs to batch-fetch permalinks
    $course_ids = array_unique( array_filter( array_map( function( $r ) { return (int) $r->course_id; }, $rows ) ) );
    $course_urls = [];
    if ( $course_ids ) {
        _prime_post_caches( $course_ids, false );
        foreach ( $course_ids as $cid ) {
            $url = get_permalink( $cid );
            if ( $url ) {
                $course_urls[ $cid ] = $url;
            }
        }
    }

    $items = [];
    foreach ( $rows as $row ) {
        $cid = (int) $row->course_id;
        $item = [
            'id'         => (int) $row->id,
            'type'       => $row->type,
            'title'      => $row->title,
            'message'    => $row->message,
            'is_read'    => ! empty( $row->read_at ),
            'created_at' => $row->created_at,
            'time_ago'   => human_time_diff( strtotime( $row->created_at ), time() ) . ' ago',
        ];
        if ( $cid && isset( $course_urls[ $cid ] ) ) {
            $item['course_url'] = $course_urls[ $cid ];
        }
        $items[] = $item;
    }

    wp_send_json_success( [
        'items'    => $items,
        'total'    => $total,
        'page'     => $page,
        'has_more' => ( $offset + $per_page ) < $total,
    ] );
} );

add_action( 'wp_ajax_glct_mark_notification_read', function (): void {
    check_ajax_referer( 'glct_learner_nonce', 'nonce' );
    $nid     = (int) ( $_POST['notification_id'] ?? 0 );
    $user_id = get_current_user_id();
    global $wpdb;
    $now = current_time( 'mysql' );
    $wpdb->update(
        $wpdb->prefix . 'glct_notifications',
        [ 'read_at' => $now, 'seen_at' => $now ],
        [ 'id' => $nid, 'user_id' => $user_id ],
        [ '%s', '%s' ],
        [ '%d', '%d' ]
    );
    // Log learner acknowledgment to GL activity feed
    $notif = $wpdb->get_row( $wpdb->prepare(
        "SELECT group_id, course_id, type FROM {$wpdb->prefix}glct_notifications WHERE id = %d AND user_id = %d",
        $nid, $user_id
    ) );
    if ( $notif ) {
        $action = $notif->type === 'update' ? 'learner_welcomed' : 'learner_read';
        glct_log_event( $action, (int) $notif->group_id, (int) $notif->course_id, $user_id, true );
    }
    // Track learner activity
    update_user_meta( $user_id, 'glct_last_activity', time() );
    wp_send_json_success();
} );

add_action( 'wp_ajax_glct_mark_all_read', function (): void {
    check_ajax_referer( 'glct_learner_nonce', 'nonce' );
    $user_id = get_current_user_id();
    global $wpdb;
    // Capture distinct group IDs before marking read (for audit logging)
    $unread_groups = $wpdb->get_col( $wpdb->prepare(
        "SELECT DISTINCT group_id FROM {$wpdb->prefix}glct_notifications WHERE user_id = %d AND read_at IS NULL",
        $user_id
    ) );
    $now = current_time( 'mysql' );
    $wpdb->query( $wpdb->prepare(
        "UPDATE {$wpdb->prefix}glct_notifications SET read_at = COALESCE(read_at, %s), seen_at = COALESCE(seen_at, %s) WHERE user_id = %d AND (read_at IS NULL OR seen_at IS NULL)",
        $now, $now,
        $user_id
    ) );
    // Log one audit event per group for GL activity feed
    foreach ( $unread_groups as $gid ) {
        glct_log_event( 'learner_read_all', (int) $gid, 0, $user_id, true );
    }
    // Track learner activity
    update_user_meta( $user_id, 'glct_last_activity', time() );
    wp_send_json_success();
} );

// AJAX endpoint to return popup HTML for cacheable pages (avoids embedding user content in page HTML)
add_action( 'wp_ajax_glct_get_popup_data', function (): void {
    check_ajax_referer( 'glct_learner_nonce', 'nonce' );
    $user_id = get_current_user_id();
    global $wpdb;
    $table = $wpdb->prefix . 'glct_notifications';
    $unseen_count = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND seen_at IS NULL", $user_id
    ) );
    if ( $unseen_count < 1 ) {
        wp_send_json_success( [ 'html' => '' ] );
        return;
    }
    $latest = $wpdb->get_results( $wpdb->prepare(
        "SELECT id, type, title, created_at FROM {$table} WHERE user_id = %d AND seen_at IS NULL ORDER BY created_at DESC LIMIT 3", $user_id
    ) );
    $alerts_url = get_transient( 'glct_alerts_page_url' );
    if ( false === $alerts_url ) {
        $alerts_url = '';
        $alerts_page_id = (int) get_option( 'glct_alerts_page_id', 0 );
        if ( $alerts_page_id ) {
            $alerts_url = esc_url( get_permalink( $alerts_page_id ) );
        }
        if ( ! $alerts_url ) {
            $found_id = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'page' AND post_status = 'publish' AND post_content LIKE %s LIMIT 1",
                '%[glct_learner_alerts]%'
            ) );
            if ( $found_id ) {
                $alerts_url = esc_url( get_permalink( $found_id ) );
                update_option( 'glct_alerts_page_id', $found_id );
            }
        }
        set_transient( 'glct_alerts_page_url', $alerts_url ?: '', HOUR_IN_SECONDS );
    }
    if ( ! $alerts_url ) $alerts_url = '#';
    $nonce    = wp_create_nonce( 'glct_learner_nonce' );
    $ajax_url = esc_url( admin_url( 'admin-ajax.php' ) );

    ob_start();
    // Reuse the same popup HTML structure
    ?>
    <div id="glct-popup" style="--white:#ffffff;--surface:#f7f9fc;--surface2:#eef1f8;--border:#e1e7f0;--border2:#c5cfe4;--ink:#0d1526;--ink2:#1e2d48;--ink3:#4a5876;--ink4:#8899b8;--blue:#3d63dd;--blue-h:#2c52cc;--green:#0b7d5c;--green-bg:#eafaf4;--green-bd:#a7f3d0;--red:#c8332a;--yellow:#b45309;--purple:#7c3aed;--gold:#b45309;--sh-md:0 4px 12px rgba(13,21,38,.08),0 12px 24px rgba(13,21,38,.06);--r6:6px;--r8:8px;--r99:9999px;position:fixed;bottom:24px;right:24px;z-index:999999;width:340px;max-width:calc(100vw - 32px);background:var(--white);border-radius:12px;box-shadow:var(--sh-md);border:1px solid var(--border);font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;animation:glctPopIn .3s ease-out">
    <style>@keyframes glctPopIn{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:none}}#glct-popup *{margin:0!important;padding:0!important;box-sizing:border-box}.glct-popup-hdr{display:flex;align-items:center;justify-content:space-between;padding:14px 18px!important;border-bottom:1px solid var(--border)}.glct-popup-hdr h4{font-size:14px!important;font-weight:700!important;color:var(--ink2)!important;display:flex;align-items:center;gap:8px}.glct-popup-badge{background:var(--blue)!important;color:var(--white)!important;font-size:11px!important;font-weight:700!important;border-radius:var(--r99)!important;min-width:22px;height:22px;display:flex;align-items:center;justify-content:center;padding:0 6px!important}.glct-popup-close{background:none!important;border:none!important;cursor:pointer;color:var(--ink4)!important;font-size:18px!important;line-height:1;padding:4px!important}.glct-popup-close:hover{color:var(--ink3)!important}.glct-popup-items{padding:6px 0!important;max-height:220px;overflow-y:auto}.glct-popup-item{padding:8px 16px!important;margin:4px 0!important;border-bottom:1px solid var(--surface2)!important;display:flex;align-items:flex-start;gap:10px}.glct-popup-item:last-child{border-bottom:none!important}.glct-popup-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0;margin-top:5px!important}.glct-popup-dot--added{background:var(--green)!important}.glct-popup-dot--removed{background:var(--red)!important}.glct-popup-dot--enabled{background:var(--blue)!important}.glct-popup-dot--disabled{background:var(--yellow)!important}.glct-popup-dot--email{background:var(--purple)!important}.glct-popup-dot--update{background:var(--gold)!important}.glct-popup-dot--deadline{background:#f59e0b!important}.glct-popup-txt{flex:1;min-width:0}.glct-popup-title{font-size:13px!important;font-weight:600!important;color:var(--ink2)!important;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.glct-popup-time{font-size:11px!important;color:var(--ink4)!important;display:block;margin-top:2px!important}.glct-popup-footer{padding:10px 16px!important;border-top:1px solid var(--border)!important;display:flex;gap:8px}.glct-popup-footer a,.glct-popup-footer button{flex:1;text-align:center;padding:8px 12px!important;border-radius:var(--r6)!important;font-size:13px!important;font-weight:600!important;text-decoration:none!important;cursor:pointer;border:none!important}.glct-popup-view{background:var(--blue)!important;color:var(--white)!important}.glct-popup-view:hover{background:var(--blue-h)!important}.glct-popup-ack{background:#eafaf4!important;color:#0b7d5c!important;border:1px solid #a7f3d0!important;transition:background .14s,color .14s,opacity .14s}.glct-popup-ack:hover{background:#0b7d5c!important;color:#fff!important}</style>
    <div class="glct-popup-hdr"><h4>🔔 Alerts <span class="glct-popup-badge"><?php echo esc_html( $unseen_count ); ?></span></h4><button class="glct-popup-close" onclick="(function(p){p.style.transition='opacity .3s,transform .3s';p.style.opacity='0';p.style.transform='translateY(20px)';setTimeout(function(){p.remove()},300);var fd=new FormData();fd.append('action','glct_dismiss_popup');fd.append('nonce','<?php echo esc_js( $nonce ); ?>');fetch('<?php echo esc_js( $ajax_url ); ?>',{method:'POST',body:fd,credentials:'same-origin'})})(this.closest('#glct-popup'))">&times;</button></div>
    <div class="glct-popup-items">
    <?php foreach ( $latest as $n ) :
        $type_class = 'email';
        if ( strpos( $n->type, 'added' ) !== false )    $type_class = 'added';
        if ( strpos( $n->type, 'removed' ) !== false )  $type_class = 'removed';
        if ( strpos( $n->type, 'enabled' ) !== false )  $type_class = 'enabled';
        if ( strpos( $n->type, 'disabled' ) !== false ) $type_class = 'disabled';
        if ( $n->type === 'update' )                    $type_class = 'update';
        if ( strpos( $n->type, 'deadline' ) !== false )  $type_class = 'deadline';
    ?>
    <div class="glct-popup-item"><span class="glct-popup-dot glct-popup-dot--<?php echo esc_attr( $type_class ); ?>"></span><div class="glct-popup-txt"><span class="glct-popup-title"><?php echo esc_html( $n->title ); ?></span><span class="glct-popup-time"><?php echo esc_html( human_time_diff( strtotime( $n->created_at ), time() ) . ' ago' ); ?></span></div></div>
    <?php endforeach; ?>
    </div>
    <div class="glct-popup-footer"><a href="<?php echo esc_url( $alerts_url ); ?>" class="glct-popup-view">View All (<?php echo esc_html( $unseen_count ); ?>)</a><button class="glct-popup-ack" onclick="(function(b){b.textContent='Marking\u2026';b.disabled=true;b.style.opacity='0.6';var p=b.closest('#glct-popup');var fd=new FormData();fd.append('action','glct_mark_all_read');fd.append('nonce','<?php echo esc_js( $nonce ); ?>');fetch('<?php echo esc_js( $ajax_url ); ?>',{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(d){if(d.success){b.textContent='\u2713 All Read';b.style.opacity='1';b.style.background='var(--green,#0b7d5c)';b.style.color='var(--white,#fff)';setTimeout(function(){p.style.transition='opacity .3s,transform .3s';p.style.opacity='0';p.style.transform='translateY(20px)';setTimeout(function(){p.remove()},300)},800)}else{b.textContent='Error';b.style.opacity='1';b.disabled=false}})})(this)">✓ <?php echo $unseen_count === 1 ? 'Mark Read' : 'Mark All Read'; ?></button></div>
    </div>
    <?php
    wp_send_json_success( [ 'html' => ob_get_clean() ] );
} );

add_action( 'wp_ajax_glct_dismiss_popup', function (): void {
    check_ajax_referer( 'glct_learner_nonce', 'nonce' );
    $user_id = get_current_user_id();
    global $wpdb;
    // Capture distinct group IDs before marking seen (for audit logging)
    $unseen_groups = $wpdb->get_col( $wpdb->prepare(
        "SELECT DISTINCT group_id FROM {$wpdb->prefix}glct_notifications WHERE user_id = %d AND seen_at IS NULL",
        $user_id
    ) );
    $wpdb->query( $wpdb->prepare(
        "UPDATE {$wpdb->prefix}glct_notifications SET seen_at = %s WHERE user_id = %d AND seen_at IS NULL",
        current_time( 'mysql' ),
        $user_id
    ) );
    // Log one audit event per group for GL activity feed
    foreach ( $unseen_groups as $gid ) {
        glct_log_event( 'learner_dismissed', (int) $gid, 0, $user_id, true );
    }
    // Track learner activity
    update_user_meta( $user_id, 'glct_last_activity', time() );
    wp_send_json_success();
} );

// 14D — Login Popup (wp_footer)

add_action( 'wp_footer', 'glct_learner_popup' );
function glct_learner_popup(): void {
    if ( ! is_user_logged_in() ) return;
    if ( current_user_can( 'administrator' ) ) return;
    if ( get_option( 'glct_allow_login_popup', 'yes' ) !== 'yes' ) return;

    // Skip on pages that are likely being page-cached (non-shortcode pages)
    // The popup renders user-specific HTML which must not be cached.
    // On cacheable pages, we output only a lightweight AJAX loader instead.
    $on_glct_page = defined( 'DONOTCACHEPAGE' ) && DONOTCACHEPAGE;

    $user_id = get_current_user_id();
    global $wpdb;
    $table = $wpdb->prefix . 'glct_notifications';

    $unseen_count = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND seen_at IS NULL", $user_id
    ) );
    if ( $unseen_count < 1 ) return;

    // On cacheable pages, output a lightweight AJAX-driven popup loader
    if ( ! $on_glct_page ) {
        // Inline a tiny script that fetches popup data via AJAX so the page HTML stays cacheable
        $ajax_url = esc_url( admin_url( 'admin-ajax.php' ) );
        $nonce    = wp_create_nonce( 'glct_learner_nonce' );
        ?>
        <script>
        (function(){
            var fd=new FormData();
            fd.append('action','glct_get_popup_data');
            fd.append('nonce','<?php echo $nonce; ?>');
            fetch('<?php echo $ajax_url; ?>',{method:'POST',body:fd,credentials:'same-origin'})
            .then(function(r){return r.json()})
            .then(function(d){if(d.success&&d.data.html){var c=document.createElement('div');c.innerHTML=d.data.html;document.body.appendChild(c.firstElementChild)}});
        })();
        </script>
        <?php
        return;
    }

    $latest = $wpdb->get_results( $wpdb->prepare(
        "SELECT id, type, title, created_at FROM {$table} WHERE user_id = %d AND seen_at IS NULL ORDER BY created_at DESC LIMIT 3", $user_id
    ) );

    // Use cached alerts page URL (transient avoids LIKE query on every page load)
    $alerts_url = get_transient( 'glct_alerts_page_url' );
    if ( false === $alerts_url ) {
        $alerts_url = '';
        $alerts_page_id = (int) get_option( 'glct_alerts_page_id', 0 );
        if ( $alerts_page_id ) {
            $alerts_url = esc_url( get_permalink( $alerts_page_id ) );
        }
        // Fallback: search for a page containing the shortcode
        if ( ! $alerts_url ) {
            global $wpdb;
            $found_id = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'page' AND post_status = 'publish' AND post_content LIKE %s LIMIT 1",
                '%[glct_learner_alerts]%'
            ) );
            if ( $found_id ) {
                $alerts_url = esc_url( get_permalink( $found_id ) );
                update_option( 'glct_alerts_page_id', $found_id );
            }
        }
        // Cache for 1 hour (even empty string) to avoid repeated LIKE queries
        set_transient( 'glct_alerts_page_url', $alerts_url ?: '', HOUR_IN_SECONDS );
    }
    if ( ! $alerts_url ) $alerts_url = '#';
    $nonce          = wp_create_nonce( 'glct_learner_nonce' );
    $ajax_url       = esc_url( admin_url( 'admin-ajax.php' ) );
    ?>
    <style>
    #glct-popup{
        --white:#ffffff;--surface:#f7f9fc;--surface2:#eef1f8;
        --border:#e1e7f0;--border2:#c5cfe4;
        --ink:#0d1526;--ink2:#1e2d48;--ink3:#4a5876;--ink4:#8899b8;
        --blue:#3d63dd;--blue-h:#2c52cc;
        --green:#0b7d5c;--red:#c8332a;--yellow:#b45309;--purple:#7c3aed;--gold:#b45309;
        --sh-md:0 4px 12px rgba(13,21,38,.08),0 12px 24px rgba(13,21,38,.06);
        --r6:6px;--r8:8px;--r99:9999px;
        position:fixed;bottom:24px;right:24px;z-index:999999;
        width:340px;max-width:calc(100vw - 32px);
        background:var(--white);border-radius:12px;
        box-shadow:var(--sh-md);border:1px solid var(--border);
        font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;
        animation:glctPopIn .3s ease-out
    }
    @keyframes glctPopIn{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:none}}
    #glct-popup *{margin:0 !important;padding:0 !important;box-sizing:border-box}
    .glct-popup-hdr{display:flex;align-items:center;justify-content:space-between;padding:14px 18px !important;border-bottom:1px solid var(--border)}
    .glct-popup-hdr h4{font-size:14px !important;font-weight:700 !important;color:var(--ink2) !important;display:flex;align-items:center;gap:8px}
    .glct-popup-badge{background:var(--blue) !important;color:var(--white) !important;font-size:11px !important;font-weight:700 !important;border-radius:var(--r99) !important;min-width:22px;height:22px;display:flex;align-items:center;justify-content:center;padding:0 6px !important}
    .glct-popup-close{background:none !important;border:none !important;cursor:pointer;color:var(--ink4) !important;font-size:18px !important;line-height:1;padding:4px !important}
    .glct-popup-close:hover{color:var(--ink3) !important}
    .glct-popup-items{padding:6px 0 !important;max-height:220px;overflow-y:auto}
    .glct-popup-item{padding:8px 16px !important;margin:4px 0 !important;border-bottom:1px solid var(--surface2) !important;display:flex;align-items:flex-start;gap:10px}
    .glct-popup-item:last-child{border-bottom:none !important}
    .glct-popup-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0;margin-top:5px !important}
    .glct-popup-dot--added{background:var(--green) !important}.glct-popup-dot--removed{background:var(--red) !important}.glct-popup-dot--enabled{background:var(--blue) !important}.glct-popup-dot--disabled{background:var(--yellow) !important}.glct-popup-dot--email{background:var(--purple) !important}.glct-popup-dot--update{background:var(--gold) !important}.glct-popup-dot--deadline{background:#f59e0b !important}
    .glct-popup-txt{flex:1;min-width:0}
    .glct-popup-title{font-size:13px !important;font-weight:600 !important;color:var(--ink2) !important;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .glct-popup-time{font-size:11px !important;color:var(--ink4) !important;display:block;margin-top:2px !important}
    .glct-popup-footer{padding:10px 16px !important;border-top:1px solid var(--border) !important;display:flex;gap:8px}
    .glct-popup-footer a,.glct-popup-footer button{flex:1;text-align:center;padding:8px 12px !important;border-radius:var(--r6) !important;font-size:13px !important;font-weight:600 !important;text-decoration:none !important;cursor:pointer;border:none !important}
    .glct-popup-view{background:var(--blue) !important;color:var(--white) !important}.glct-popup-view:hover{background:var(--blue-h) !important}
    .glct-popup-ack{background:var(--green-bg,#eafaf4) !important;color:var(--green,#0b7d5c) !important;border:1px solid var(--green-bd,#a7f3d0) !important;transition:background .14s,color .14s,opacity .14s}.glct-popup-ack:hover{background:var(--green,#0b7d5c) !important;color:var(--white) !important}
    @media(max-width:480px){#glct-popup{bottom:12px;right:12px;width:calc(100vw - 24px)}}
    </style>
    <div id="glct-popup">
        <div class="glct-popup-hdr">
            <h4>🔔 Alerts <span class="glct-popup-badge"><?php echo esc_html( $unseen_count ); ?></span></h4>
            <button class="glct-popup-close" id="glct-popup-x">&times;</button>
        </div>
        <div class="glct-popup-items">
            <?php foreach ( $latest as $n ) :
                $type_class = 'email';
                if ( strpos( $n->type, 'added' ) !== false )    $type_class = 'added';
                if ( strpos( $n->type, 'removed' ) !== false )  $type_class = 'removed';
                if ( strpos( $n->type, 'enabled' ) !== false )  $type_class = 'enabled';
                if ( strpos( $n->type, 'disabled' ) !== false ) $type_class = 'disabled';
                if ( $n->type === 'update' )                    $type_class = 'update';
            ?>
            <div class="glct-popup-item">
                <span class="glct-popup-dot glct-popup-dot--<?php echo esc_attr( $type_class ); ?>"></span>
                <div class="glct-popup-txt">
                    <span class="glct-popup-title"><?php echo esc_html( $n->title ); ?></span>
                    <span class="glct-popup-time"><?php echo esc_html( human_time_diff( strtotime( $n->created_at ), time() ) . ' ago' ); ?></span>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="glct-popup-footer">
            <a href="<?php echo $alerts_url; ?>" class="glct-popup-view">View All (<?php echo esc_html( $unseen_count ); ?>)</a>
            <button class="glct-popup-ack" id="glct-popup-ack">✓ <?php echo $unseen_count === 1 ? 'Mark Read' : 'Mark All Read'; ?></button>
        </div>
    </div>
    <script>
    (function(){
        var ajax='<?php echo $ajax_url; ?>';
        var nonce='<?php echo $nonce; ?>';
        function closePopup(){
            var popup=document.getElementById('glct-popup');
            if(!popup)return;
            popup.style.transition='opacity .3s,transform .3s';
            popup.style.opacity='0';
            popup.style.transform='translateY(20px)';
            setTimeout(function(){popup.remove()},300);
        }
        function dismissPopup(){
            closePopup();
            var fd=new FormData();
            fd.append('action','glct_dismiss_popup');
            fd.append('nonce',nonce);
            fetch(ajax,{method:'POST',body:fd,credentials:'same-origin'});
        }
        function markAllRead(){
            var btn=document.getElementById('glct-popup-ack');
            if(btn){btn.textContent='Marking\u2026';btn.disabled=true;btn.style.opacity='0.6'}
            var fd=new FormData();
            fd.append('action','glct_mark_all_read');
            fd.append('nonce',nonce);
            fetch(ajax,{method:'POST',body:fd,credentials:'same-origin'})
            .then(function(r){return r.json()})
            .then(function(d){
                if(d.success){
                    if(btn){btn.textContent='\u2713 All Read';btn.style.opacity='1';btn.style.background='var(--green,#0b7d5c)';btn.style.color='var(--white,#fff)'}
                    setTimeout(closePopup,800);
                } else {
                    if(btn){btn.textContent='Error';btn.style.opacity='1';btn.disabled=false}
                }
            });
        }
        var xBtn=document.getElementById('glct-popup-x');
        var aBtn=document.getElementById('glct-popup-ack');
        if(xBtn)xBtn.addEventListener('click',dismissPopup);
        if(aBtn)aBtn.addEventListener('click',markAllRead);
    })();
    </script>
    <?php
}

// 14E — Learner Alerts Shortcode & Renderer

add_shortcode( 'glct_learner_alerts', 'glct_learner_alerts_shortcode' );
function glct_learner_alerts_shortcode(): string {
    // Prevent page caching — this page contains nonces and user-specific content
    if ( ! defined( 'DONOTCACHEPAGE' ) ) {
        define( 'DONOTCACHEPAGE', true );
    }
    nocache_headers();

    if ( ! is_user_logged_in() ) {
        return '<p style="padding:20px;text-align:center;color:#64748b;">Please log in to view your alerts.</p>';
    }
    ob_start();
    glct_render_learner_alerts();
    return ob_get_clean();
}

function glct_render_learner_alerts(): void {
    $nonce    = wp_create_nonce( 'glct_learner_nonce' );
    $ajax_url = admin_url( 'admin-ajax.php' );

    // Track learner activity
    update_user_meta( get_current_user_id(), 'glct_last_activity', time() );

    // Admin broadcasts (type='update') are created by the admin via AJAX, not auto-generated here.
    ?>
    <div id="glct-alerts">
        <div class="glct-al-header">
            <div>
                <h2 class="glct-al-title">📬 My Course Alerts</h2>
                <p class="glct-al-sub">Stay updated on course changes and messages from your Group Leader</p>
            </div>
            <button id="glct-al-mark-all" class="glct-al-btn" disabled>Mark All Read</button>
        </div>

        <div class="glct-al-filters">
            <button class="glct-al-pill glct-al-pill--active" data-filter="all">All</button>
            <button class="glct-al-pill" data-filter="unread">Unread</button>
            <button class="glct-al-pill" data-filter="email_sent">Emails</button>
            <button class="glct-al-pill" data-filter="course_change">Course Changes</button>
            <button class="glct-al-pill" data-filter="update">Updates</button>
            <button class="glct-al-pill" data-filter="deadline">Deadlines</button>
        </div>

        <div id="glct-al-list">
            <p class="glct-al-loading">Loading your alerts...</p>
        </div>

        <div style="text-align:center; padding:16px 0;">
            <button id="glct-al-more" class="glct-al-btn glct-al-btn--ghost" hidden>Load More</button>
        </div>
    </div>

    <style>
    #glct-alerts{
        --white:#ffffff;--surface:#f7f9fc;--surface2:#eef1f8;
        --border:#e1e7f0;--border2:#c5cfe4;
        --ink:#0d1526;--ink2:#1e2d48;--ink3:#4a5876;--ink4:#8899b8;
        --blue:#3d63dd;--blue-h:#2c52cc;--blue-bg:#eef2ff;--blue-bd:#afc2ff;
        --green:#0b7d5c;--green-bg:#eafaf4;--green-bd:#6dcfab;
        --red:#c8332a;--red-bg:#fff4f3;--red-bd:#f9b2ae;
        --yellow:#b45309;--yellow-bg:#fef3c7;--yellow-bd:#fcd34d;
        --purple:#7c3aed;--purple-bg:#ede9fe;--purple-bd:#c4b5fd;
        --gold:#b45309;--gold-bg:#fef9c3;--gold-bd:#fde047;
        --sh-sm:0 1px 3px rgba(13,21,38,.06),0 2px 6px rgba(13,21,38,.04);
        --r6:6px;--r8:8px;--r99:9999px;
        font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif !important;
        max-width:720px;margin:0 auto !important;padding:24px 16px !important;color:var(--ink);line-height:1.6
    }
    #glct-alerts *{margin:0 !important;padding:0 !important;box-sizing:border-box}
    .glct-al-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px !important;gap:16px;flex-wrap:wrap}
    .glct-al-header div p{font-weight:500 !important}
    .glct-al-title{font-size:1.35rem !important;font-weight:700 !important;color:var(--ink) !important}
    .glct-al-sub{font-size:.85rem !important;color:var(--ink4) !important;margin-top:4px !important}
    .glct-al-btn{padding:8px 18px !important;font-size:.82rem !important;font-weight:600 !important;border-radius:var(--r6) !important;border:none !important;cursor:pointer;background:var(--blue) !important;color:var(--white) !important;transition:background .14s,color .14s,opacity .14s}
    .glct-al-btn:hover{background:var(--blue-h) !important}
    #glct-al-mark-all{background-color:transparent !important;color:#2980b9 !important;transition:opacity .14s}
    #glct-al-mark-all:hover:not(:disabled){background-color:var(--surface2) !important}
    #glct-al-mark-all:disabled{opacity:0.4 !important;cursor:not-allowed !important;color:var(--ink4) !important}
    .glct-al-btn--ghost{background:var(--surface2) !important;color:var(--ink3) !important;border:1px solid var(--border) !important}.glct-al-btn--ghost:hover{background:var(--border) !important;color:var(--ink2) !important}
    .glct-al-filters{display:flex;gap:8px;margin-bottom:18px !important;flex-wrap:wrap}
    .glct-al-pill{font-size:.78rem !important;font-weight:600 !important;padding:4px 8px !important;margin-left:4px !important;border-radius:var(--r99) !important;border:1px solid var(--border2) !important;background:var(--white) !important;color:var(--ink3) !important;cursor:pointer;transition:all .14s}
    .glct-al-pill:hover{border-color:var(--blue-bd) !important;color:var(--blue) !important}
    .glct-al-pill--active{background:var(--blue) !important;color:var(--white) !important;border-color:var(--blue) !important}
    .glct-al-loading{text-align:center;padding:32px 0 !important;color:var(--ink4);font-size:.9rem}
    .glct-al-empty{text-align:center;padding:48px 0 !important;color:var(--ink4);font-size:.95rem}
    .glct-al-item{display:flex;align-items:flex-start;gap:16px;padding:18px 20px !important;border:1px solid var(--border) !important;border-radius:var(--r8) !important;margin-top:12px !important;margin-bottom:12px !important;background:var(--white) !important;cursor:pointer;box-shadow:var(--sh-sm);transition:border-color .14s,background .4s,border-left-width .3s}
    .glct-al-item:hover{border-color:var(--blue-bd) !important;background:var(--surface) !important}
    .glct-al-item--unread{border-left:3px solid var(--blue) !important;background:var(--blue-bg) !important}
    .glct-al-icon{width:36px;height:36px;border-radius:var(--r8);display:flex;align-items:center;justify-content:center;font-size:1rem;flex-shrink:0}
    .glct-al-icon--added{background:var(--green-bg) !important;color:var(--green) !important}
    .glct-al-icon--removed{background:var(--red-bg) !important;color:var(--red) !important}
    .glct-al-icon--enabled{background:var(--blue-bg) !important;color:var(--blue) !important}
    .glct-al-icon--disabled{background:var(--yellow-bg) !important;color:var(--yellow) !important}
    .glct-al-icon--email{background:var(--purple-bg) !important;color:var(--purple) !important}
    .glct-al-icon--update{background:var(--gold-bg) !important;color:var(--gold) !important;margin:4px !important}
    .glct-al-icon--deadline{background:#fef3c7 !important;color:#b45309 !important}
    .glct-al-content{flex:1;min-width:0;padding-top:4px !important;padding-bottom:4px !important}
    .glct-al-top{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px !important}
    .glct-al-badge{font-size:.68rem !important;font-weight:700 !important;padding:2px 8px !important;border-radius:var(--r99) !important;text-transform:uppercase;letter-spacing:.3px}
    .glct-al-badge--added{background:var(--green-bg) !important;color:var(--green) !important}
    .glct-al-badge--removed{background:var(--red-bg) !important;color:var(--red) !important}
    .glct-al-badge--enabled{background:var(--blue-bg) !important;color:var(--blue) !important}
    .glct-al-badge--disabled{background:var(--yellow-bg) !important;color:var(--yellow) !important}
    .glct-al-badge--email{background:var(--purple-bg) !important;color:var(--purple) !important}
    .glct-al-badge--update{background:var(--gold-bg) !important;color:var(--gold) !important}
    .glct-al-badge--deadline{background:#fef3c7 !important;color:#b45309 !important}
    .glct-al-time{font-size:.72rem !important;color:var(--ink4) !important;margin-left:auto !important}
    .glct-al-item-title{font-size:.9rem !important;font-weight:600 !important;color:var(--ink2) !important;margin-bottom:2px !important}
    .glct-al-msg{margin-top:10px !important;padding:12px 16px !important;background:var(--surface) !important;border-radius:var(--r6) !important;border:1px solid var(--border) !important;font-size:.84rem !important;color:var(--ink3) !important;line-height:1.7;white-space:pre-wrap}
    .glct-al-course-link{display:inline-block !important;margin-top:8px !important;font-size:.82rem !important;font-weight:600 !important;color:var(--blue) !important;text-decoration:none !important;padding:6px 12px !important;background:var(--blue-bg) !important;border:1px solid var(--blue-bd) !important;border-radius:var(--r6) !important;transition:background .14s,color .14s}
    .glct-al-course-link:hover{background:var(--blue) !important;color:var(--white) !important}
    .glct-al-ack{display:flex;align-items:center;gap:8px;margin-top:10px !important;margin-left:4px !important;padding:8px 12px !important;background:var(--blue-bg) !important;border:1px solid var(--blue-bd) !important;border-radius:var(--r6) !important;cursor:pointer}
    .glct-al-ack input[type="checkbox"]{width:18px !important;height:18px !important;accent-color:var(--blue);cursor:pointer;flex-shrink:0;margin:0 !important}
    .glct-al-ack label{font-size:.82rem !important;font-weight:600 !important;color:var(--blue) !important;cursor:pointer}
    .glct-al-ack.is-confirmed{background:var(--green-bg) !important;border-color:var(--green-bd) !important}
    .glct-al-ack.is-confirmed label{color:var(--green) !important}
    @media(max-width:600px){#glct-alerts{padding:16px 12px !important}.glct-al-item{padding:12px 14px !important;gap:10px}.glct-al-icon{width:30px;height:30px;font-size:.85rem}.glct-al-title{font-size:1.15rem !important}}
    </style>

    <script>
    (function(){
        var AJAX='<?php echo esc_js( $ajax_url ); ?>';
        var NONCE='<?php echo esc_js( $nonce ); ?>';
        var currentFilter='all';
        var currentPage=1;

        function post(action,data,cb){
            var fd=new FormData();
            fd.append('action',action);
            fd.append('nonce',NONCE);
            for(var k in data) fd.append(k,data[k]);
            fetch(AJAX,{method:'POST',body:fd,credentials:'same-origin'})
                .then(function(r){return r.json()})
                .then(cb)
                .catch(function(){ cb({success:false}); });
        }

        function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')}

        function updateMarkAllBtn(){
            var btn=document.getElementById('glct-al-mark-all');
            if(!btn)return;
            var hasUnread=document.querySelectorAll('#glct-al-list .glct-al-item--unread').length>0||
                          document.querySelectorAll('#glct-al-list .glct-al-item[data-read="0"]').length>0;
            btn.disabled=!hasUnread;
        }

        function typeInfo(type){
            if(type==='course_added'||type==='user_enabled') return{cls:'added',icon:'➕',label:'Added'};
            if(type==='course_removed') return{cls:'removed',icon:'🗑',label:'Removed'};
            if(type==='course_enabled') return{cls:'enabled',icon:'✅',label:'Enabled'};
            if(type==='course_disabled'||type==='user_disabled') return{cls:'disabled',icon:'⚠️',label:'Disabled'};
            if(type==='email_sent') return{cls:'email',icon:'✉️',label:'Email'};
            if(type==='update') return{cls:'update',icon:'📢',label:'Update'};
            if(type==='deadline'||type==='deadline_reminder') return{cls:'deadline',icon:'⏰',label:'Deadline'};
            return{cls:'enabled',icon:'📌',label:type};
        }

        function loadAlerts(page,append){
            if(!append){document.getElementById('glct-al-list').innerHTML='<p class="glct-al-loading">Loading...</p>'}
            post('glct_get_my_notifications',{page:page,filter:currentFilter},function(res){
                if(!res.success){document.getElementById('glct-al-list').innerHTML='<p class="glct-al-empty">Error loading alerts.</p>';return}
                var items=res.data.items;
                if(!items.length&&page===1){document.getElementById('glct-al-list').innerHTML='<p class="glct-al-empty">🎉 No alerts yet. You\'re all caught up!</p>';document.getElementById('glct-al-more').hidden=true;return}
                var html='';
                items.forEach(function(n){
                    var ti=typeInfo(n.type);
                    var ackId='glct-ack-'+n.id;
                    html+='<div class="glct-al-item'+(n.is_read?'':' glct-al-item--unread')+'" data-id="'+n.id+'" data-read="'+(n.is_read?1:0)+'">'
                        +'<div class="glct-al-icon glct-al-icon--'+ti.cls+'">'+ti.icon+'</div>'
                        +'<div class="glct-al-content">'
                        +'<div class="glct-al-top"><span class="glct-al-badge glct-al-badge--'+ti.cls+'">'+ti.label+'</span><span class="glct-al-time">'+esc(n.time_ago)+'</span></div>'
                        +'<div class="glct-al-item-title">'+esc(n.title)+'</div>'
                        +(n.message?'<div class="glct-al-msg" hidden>'+esc(n.message)+'</div>':'')
                        +(n.course_url?'<a href="'+esc(n.course_url)+'" class="glct-al-course-link" onclick="event.stopPropagation()">Go to Course →</a>':'')
                        +'<div class="glct-al-ack'+(n.is_read?' is-confirmed':'')+'">'
                        +'<input type="checkbox" id="'+ackId+'"'+(n.is_read?' checked disabled':'')+' />'
                        +'<label for="'+ackId+'">'+(n.is_read?'✓ Acknowledged':'I acknowledge this alert')+'</label>'
                        +'</div>'
                        +'</div></div>';
                });
                if(append){document.getElementById('glct-al-list').innerHTML+=html}
                else{document.getElementById('glct-al-list').innerHTML=html}
                document.getElementById('glct-al-more').hidden=!res.data.has_more;
                wireItems();
                updateMarkAllBtn();
            });
        }

        function wireItems(){
            document.querySelectorAll('#glct-al-list .glct-al-item').forEach(function(el){
                if(el.dataset.wired)return;
                el.dataset.wired='1';
                // Click to expand/collapse message
                el.addEventListener('click',function(e){
                    if(e.target.tagName==='INPUT'||e.target.tagName==='LABEL')return; // don't toggle msg on checkbox click
                    var msg=el.querySelector('.glct-al-msg');
                    if(msg)msg.hidden=!msg.hidden;
                });
                // Explicit acknowledge checkbox
                var cb=el.querySelector('.glct-al-ack input[type="checkbox"]');
                if(cb&&!cb.disabled){
                    cb.addEventListener('change',function(){
                        if(!cb.checked)return;
                        cb.disabled=true;
                        var ack=el.querySelector('.glct-al-ack');
                        var lbl=el.querySelector('.glct-al-ack label');
                        lbl.textContent='Acknowledging...';
                        post('glct_mark_notification_read',{notification_id:el.dataset.id},function(res){
                            el.dataset.read='1';
                            el.classList.remove('glct-al-item--unread');
                            ack.classList.add('is-confirmed');
                            lbl.textContent='✓ Acknowledged';
                            updateMarkAllBtn();
                        });
                    });
                }
            });
        }

        // Filter pills
        document.querySelectorAll('.glct-al-pill').forEach(function(pill){
            pill.addEventListener('click',function(){
                document.querySelectorAll('.glct-al-pill').forEach(function(p){p.classList.remove('glct-al-pill--active')});
                pill.classList.add('glct-al-pill--active');
                currentFilter=pill.dataset.filter;
                currentPage=1;
                loadAlerts(1,false);
            });
        });

        // Load More
        document.getElementById('glct-al-more').addEventListener('click',function(){
            currentPage++;
            loadAlerts(currentPage,true);
        });

        // Mark All Read
        document.getElementById('glct-al-mark-all').addEventListener('click',function(){
            var btn=this;
            var origText=btn.textContent;
            btn.textContent='Marking\u2026';
            btn.disabled=true;
            btn.style.opacity='0.6';
            post('glct_mark_all_read',{},function(res){
                if(res.success){
                    btn.textContent='\u2713 All Read';
                    btn.style.background='var(--green-bg,#eafaf4)';
                    btn.style.color='var(--green,#0b7d5c)';
                    btn.style.opacity='1';
                    document.querySelectorAll('#glct-al-list .glct-al-item').forEach(function(el){
                        el.classList.remove('glct-al-item--unread');
                        el.dataset.read='1';
                        var ack=el.querySelector('.glct-al-ack');
                        var cb=el.querySelector('.glct-al-ack input[type="checkbox"]');
                        var lbl=el.querySelector('.glct-al-ack label');
                        if(ack&&!ack.classList.contains('is-confirmed')){
                            ack.classList.add('is-confirmed');
                            if(cb){cb.checked=true;cb.disabled=true}
                            if(lbl)lbl.textContent='\u2713 Acknowledged';
                        }
                    });
                    // Dismiss the notification popup if it's visible on the page
                    var popup=document.getElementById('glct-popup');
                    if(popup){popup.style.transition='opacity .3s,transform .3s';popup.style.opacity='0';popup.style.transform='translateY(20px)';setTimeout(function(){popup.remove()},300)}
                    setTimeout(function(){
                        btn.textContent=origText;
                        btn.style.background='';
                        btn.style.color='';
                        updateMarkAllBtn();
                    },2500);
                } else {
                    btn.textContent='Error \u2014 Try Again';
                    btn.style.background='var(--red-bg,#fff4f3)';
                    btn.style.color='var(--red,#c8332a)';
                    btn.style.opacity='1';
                    btn.disabled=false;
                    setTimeout(function(){
                        btn.textContent=origText;
                        btn.style.background='';
                        btn.style.color='';
                    },3000);
                }
            });
        });

        // Initial load
        loadAlerts(1,false);
    })();
    </script>
    <?php
}